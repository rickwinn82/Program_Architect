Program Architect Build 94 Operations Control Repair

Purpose
- restore functional Operations page controls
- package the release with offline install assets and safer local-data controls
- split the browser app into modular static files instead of one inline-script HTML

Fixed
- Open Operations Report PDF
- Email Operations Report
- Download Operations TXT
- add manifest, service worker, and app icon files for packaged installs
- add dashboard backup export, backup import, and local reset controls
- track last saved / last backup / last restore timestamps in local state
- tighten catalog product matching for inventory and order-sheet edits
- move app logic into `calc-core.js`, `app-main.js`, and `modules/`
- split shared constants, state-storage, and regression logic into separate `modules/` files
- bundle local PDF.js files in `vendor/` so vendor PDF import works offline
- add locked regression expectations plus `npm run regression`

Notes
- built from Build 93 Rate Input Repair baseline
- `index.html` now loads external static files, so keep the full folder together
