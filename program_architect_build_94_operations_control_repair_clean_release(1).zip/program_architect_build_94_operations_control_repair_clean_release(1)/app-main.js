import { ensurePdfJsModule } from "./modules/pdf-loader.mjs";
import { STORAGE_KEY, LEGACY_STORAGE_KEYS, APP_META as BASE_APP_META, APP_COPY } from "./modules/constants.mjs";
import { createStateStorage } from "./modules/state-storage.mjs";
import { createRegressionTools } from "./modules/regression-tools.mjs";

const APP_META = {
  ...BASE_APP_META,
  pdfJsUrl: new URL("./vendor/pdf.min.mjs", import.meta.url).href,
  pdfJsWorkerUrl: new URL("./vendor/pdf.worker.min.mjs", import.meta.url).href
};
let installPrompt = null;
const products = [
  {
    "sku": "001482",
    "name": "Ferrous Sulfate Micronutrient 20%Fe Sprayable",
    "category": "Nutrient",
    "price": 21.46,
    "unit": "50 lb bag",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402. Item note: Currently a shortage, I recommend 13-0-0 non staining below.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "018300",
    "name": "Magnesium Sulfate (Epsom Salt) AG Grade",
    "category": "Nutrient",
    "price": 21.57,
    "unit": "50 lb bag",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "080-57622",
    "name": "BioPro Bio MP",
    "category": "Bio",
    "price": 65.59,
    "unit": "2.5 gal jug",
    "npk": "5-3-2",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "084043",
    "name": "LESCO Chelated Iron Plus",
    "category": "Nutrient",
    "price": 27.7,
    "unit": "2.5 gal jug",
    "npk": "12-0-0",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "089075",
    "name": "LESCO Moisture Manager",
    "category": "Soil",
    "price": 101.19,
    "unit": "2.5 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402. Item note: Private label Hydretain.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "089801",
    "name": "LESCO Moisture Manager Hygroscopic Humectant Soil Conditioner",
    "category": "Soil",
    "price": 56.18,
    "unit": "40 lb bag",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "098186",
    "name": "LESCO Chelated AM + Micros",
    "category": "Nutrient",
    "price": 28.37,
    "unit": "2.5 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "098504",
    "name": "LESCO K-Flow 0-0-25",
    "category": "Nutrient",
    "price": 29.49,
    "unit": "2.5 gal jug",
    "npk": "0-0-25",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "098604",
    "name": "LESCO 24-0-11 75% PolyPlus OPTI",
    "category": "Nutrient",
    "price": 26.98,
    "unit": "50 lb bag",
    "npk": "24-0-11",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "101186",
    "name": "LESCO Broadcast Spreader w/ 80 lb Capacity and Stainless Steel Frame",
    "category": "Equipment",
    "price": 698.0,
    "unit": "ea",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "10441225",
    "name": "LESCO T-Storm Flowable Thiophanate-Methyl 46.2",
    "category": "Fungicide",
    "price": 119.41,
    "unit": "2.5 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "10580032",
    "name": "Nufarm Arena 0.25G Clothianidin 0.25 Systemic Granular Insecticide",
    "category": "Insecticide",
    "price": 70.5,
    "unit": "30 lb bag",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "10594403",
    "name": "Safari 20 SG Insecticide",
    "category": "Insecticide",
    "price": 409.05,
    "unit": "3 lb",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "10669032",
    "name": "Aloft LC G Insecticide",
    "category": "Insecticide",
    "price": 70.5,
    "unit": "30 lb",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "10677464",
    "name": "Aloft LC SC Broad Spectrum Liquid Insecticide",
    "category": "Insecticide",
    "price": 675.3,
    "unit": "64 fl oz bottle",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "10824440",
    "name": "Arena S.E. Insecticide",
    "category": "Insecticide",
    "price": 411.8,
    "unit": "2.5 lb",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "11008364-NLA",
    "name": "LESCO Crosscheck Plus Liquid Insecticide",
    "category": "Insecticide",
    "price": 30.24,
    "unit": "1 gal",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "113575",
    "name": "LESCO-Wet Plus Nonionic Wetting Agent",
    "category": "Soil",
    "price": 73.56,
    "unit": "2.5 gal",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "1235445",
    "name": "LESCO Handheld Spreader w/ 5 lb Capacity",
    "category": "Equipment",
    "price": 29.99,
    "unit": "ea",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "190344",
    "name": "LESCO No-Leak Backpack Sprayer Piston Pump 4 gal",
    "category": "Equipment",
    "price": 99.0,
    "unit": "ea",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "190593",
    "name": "LESCO Elite 18V Zero Pump Fixed Pressure Backpack Sprayer",
    "category": "Equipment",
    "price": 239.47,
    "unit": "ea",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "190723",
    "name": "LESCO 18V Variable Flow Zero Pump Backpack Sprayer",
    "category": "Equipment",
    "price": 249.24,
    "unit": "ea",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "23014BRN025",
    "name": "BRANDT Agra Sol Micro Mix",
    "category": "Nutrient",
    "price": 83.54,
    "unit": "25 lb bag",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://brandt.co/product-finder-app/",
    "officialLabelUrl": "https://brandt.co/product-finder-app/",
    "active": "",
    "warning": ""
  },
  {
    "sku": "49023BRN100",
    "name": "Brandt Seaweed Max",
    "category": "Bio",
    "price": 81.5,
    "unit": "2.5 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://brandt.co/product-finder-app/",
    "officialLabelUrl": "https://brandt.co/product-finder-app/",
    "active": "",
    "warning": ""
  },
  {
    "sku": "510017FUNG",
    "name": "Artavia 2 SC (Azoxy) Liquis Fungicide",
    "category": "Fungicide",
    "price": 135.0,
    "unit": "1 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://atticusllc.com/ecocore-products/atticus-artavia-2-sc/",
    "officialLabelUrl": "https://atticusllc.com/ecocore-products/atticus-artavia-2-sc/",
    "active": "",
    "warning": ""
  },
  {
    "sku": "510268",
    "name": "LESCO 8-2-12 100% Poly Plus OPTI Kieserite",
    "category": "Nutrient",
    "price": 37.62,
    "unit": "50 lb bag",
    "npk": "8-2-12",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "510311",
    "name": "LESCO Green Flo Phyte Plus + Micros",
    "category": "Nutrient",
    "price": 89.86,
    "unit": "2.5 gal",
    "npk": "0-0-26",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "510680",
    "name": "Cytogro Liquid Fertilizer Hormone Biostimulant",
    "category": "Bio",
    "price": 124.23,
    "unit": "1 gal",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "510894-2.5",
    "name": "LESCO CarbonPro-L w/ MobilEX",
    "category": "Soil",
    "price": 331.25,
    "unit": "2.5 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "510971",
    "name": "LESCO 46-0-0 100% NOS AM Turfgrass Soluble Fertilizer",
    "category": "Nutrient",
    "price": 34.52,
    "unit": "50 lb bag",
    "npk": "46-0-0",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511362-2.5",
    "name": "LESCO 13-0-0 Spar-TECH 6%Fe 1%Mn Liquid Fertilizer",
    "category": "Nutrient",
    "price": 68.95,
    "unit": "2.5 gal jug",
    "npk": "13-0-0",
    "notes": "Source: SiteOne quote 8346402. Item note: 1-2 oz per 1000.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511371",
    "name": "LESCO 21-0-6 Spar-TECH Turfgrass Granular Fertilizer",
    "category": "Nutrient",
    "price": 23.24,
    "unit": "50 lb bag",
    "npk": "21-0-6",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511380-2.5",
    "name": "LESCO 0-0-4 Spar-TECH 2.1%Mg 5.2%S",
    "category": "Nutrient",
    "price": 57.79,
    "unit": "2.5 gal jug",
    "npk": "0-0-4",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511403-2.5",
    "name": "LESCO Micro Mix Spar-TECH Turfgrass & Ornamental Liquid Micronutrient",
    "category": "Nutrient",
    "price": 80.83,
    "unit": "2.5 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511426",
    "name": "LESCO 18-0-18 65% PolyPlus OPTI Spar-TECH",
    "category": "Nutrient",
    "price": 31.96,
    "unit": "50 lb bag",
    "npk": "18-0-18",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511434-2.5",
    "name": "LESCO BioActivator Spar-TECH",
    "category": "Bio",
    "price": 149.0,
    "unit": "2.5 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511493-2.5",
    "name": "LESCO Bio Iron Plus Spar-TECH",
    "category": "Bio",
    "price": 79.74,
    "unit": "2.5 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511512",
    "name": "LESCO Black Out AMSpar-TECH",
    "category": "Nutrient",
    "price": 24.05,
    "unit": "50 lb bag",
    "npk": "0-0-24",
    "notes": "Source: SiteOne quote 8346402. Item note on one listing: spreadable only.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511525",
    "name": "LESCO 20-0-10 50% PolyPlus OPTI45 25% AS",
    "category": "Nutrient",
    "price": 19.71,
    "unit": "50 lb bag",
    "npk": "20-0-10",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511543",
    "name": "LESCO 8-0-10 Palm & Tropical Ornamental Fertilizer",
    "category": "Nutrient",
    "price": 17.65,
    "unit": "50 lb bag",
    "npk": "8-0-10",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511544",
    "name": "LESCO 8-10-10 Palm & Tropical Ornamental Fertilizer",
    "category": "Nutrient",
    "price": 20.59,
    "unit": "50 lb bag",
    "npk": "8-10-10",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511621",
    "name": "LESCO 19-19-19 AM Spar-TECH + Micros",
    "category": "Nutrient",
    "price": 34.75,
    "unit": "25 lb bag",
    "npk": "19-19-19",
    "notes": "Source: SiteOne quote 8346402. Item note: better performing than 20-20-20 due to SparTech.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511697",
    "name": "LESCO 32-0-8 30% PolyPlus OPTI Spar-TECH",
    "category": "Nutrient",
    "price": 32.81,
    "unit": "50 lb bag",
    "npk": "32-0-8",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "511716-2.5",
    "name": "LESCO 28-0-0 UAN Spar-TECH 0.25% Fe 0.25% Mn",
    "category": "Nutrient",
    "price": 51.72,
    "unit": "2.5 gal jug",
    "npk": "28-0-0",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "57004",
    "name": "BioPro EnviroPlex Soil Conditioner",
    "category": "Soil",
    "price": 56.28,
    "unit": "2.5 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "59011636",
    "name": "Basagran T&O Post Emergent Liquid Herbicide",
    "category": "Herbicide",
    "price": 58.49,
    "unit": "1 gal",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "59012784",
    "name": "Pillar G Intrinsic Fungicide",
    "category": "Fungicide",
    "price": 113.21,
    "unit": "30 lb",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "59026395",
    "name": "BASF Pillar SC Intrinsic Brand Fungicide",
    "category": "Fungicide",
    "price": 213.6,
    "unit": "43.5 oz",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "59030455",
    "name": "Drive XLR8 Post Emergent Liquid Herbicide",
    "category": "Herbicide",
    "price": 59.82,
    "unit": "64 oz",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "6020408",
    "name": "MANZATE MAX T&O Fungicide",
    "category": "Fungicide",
    "price": 135.84,
    "unit": "2.5 gal",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "64182N",
    "name": "Provaunt WDG Insecticide",
    "category": "Insecticide",
    "price": 468.0,
    "unit": "72 oz",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "702463",
    "name": "LESCO Quin-Way 1.5 L Post-Emergent Liquid Herbicide",
    "category": "Herbicide",
    "price": 56.1,
    "unit": "64 oz bottle",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "71680",
    "name": "Recognition Post Emergent Herbicide",
    "category": "Herbicide",
    "price": 177.45,
    "unit": "1.95 oz bottle",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "73215",
    "name": "Fusilade II Fluazifop-P-Butyl Post Emergent Liquid Herbicide",
    "category": "Herbicide",
    "price": 91.12,
    "unit": "32 fl oz bottle",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "76804",
    "name": "LESCO Spectator Ultra Systemic Liquid Fungicide",
    "category": "Fungicide",
    "price": 77.83,
    "unit": "1 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "80113",
    "name": "Atexzo Insecticide/Miticide",
    "category": "Insecticide",
    "price": 937.5,
    "unit": "0.5 gal",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "8100FUNG",
    "name": "KPHITE 7LP Systemic Fungicide",
    "category": "Fungicide",
    "price": 87.68,
    "unit": "2.5 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "87198",
    "name": "Trefinti Nematicide/Fungicide",
    "category": "Insecticide",
    "price": 1296.9,
    "unit": "33 oz",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "8731126",
    "name": "Avenue South Post Emergent Liquid Herbicide",
    "category": "Herbicide",
    "price": 237.5,
    "unit": "2.5 gal",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "8732176",
    "name": "LESCO Momentum Southern Post Emergent Liquid Herbicide",
    "category": "Herbicide",
    "price": 237.5,
    "unit": "2.5 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402. Item note: SiteOne private label Avenue South.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "D00000906",
    "name": "LESCO Bandit 2F Systemic Liquid Insecticide",
    "category": "Insecticide",
    "price": 45.23,
    "unit": "1 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402. Item note: Private label, not generic.",
    "officialPageUrl": "https://www.lesco.com/sds-label-search",
    "officialLabelUrl": "https://www.lesco.com/sds-label-search",
    "active": "",
    "warning": ""
  },
  {
    "sku": "D00000961",
    "name": "Merit 2F Insecticide",
    "category": "Insecticide",
    "price": 83.24,
    "unit": "1 gal",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "D00000991",
    "name": "Envu Specticle Flo Pre-Emergent Liquid Herbicide",
    "category": "Herbicide",
    "price": 325.18,
    "unit": "18 oz",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "D00001204",
    "name": "Celsius WG Post Emergent Water Dispersible Granule Herbicide",
    "category": "Herbicide",
    "price": 131.2,
    "unit": "10 oz",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "https://www.cropscience.bayer.us/products/herbicides/celsius-wg",
    "officialLabelUrl": "https://www.cropscience.bayer.us/labels",
    "active": "",
    "warning": ""
  },
  {
    "sku": "F0142",
    "name": "Live Earth Liquid Soil Conditioner",
    "category": "Soil",
    "price": 31.79,
    "unit": "2.5 gal jug",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "F0A0041-002500",
    "name": "Revolution Surfactant",
    "category": "Soil",
    "price": 323.0,
    "unit": "2.5 gal",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "F0A0043-002500",
    "name": "Aquatrols Sixteen 90 Surfactant",
    "category": "Soil",
    "price": 190.18,
    "unit": "2.5 gal container",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "FZVAAK-3",
    "name": "Flowzone Typhoon Variable Pressure Sprayer 3.0 - 4 gal 18V",
    "category": "Equipment",
    "price": 329.99,
    "unit": "ea",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "LA-HESP2.5",
    "name": "Ecologel Hydretain Liquid Humectant",
    "category": "Soil",
    "price": 164.33,
    "unit": "2.5 gal",
    "npk": "",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "MP50POT",
    "name": "Diamond K UltraFines 0-0-50 100% SOP",
    "category": "Nutrient",
    "price": 42.94,
    "unit": "50 lb bag",
    "npk": "0-0-50",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  },
  {
    "sku": "URE50BIU",
    "name": "Nutrien 46-0-0 Urea Agricultural Grade Microprill",
    "category": "Nutrient",
    "price": 27.85,
    "unit": "50 lb bag",
    "npk": "46-0-0",
    "notes": "Source: SiteOne quote 8346402.",
    "officialPageUrl": "",
    "officialLabelUrl": "",
    "active": "",
    "warning": ""
  }
];
const PRELOADED_CATALOG_PRODUCTS = [
  {
    "id": "siteone-001482",
    "name": "Ferrous Sulfate Micronutrient 20%Fe Sprayable",
    "sku": "001482",
    "price": 21.46,
    "notes": "Source: SiteOne quote 8346402. Item note: Currently a shortage, I recommend 13-0-0 non staining below.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-018300",
    "name": "Magnesium Sulfate (Epsom Salt) AG Grade",
    "sku": "018300",
    "price": 21.57,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-080-57622",
    "name": "BioPro Bio MP",
    "sku": "080-57622",
    "price": 65.59,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "5-3-2",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-084043",
    "name": "LESCO Chelated Iron Plus",
    "sku": "084043",
    "price": 27.7,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "12-0-0",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-089075",
    "name": "LESCO Moisture Manager",
    "sku": "089075",
    "price": 101.19,
    "notes": "Source: SiteOne quote 8346402. Item note: Private label Hydretain.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-089801",
    "name": "LESCO Moisture Manager Hygroscopic Humectant Soil Conditioner",
    "sku": "089801",
    "price": 56.18,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "40 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-098186",
    "name": "LESCO Chelated AM + Micros",
    "sku": "098186",
    "price": 28.37,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-098504",
    "name": "LESCO K-Flow 0-0-25",
    "sku": "098504",
    "price": 29.49,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "0-0-25",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-098604",
    "name": "LESCO 24-0-11 75% PolyPlus OPTI",
    "sku": "098604",
    "price": 26.98,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "24-0-11",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-101186",
    "name": "LESCO Broadcast Spreader w/ 80 lb Capacity and Stainless Steel Frame",
    "sku": "101186",
    "price": 698.0,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "equipment",
    "unit_type": "",
    "pack_size": "ea",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-10441225",
    "name": "LESCO T-Storm Flowable Thiophanate-Methyl 46.2",
    "sku": "10441225",
    "price": 119.41,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-10580032",
    "name": "Nufarm Arena 0.25G Clothianidin 0.25 Systemic Granular Insecticide",
    "sku": "10580032",
    "price": 70.5,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "30 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-10594403",
    "name": "Safari 20 SG Insecticide",
    "sku": "10594403",
    "price": 409.05,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "3 lb",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-10669032",
    "name": "Aloft LC G Insecticide",
    "sku": "10669032",
    "price": 70.5,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "30 lb",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-10677464",
    "name": "Aloft LC SC Broad Spectrum Liquid Insecticide",
    "sku": "10677464",
    "price": 675.3,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "64 fl oz bottle",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-10824440",
    "name": "Arena S.E. Insecticide",
    "sku": "10824440",
    "price": 411.8,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 lb",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-11008364-nla",
    "name": "LESCO Crosscheck Plus Liquid Insecticide",
    "sku": "11008364-NLA",
    "price": 30.24,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "1 gal",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-113575",
    "name": "LESCO-Wet Plus Nonionic Wetting Agent",
    "sku": "113575",
    "price": 73.56,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-1235445",
    "name": "LESCO Handheld Spreader w/ 5 lb Capacity",
    "sku": "1235445",
    "price": 29.99,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "equipment",
    "unit_type": "",
    "pack_size": "ea",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-190344",
    "name": "LESCO No-Leak Backpack Sprayer Piston Pump 4 gal",
    "sku": "190344",
    "price": 99.0,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "equipment",
    "unit_type": "",
    "pack_size": "ea",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-190593",
    "name": "LESCO Elite 18V Zero Pump Fixed Pressure Backpack Sprayer",
    "sku": "190593",
    "price": 239.47,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "equipment",
    "unit_type": "",
    "pack_size": "ea",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-190723",
    "name": "LESCO 18V Variable Flow Zero Pump Backpack Sprayer",
    "sku": "190723",
    "price": 249.24,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "equipment",
    "unit_type": "",
    "pack_size": "ea",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-23014brn025",
    "name": "BRANDT Agra Sol Micro Mix",
    "sku": "23014BRN025",
    "price": 83.54,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "25 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-49023brn100",
    "name": "Brandt Seaweed Max",
    "sku": "49023BRN100",
    "price": 81.5,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-510017fung",
    "name": "Artavia 2 SC (Azoxy) Liquis Fungicide",
    "sku": "510017FUNG",
    "price": 135.0,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "1 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-510268",
    "name": "LESCO 8-2-12 100% Poly Plus OPTI Kieserite",
    "sku": "510268",
    "price": 37.62,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "8-2-12",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-510311",
    "name": "LESCO Green Flo Phyte Plus + Micros",
    "sku": "510311",
    "price": 89.86,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "0-0-26",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-510680",
    "name": "Cytogro Liquid Fertilizer Hormone Biostimulant",
    "sku": "510680",
    "price": 124.23,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "1 gal",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-510894-2.5",
    "name": "LESCO CarbonPro-L w/ MobilEX",
    "sku": "510894-2.5",
    "price": 331.25,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-510971",
    "name": "LESCO 46-0-0 100% NOS AM Turfgrass Soluble Fertilizer",
    "sku": "510971",
    "price": 34.52,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "46-0-0",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511362-2.5",
    "name": "LESCO 13-0-0 Spar-TECH 6%Fe 1%Mn Liquid Fertilizer",
    "sku": "511362-2.5",
    "price": 68.95,
    "notes": "Source: SiteOne quote 8346402. Item note: 1-2 oz per 1000.",
    "npk": "13-0-0",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511371",
    "name": "LESCO 21-0-6 Spar-TECH Turfgrass Granular Fertilizer",
    "sku": "511371",
    "price": 23.24,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "21-0-6",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511380-2.5",
    "name": "LESCO 0-0-4 Spar-TECH 2.1%Mg 5.2%S",
    "sku": "511380-2.5",
    "price": 57.79,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "0-0-4",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511403-2.5",
    "name": "LESCO Micro Mix Spar-TECH Turfgrass & Ornamental Liquid Micronutrient",
    "sku": "511403-2.5",
    "price": 80.83,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511426",
    "name": "LESCO 18-0-18 65% PolyPlus OPTI Spar-TECH",
    "sku": "511426",
    "price": 31.96,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "18-0-18",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511434-2.5",
    "name": "LESCO BioActivator Spar-TECH",
    "sku": "511434-2.5",
    "price": 149.0,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511493-2.5",
    "name": "LESCO Bio Iron Plus Spar-TECH",
    "sku": "511493-2.5",
    "price": 79.74,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511512",
    "name": "LESCO Black Out AMSpar-TECH",
    "sku": "511512",
    "price": 24.05,
    "notes": "Source: SiteOne quote 8346402. Item note on one listing: spreadable only.",
    "npk": "0-0-24",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511525",
    "name": "LESCO 20-0-10 50% PolyPlus OPTI45 25% AS",
    "sku": "511525",
    "price": 19.71,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "20-0-10",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511543",
    "name": "LESCO 8-0-10 Palm & Tropical Ornamental Fertilizer",
    "sku": "511543",
    "price": 17.65,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "8-0-10",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511544",
    "name": "LESCO 8-10-10 Palm & Tropical Ornamental Fertilizer",
    "sku": "511544",
    "price": 20.59,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "8-10-10",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511621",
    "name": "LESCO 19-19-19 AM Spar-TECH + Micros",
    "sku": "511621",
    "price": 34.75,
    "notes": "Source: SiteOne quote 8346402. Item note: better performing than 20-20-20 due to SparTech.",
    "npk": "19-19-19",
    "category": "materials",
    "unit_type": "",
    "pack_size": "25 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511697",
    "name": "LESCO 32-0-8 30% PolyPlus OPTI Spar-TECH",
    "sku": "511697",
    "price": 32.81,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "32-0-8",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-511716-2.5",
    "name": "LESCO 28-0-0 UAN Spar-TECH 0.25% Fe 0.25% Mn",
    "sku": "511716-2.5",
    "price": 51.72,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "28-0-0",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-57004",
    "name": "BioPro EnviroPlex Soil Conditioner",
    "sku": "57004",
    "price": 56.28,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-59011636",
    "name": "Basagran T&O Post Emergent Liquid Herbicide",
    "sku": "59011636",
    "price": 58.49,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "1 gal",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-59012784",
    "name": "Pillar G Intrinsic Fungicide",
    "sku": "59012784",
    "price": 113.21,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "30 lb",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-59026395",
    "name": "BASF Pillar SC Intrinsic Brand Fungicide",
    "sku": "59026395",
    "price": 213.6,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "43.5 oz",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-59030455",
    "name": "Drive XLR8 Post Emergent Liquid Herbicide",
    "sku": "59030455",
    "price": 59.82,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "64 oz",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-6020408",
    "name": "MANZATE MAX T&O Fungicide",
    "sku": "6020408",
    "price": 135.84,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-64182n",
    "name": "Provaunt WDG Insecticide",
    "sku": "64182N",
    "price": 468.0,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "72 oz",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-702463",
    "name": "LESCO Quin-Way 1.5 L Post-Emergent Liquid Herbicide",
    "sku": "702463",
    "price": 56.1,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "64 oz bottle",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-71680",
    "name": "Recognition Post Emergent Herbicide",
    "sku": "71680",
    "price": 177.45,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "1.95 oz bottle",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-73215",
    "name": "Fusilade II Fluazifop-P-Butyl Post Emergent Liquid Herbicide",
    "sku": "73215",
    "price": 91.12,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "32 fl oz bottle",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-76804",
    "name": "LESCO Spectator Ultra Systemic Liquid Fungicide",
    "sku": "76804",
    "price": 77.83,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "1 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-80113",
    "name": "Atexzo Insecticide/Miticide",
    "sku": "80113",
    "price": 937.5,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "0.5 gal",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-8100fung",
    "name": "KPHITE 7LP Systemic Fungicide",
    "sku": "8100FUNG",
    "price": 87.68,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-87198",
    "name": "Trefinti Nematicide/Fungicide",
    "sku": "87198",
    "price": 1296.9,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "33 oz",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-8731126",
    "name": "Avenue South Post Emergent Liquid Herbicide",
    "sku": "8731126",
    "price": 237.5,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-8732176",
    "name": "LESCO Momentum Southern Post Emergent Liquid Herbicide",
    "sku": "8732176",
    "price": 237.5,
    "notes": "Source: SiteOne quote 8346402. Item note: SiteOne private label Avenue South.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-d00000906",
    "name": "LESCO Bandit 2F Systemic Liquid Insecticide",
    "sku": "D00000906",
    "price": 45.23,
    "notes": "Source: SiteOne quote 8346402. Item note: Private label, not generic.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "1 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-d00000961",
    "name": "Merit 2F Insecticide",
    "sku": "D00000961",
    "price": 83.24,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "1 gal",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-d00000991",
    "name": "Envu Specticle Flo Pre-Emergent Liquid Herbicide",
    "sku": "D00000991",
    "price": 325.18,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "18 oz",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-d00001204",
    "name": "Celsius WG Post Emergent Water Dispersible Granule Herbicide",
    "sku": "D00001204",
    "price": 131.2,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "10 oz",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-f0142",
    "name": "Live Earth Liquid Soil Conditioner",
    "sku": "F0142",
    "price": 31.79,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal jug",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-f0a0041-002500",
    "name": "Revolution Surfactant",
    "sku": "F0A0041-002500",
    "price": 323.0,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-f0a0043-002500",
    "name": "Aquatrols Sixteen 90 Surfactant",
    "sku": "F0A0043-002500",
    "price": 190.18,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal container",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-fzvaak-3",
    "name": "Flowzone Typhoon Variable Pressure Sprayer 3.0 - 4 gal 18V",
    "sku": "FZVAAK-3",
    "price": 329.99,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "equipment",
    "unit_type": "",
    "pack_size": "ea",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-la-hesp2.5",
    "name": "Ecologel Hydretain Liquid Humectant",
    "sku": "LA-HESP2.5",
    "price": 164.33,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "",
    "category": "materials",
    "unit_type": "",
    "pack_size": "2.5 gal",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-mp50pot",
    "name": "Diamond K UltraFines 0-0-50 100% SOP",
    "sku": "MP50POT",
    "price": 42.94,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "0-0-50",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  },
  {
    "id": "siteone-ure50biu",
    "name": "Nutrien 46-0-0 Urea Agricultural Grade Microprill",
    "sku": "URE50BIU",
    "price": 27.85,
    "notes": "Source: SiteOne quote 8346402.",
    "npk": "46-0-0",
    "category": "materials",
    "unit_type": "",
    "pack_size": "50 lb bag",
    "source_type": "pdf",
    "source_file": "Bid 8346402.pdf",
    "source_vendor": "SiteOne",
    "source_quote_number": "8346402"
  }
];
const specialsCatalog = [
  { key:"newSod", name:"New Sod Establishment Protection", description:"Protective, biological, and rooting-oriented support for new turf establishment.", mode:"manual", defaultPrice:175 },
  { key:"salinity", name:"Salinity Remediation", description:"Leaching, carbon support, and chemistry designed to improve root-zone performance in saline conditions.", mode:"manual", defaultPrice:250 },
  { key:"hydretain", name:"Hydretain Moisture Management", description:"Moisture-efficiency support to stretch irrigation performance and reduce stress swings.", mode:"manual", defaultPrice:250 },
  { key:"regulator", name:"Growth Regulation Program", description:"Plant growth regulation to improve density, control flush growth, and refine performance.", mode:"manual", defaultPrice:250 },
  { key:"fireAnt", name:"Fire Ant Treatment", description:"Targeted fire ant management as an additional quoted service.", mode:"manual", defaultPrice:350 },
  { key:"oakInvigoration", name:"Oak Tree Root Invigoration", description:"DBH-priced root-zone invigoration for oaks, generated by diameter and tree count.", mode:"oak", defaultPrice:0 },
  { key:"palmInjection", name:"Palm Injections", description:"Height-based palm injection pricing using quantity in each height class.", mode:"palm", defaultPrice:0 },
  { key:"deepRoot", name:"Deep Root Feeding", description:"Quoted or per-tree deep root feeding for trees and large shrubs.", mode:"manual", defaultPrice:0 }
];
function buildDefaultSpecialPrograms(){
  return Object.fromEntries(specialsCatalog.map(s=>[
    s.key,
    {
      [`special_${s.key}_base`]:{
        name:`${s.name} Program`,
        treatmentKey:s.key,
        tankCoverageSqft:60000,
        lines:[]
      }
    }
  ]));
}
const defaultSpecialPrograms = buildDefaultSpecialPrograms();
const defaultSelectedSpecialPrograms = Object.fromEntries(specialsCatalog.map(s=>[s.key, `special_${s.key}_base`]));
const defaultDeletedBuiltInSpecialPrograms = Object.fromEntries(specialsCatalog.map(s=>[s.key, []]));
const defaultPrograms = {
  april:{ name:"2026 April Turf Program", tankCoverageSqft:60000, lines:[
    { sku:"510971", rate:12, unit:"lb per 150-gal tank" },
    { sku:"SOP", rate:10, unit:"lb per 150-gal tank" },
    { sku:"23014BRN025", rate:2.5, unit:"lb per 150-gal tank" },
    { sku:"084043", rate:32, unit:"oz per 150-gal tank" },
    { sku:"SOIL", rate:32, unit:"oz per 150-gal tank" },
    { sku:"SEAWEED", rate:16, unit:"oz per 150-gal tank" }
  ]},
  may:{ name:"2026 May Turf Program", tankCoverageSqft:60000, lines:[
    { sku:"510971", rate:15, unit:"lb per 150-gal tank" },
    { sku:"SOP", rate:14, unit:"lb per 150-gal tank" },
    { sku:"23014BRN025", rate:2.5, unit:"lb per 150-gal tank" },
    { sku:"084043", rate:32, unit:"oz per 150-gal tank" },
    { sku:"SOIL", rate:32, unit:"oz per 150-gal tank" },
    { sku:"BANDIT", rate:34, unit:"oz per 150-gal tank" },
    { sku:"CROSSCHECK", rate:24, unit:"oz per 150-gal tank" }
  ]}
};
const defaultOrnamentalPrograms = {
  orn_april:{ name:"2026 April Ornamental Program", tankCoverageSqft:10000, lines:[
    { sku:"084043", rate:48, unit:"oz per 150-gal tank" },
    { sku:"SOIL", rate:64, unit:"oz per 150-gal tank" },
    { sku:"SEAWEED", rate:32, unit:"oz per 150-gal tank" },
    { sku:"23014BRN025", rate:3, unit:"lb per 150-gal tank" }
  ]},
  orn_may:{ name:"2026 May Ornamental Program", tankCoverageSqft:10000, lines:[
    { sku:"084043", rate:48, unit:"oz per 150-gal tank" },
    { sku:"SOIL", rate:64, unit:"oz per 150-gal tank" },
    { sku:"SEAWEED", rate:32, unit:"oz per 150-gal tank" },
    { sku:"BIOACT", rate:24, unit:"oz per 150-gal tank" },
    { sku:"BANDIT", rate:24, unit:"oz per 150-gal tank" }
  ]}
};
const facts = [
  "Rhizosphere pH manipulation can change nutrient solubility and transport across the soil-root interface.",
  "Chelation can preserve micronutrient availability in solution long enough to improve uptake efficiency.",
  "Potassium supports osmotic regulation, stomatal behavior, and stress buffering.",
  "Carbon-based inputs can influence microbial activity and nutrient cycling within the root zone.",
  "Plant response quality depends on transport and signaling efficiency, not just total nutrient loading.",
  "Stress reducers and hormonal inputs can improve response continuity under heat and salinity.",
  "Nutrient-use efficiency often improves more from timing and access than from simply increasing the rate."
];
function blankQuote(){
  return {
    customer:"", address:"", phone:"", email:"",
    turfSqft:5000, ornamentalSqft:3000, ornamentalDensity:"medium", palmCount:8,
    notes:"", customNotes:"", includeBlurb:true, manualDiscountPct:0,
    services:{
      turf:{selected:true, description:"Recurring turf nutrition, soil support, and targeted pest and disease management.", notes:""},
      ornamental:{selected:true, description:"Recurring ornamental and shrub care with fertility, biological, and targeted intervention support.", notes:""},
      palm:{selected:true, description:"Recurring palm program with nutrient and plant health support. $4 per palm per month with a $25 monthly minimum.", notes:""}
    },
    specials:Object.fromEntries(specialsCatalog.map(s=>[s.key,{selected:false,price:s.defaultPrice,notes:"",dbh:"",palmHeights:{upTo15:0,ft15to30:0,ft30to45:0,ft45plus:0}}]))
  };
}
const LEGACY_SKU_ALIASES = {
  SOP:"23014BRN025",
  SOIL:"F0142",
  SEAWEED:"49023BRN100",
  BANDIT:"D00000906",
  CROSSCHECK:"11008364-NLA",
  BIOACT:"511434-2.5"
};
function withLegacyAliases(labels){
  const out = {...labels};
  Object.entries(LEGACY_SKU_ALIASES).forEach(([alias, target])=>{
    if(out[alias]) return;
    const base = out[target];
    if(base) out[alias] = {...base, sku:alias, aliasFor:target};
  });
  return out;
}
const defaultState = {
  view:"dashboard",
  builderMode:"turf",
  selectedProgram:"april",
  selectedOrnamentalProgram:"orn_april",
  selectedSpecialTreatment:"newSod",
  selectedSpecialPrograms:structuredClone(defaultSelectedSpecialPrograms),
  turf:"staug",
  soilTemp:"",
  lastDailyRefresh:"",
  labels:withLegacyAliases(Object.fromEntries(products.map(p=>[p.sku,{...p}]))),
  programs:defaultPrograms,
  ornamentalPrograms:defaultOrnamentalPrograms,
  specialPrograms:structuredClone(defaultSpecialPrograms),
  currentQuote:blankQuote(),
  history:[],
  vendorCatalog:{materials:[], equipment:[], other:[]},
  catalogState:{products:PRELOADED_CATALOG_PRODUCTS, lastSelectedProductId:""},
  importState:{batch:null, stagingRows:[], warnings:[], duplicateMatches:[]},
  validationState:{lastAuditAt:"", lastView:"dashboard"},
  regressionState:{activeScenario:"", lastAppliedAt:""},
  specialTreatmentState:{treatments:{}, linkedProductIds:{}},
  actualSell:{turfPer1000:"", ornamentalPer1000:"", palmPerUnit:"", specialsPer1000:""},
  margins:{turf:45, ornamental:50, palm:55, specials:60},
  manualSales:[],
  forecasts:{properties:1, avgTurfSqft:5000, avgOrnSqft:3000, avgPalmCount:8, avgSpecialSqft:3000},
  orderSheetDraft:[],
  labelCenter:{query:"", sort:"name", onlyWithLabels:false},
  deletedBuiltInPrograms:[],
  deletedBuiltInOrnamentalPrograms:[],
  deletedBuiltInSpecialPrograms:structuredClone(defaultDeletedBuiltInSpecialPrograms),
  orderBuilder:{sku:"", qty:1},
  orderPurchaseMode:"target",
  includeStockedReorderInOrderSheet:false,
  orderCatalogFilter:"all",
  catalogSearch:"",
  orderSheetSearch:"",
  programLineEditors:{turf:{}, ornamental:{}, specials:{}},
  programProductSearch:{turf:"", ornamental:"", special:""},
  appMeta:{lastSavedAt:"", lastBackupAt:"", lastRestoreAt:"", lastAutoBackupAt:""},
  settings:{autoBackupOnSave:false}
};
function emptyCatalog(){ return {materials:[], equipment:[], other:[]}; }
function inferNpk(value){
  const match = String(value||"").match(/(\d{1,2}-\d{1,2}-\d{1,2})/);
  return match ? match[1] : "";
}
function productLabel(product){
  if(!product) return "";
  const npk = product.npk || inferNpk(product.name) || inferNpk(product.notes);
  return npk ? `${product.name} (${npk})` : product.name;
}

function normalizedProgramProductSearch(state, mode){
  const key = mode === "ornamental" ? "ornamental" : mode === "special" ? "special" : "turf";
  return String((state.programProductSearch || {})[key] || "").trim().toLowerCase();
}
function filteredProgramProducts(state, mode){
  const q = normalizedProgramProductSearch(state, mode);
  const products = Object.values(state.labels || {});
  if(!q) return products;
  return products.filter(p=>{
    const hay = [p.sku, p.name, p.active, p.function, p.notes, p.npk].map(v=>String(v||"").toLowerCase()).join(" ");
    return hay.includes(q);
  });
}
function builderSearchKey(mode){
  return mode === "ornamental" ? "ornamental" : mode === "special" ? "special" : "turf";
}
function refreshBuilderProductSelect(state, mode){
  const select = document.getElementById("newLineProduct");
  const search = document.getElementById("newLineProductSearch");
  if(!select) return;
  const products = filteredProgramProducts(state, mode);
  const currentSku = String((state.orderBuilder||{}).sku || select.value || '').trim();
  select.innerHTML = `<option value="">Select product</option>${products.map(p=>`<option value="${p.sku}" ${currentSku===p.sku?'selected':''}>${productLabel(p)}</option>`).join("")}`;
  if(currentSku && !products.some(p=>String(p.sku)===currentSku)){
    select.value = "";
    state.orderBuilder = {...(state.orderBuilder||{}), sku:""};
  }
  const countEl = search ? search.parentElement?.querySelector('.small') : null;
  if(countEl) countEl.textContent = `${products.length} match(es) in product selection.`;
}
function restoreBuilderSearchFocus(){
  const info = window.__paFocus;
  if(!info || info.id !== 'newLineProductSearch') return;
  const el = document.getElementById(info.id);
  if(!el) return;
  el.focus();
  try{ el.setSelectionRange(info.start ?? el.value.length, info.end ?? el.value.length); }catch(err){}
}
function rememberInputFocus(el){
  if(!el || !el.id) return;
  window.__paFocus = {id:el.id, start:el.selectionStart, end:el.selectionEnd};
}
function isPdfDataUrl(value){
  return String(value||'').startsWith('data:application/pdf');
}
function lineCarrier(line){
  return String(line && line.unit || '').includes(' per ') ? String(line.unit).split(' per ')[1] : '150-gal tank';
}
function lineUnitOnly(line){
  return String(line && line.unit || '').split(' per ')[0] || 'oz';
}
function composeLineUnit(unitOnly, carrier){
  return `${unitOnly || 'oz'} per ${carrier || '150-gal tank'}`;
}
function builderLineDraftBucket(mode){
  window.__paLineDrafts = window.__paLineDrafts || {turf:{}, ornamental:{}, special:{}};
  const key = mode === 'ornamental' ? 'ornamental' : mode === 'special' ? 'special' : 'turf';
  window.__paLineDrafts[key] = window.__paLineDrafts[key] || {};
  return window.__paLineDrafts[key];
}
function builderLineDraftValue(mode, idx, field, fallback){
  const bucket = builderLineDraftBucket(mode);
  if(bucket[idx] && Object.prototype.hasOwnProperty.call(bucket[idx], field)) return bucket[idx][field];
  return fallback;
}
function setBuilderLineDraftValue(mode, idx, field, value){
  const bucket = builderLineDraftBucket(mode);
  bucket[idx] = bucket[idx] || {};
  bucket[idx][field] = value;
}
function clearBuilderLineDraft(mode, idx){
  const bucket = builderLineDraftBucket(mode);
  delete bucket[idx];
}
function remapBuilderLineDrafts(mode, removedIdx){
  const key = mode === 'ornamental' ? 'ornamental' : mode === 'special' ? 'special' : 'turf';
  const bucket = builderLineDraftBucket(mode);
  const next = {};
  Object.keys(bucket).forEach(oldKey=>{
    const n = Number(oldKey);
    if(Number.isNaN(n)) return;
    if(n < removedIdx) next[String(n)] = bucket[oldKey];
    else if(n > removedIdx) next[String(n-1)] = bucket[oldKey];
  });
  window.__paLineDrafts[key] = next;
}
function commitProgramLineField(state, idx, updater, mode){
  const active = activeProgramRecord(state, mode || state.builderMode);
  if(!active || !active.lines || !active.lines[idx]) return false;
  updater(active.lines[idx]);
  saveState(state);
  return true;
}
function flushProgramLineEditors(state, mode){
  const useMode = mode || state.builderMode;
  const active = activeProgramRecord(state, useMode);
  if(!active || !Array.isArray(active.lines)) return false;
  let changed = false;
  document.querySelectorAll('[data-line-rate]').forEach(el=>{
    const idx = Number(el.dataset.lineRate);
    if(!active.lines[idx]) return;
    const next = Number(el.value || 0);
    if(Number(active.lines[idx].rate || 0) !== next){
      active.lines[idx].rate = next;
      changed = true;
    }
  });
  document.querySelectorAll('[data-line-uom]').forEach(el=>{
    const idx = Number(el.dataset.lineUom);
    if(!active.lines[idx]) return;
    const next = composeLineUnit(el.value, lineCarrier(active.lines[idx]));
    if(String(active.lines[idx].unit || '') !== next){
      active.lines[idx].unit = next;
      changed = true;
    }
  });
  document.querySelectorAll('[data-line-carrier]').forEach(el=>{
    const idx = Number(el.dataset.lineCarrier);
    if(!active.lines[idx]) return;
    const next = composeLineUnit(lineUnitOnly(active.lines[idx]), el.value);
    if(String(active.lines[idx].unit || '') !== next){
      active.lines[idx].unit = next;
      changed = true;
    }
  });
  if(changed) saveState(state);
  return changed;
}
function restoreBuilderLineFocus(){
  const info = window.__paLineFocus;
  if(!info) return;
  const selector = info.kind === 'rate'
    ? `[data-line-rate="${info.idx}"]`
    : info.kind === 'uom'
      ? `[data-line-uom="${info.idx}"]`
      : `[data-line-carrier="${info.idx}"]`;
  const el = document.querySelector(selector);
  if(!el) return;
  el.focus();
  if(typeof el.select === 'function') el.select();
  window.__paLineFocus = null;
}
function labelPreviewHtml(product){
  if(!product || !product.labelImage) return '<div class="labelImagePlaceholder">No label file</div>';
  if(isPdfDataUrl(product.labelImage)) return `<div class="labelImageWrap hasPdf"><object data="${product.labelImage}#view=FitH&page=1" type="application/pdf" class="labelPdfPreview"><div class="labelImagePlaceholder"><div>PDF preview unavailable</div><div class="small" style="margin-top:6px">${product.labelFileName || 'Uploaded PDF label'}</div></div></object><div class="labelPdfMeta">${product.labelFileName || 'Uploaded PDF label'}</div></div>`;
  return `<img src="${product.labelImage}" alt="${product.name} label" class="labelImage">`;
}

function escapeHtml(value){
  return String(value ?? '').replace(/[&<>"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[ch]));
}
function labelCenterVisibleProducts(state){
  const prefs = {...(defaultState.labelCenter||{}), ...(state.labelCenter||{})};
  const query = String(prefs.query || '').trim().toLowerCase();
  let products = Object.values(state.labels||{}).filter(p=>p && p.name);
  if(prefs.onlyWithLabels) products = products.filter(p=>Boolean(p.labelImage));
  if(query){
    products = products.filter(p=>[
      p.name,
      p.sku,
      p.labelFileName,
      p.notes,
      p.npk
    ].filter(Boolean).some(v=>String(v).toLowerCase().includes(query)));
  }
  const sort = prefs.sort || 'name';
  const byText = (a,b,key)=>String(a?.[key]||'').localeCompare(String(b?.[key]||''));
  products = products.slice().sort((a,b)=>{
    if(sort==='sku') return byText(a,b,'sku') || byText(a,b,'name');
    if(sort==='hasLabel') return Number(Boolean(b.labelImage)) - Number(Boolean(a.labelImage)) || byText(a,b,'name');
    if(sort==='recentLabel') return Number(Boolean(b.labelImage)) - Number(Boolean(a.labelImage)) || byText(a,b,'labelFileName') || byText(a,b,'name');
    return byText(a,b,'name') || byText(a,b,'sku');
  });
  return products;
}
function labelCenterStats(state){
  const all = Object.values(state.labels||{}).filter(p=>p && p.name);
  const visible = labelCenterVisibleProducts(state);
  const uploaded = all.filter(p=>Boolean(p.labelImage)).length;
  const visibleUploaded = visible.filter(p=>Boolean(p.labelImage)).length;
  return {all, visible, uploaded, visibleUploaded};
}
function buildLabelBinderHtml(products){
  const sections = products.map((product, idx)=>{
    const title = escapeHtml(product.name || product.sku || `Label ${idx+1}`);
    const meta = [product.sku, product.npk].filter(Boolean).map(escapeHtml).join(' | ');
    const asset = isPdfDataUrl(product.labelImage||'')
      ? `<iframe src="${product.labelImage}#view=FitH&page=1" style="width:100%;height:9.6in;border:1px solid #ccc;border-radius:8px;background:#fff" title="${title}"></iframe>`
      : `<div style="border:1px solid #ccc;border-radius:8px;padding:12px;background:#fff;text-align:center"><img src="${product.labelImage}" alt="${title}" style="max-width:100%;max-height:9.6in;object-fit:contain"></div>`;
    return `<section class="binderItem"><div class="binderHead"><h2>${title}</h2><div class="binderMeta">${meta || '&nbsp;'}</div></div>${asset}</section>`;
  }).join('');
  return `<!doctype html><html><head><meta charset="utf-8"><title>Label Center SDS Binder</title><style>
    @page{size:Letter;margin:.45in}
    html,body{margin:0;padding:0;font-family:Arial,sans-serif;color:#111;background:#fff}
    .binderIntro{margin-bottom:18px}
    .binderIntro h1{margin:0 0 6px 0;font-size:26px}
    .binderIntro .sub{font-size:12px;color:#555}
    .binderItem{page-break-after:always;break-after:page}
    .binderItem:last-child{page-break-after:auto;break-after:auto}
    .binderHead{display:flex;justify-content:space-between;gap:12px;align-items:flex-end;margin:0 0 10px 0}
    .binderHead h2{margin:0;font-size:18px}
    .binderMeta{font-size:11px;color:#555;text-align:right}
  </style></head><body><div class="binderIntro"><h1>Label Center SDS Binder</h1><div class="sub">Printed from Program Architect Build 94 Operations Control Repair. Showing ${products.length} label${products.length===1?'':'s'}.</div></div>${sections}</body></html>`;
}
function printVisibleLabelsBinder(state){
  const products = labelCenterVisibleProducts(state).filter(p=>Boolean(p.labelImage));
  if(!products.length){
    alert('No visible uploaded labels to print.');
    return;
  }
  openPrint(buildLabelBinderHtml(products));
}
function safeHttpUrl(url){
  const v = String(url||'').trim();
  return /^https?:\/\//i.test(v) ? v : '';
}
function productOpenUrl(product){
  const direct = safeHttpUrl(product?.officialPageUrl) || safeHttpUrl(product?.officialLabelUrl);
  if(direct) return direct;
  const seed = [product?.sku, product?.name].filter(Boolean).join(' ').trim();
  return seed ? `https://www.google.com/search?q=${encodeURIComponent(seed)}` : '';
}

function normalizedProductKey(value){
  return String(value||'').trim().toLowerCase();
}
function catalogProductIdentifier(product){
  return String(product?.id || product?.sku || product?.name || '').trim();
}
function catalogProductsMatch(a, b){
  if(!a || !b) return false;
  const aId = normalizedProductKey(a?.product_id || a?.id);
  const bId = normalizedProductKey(b?.product_id || b?.id);
  if(aId && bId) return aId === bId;
  const aSku = normalizedProductKey(a?.sku);
  const bSku = normalizedProductKey(b?.sku);
  if(aSku && bSku) return aSku === bSku;
  const aName = normalizedProductKey(a?.name);
  const bName = normalizedProductKey(b?.name);
  return !!(aName && bName && aName === bName);
}
function findCatalogProductInList(rows, row){
  return (rows||[]).find(p=>catalogProductsMatch(p, row)) || null;
}
function resolveCatalogPrice(product){
  if(!product) return {price:0, source:'Missing product', resolved:false, missing:true, manual:false};
  const hasManual = product.manual_price !== undefined && product.manual_price !== null && product.manual_price !== '' && !Number.isNaN(Number(product.manual_price));
  if(hasManual) return {price:Number(product.manual_price), source:'Manual override', resolved:true, missing:false, manual:true};
  const hasVendor = product.vendor_price !== undefined && product.vendor_price !== null && product.vendor_price !== '' && !Number.isNaN(Number(product.vendor_price));
  if(hasVendor) return {price:Number(product.vendor_price), source:'Vendor price', resolved:true, missing:false, manual:false};
  const hasLegacy = product.price !== undefined && product.price !== null && product.price !== '' && !Number.isNaN(Number(product.price));
  if(hasLegacy) return {price:Number(product.price), source:'Catalog price', resolved:true, missing:false, manual:false};
  return {price:0, source:'Missing price', resolved:false, missing:true, manual:false};
}
function findCatalogProductForRow(state, row){
  return findCatalogProductInList(orderSheetCatalogRows(state), row);
}
function orderDraftLinkForRow(state, row){
  const direct = safeHttpUrl(row?.url);
  if(direct) return direct;
  const product = findCatalogProductForRow(state, row);
  if(product) return productOpenUrl(product);
  const seed = [row?.sku, row?.name].filter(Boolean).join(' ').trim();
  return seed ? `https://www.google.com/search?q=${encodeURIComponent(seed)}` : '';
}
function orderSheetCatalogRows(state){
  const rows = (state.catalogState?.products && state.catalogState.products.length ? state.catalogState.products : Object.values(state.labels||{})).filter(p=>p && p.name);
  return rows.slice().sort((a,b)=> String(a.name||'').localeCompare(String(b.name||'')));
}

function matchesCatalogSearch(row, query){
  const q = String(query||'').trim().toLowerCase();
  if(!q) return true;
  const hay = [row?.name, row?.sku, row?.npk, row?.notes, row?.category, row?.pack_size, row?.unit, row?.source_vendor, row?.source_quote_number].filter(Boolean).join(' ').toLowerCase();
  return hay.includes(q);
}
function filteredVendorCatalog(cat, query){
  const filter = rows => (rows||[]).filter(row=>matchesCatalogSearch(row, query));
  return {materials:filter(cat?.materials), equipment:filter(cat?.equipment), other:filter(cat?.other)};
}
function orderSheetVisibleCatalogRows(state){
  const filter = String(state.orderCatalogFilter || 'all');
  return orderSheetCatalogRows(state).filter(row=>{
    if(!matchesCatalogSearch(row, state.orderSheetSearch||'')) return false;
    if(filter === 'stocked') return isStockedItem(row);
    if(filter === 'catalog') return !isStockedItem(row);
    return true;
  });
}
function scopedOrderRestockRows(summary){
  if(!(summary?.draft||[]).length) return summary?.restockRows || [];
  const keys = new Set(summary.draft.map(r=>`${String(r.sku||'').toLowerCase()}|${String(r.name||'').toLowerCase()}`));
  return (summary.restockRows||[]).filter(r=> keys.has(`${String(r.sku||'').toLowerCase()}|${String(r.name||'').toLowerCase()}`));
}


function catalogPriceSourceLabel(product){
  if(!product) return 'Catalog';
  const hasManual = product.manual_price !== undefined && product.manual_price !== null && product.manual_price !== '' && !Number.isNaN(Number(product.manual_price));
  if(hasManual) return 'Manual override';
  const vendor = String(product.source_vendor||'').trim();
  const quote = String(product.source_quote_number||'').trim();
  if(vendor && quote) return `${vendor} quote ${quote}`;
  if(vendor) return vendor;
  return 'Vendor price';
}
function orderVendorLabel(product){
  const vendor = String(product?.source_vendor||'').trim() || 'Unspecified vendor';
  const quote = String(product?.source_quote_number||'').trim();
  return quote ? `${vendor} quote ${quote}` : vendor;
}
function summarizeCatalogRows(rows){
  const list = rows || [];
  return {
    rows: list,
    lines: list.length,
    vendorValue: list.reduce((sum,r)=> sum + vendorPriceValue(r), 0),
    currentValue: list.reduce((sum,r)=> sum + effectiveCatalogPrice(r), 0)
  };
}
function orderSheetSummary(state){
  const rows = orderSheetCatalogRows(state);
  const draft = (state.orderSheetDraft || []).map(r=>{
    const product = findCatalogProductForRow(state, r) || {};
    const desiredQty = Number(r.qty||0);
    const onHand = orderRowOnHand(state, r);
    const minStock = reorderMinimum(product);
    const target = targetStock(product);
    const orderQty = reorderNeed(product, desiredQty, state.orderPurchaseMode || 'target');
    const unitPrice = orderRowUnitPrice(state, r);
    return {
      ...r,
      unit: r.unit || product.unit || product.pack_size || '',
      vendor: r.vendor || orderVendorLabel(product),
      category: normalizeCatalogCategory(r.category || product.category, 'materials'),
      desiredQty,
      onHand,
      minStock,
      targetStock: target,
      orderQty,
      cost: unitPrice * orderQty,
      vendor_price: vendorPriceValue(product),
      unit_price: unitPrice,
      flags: inventoryFlags(product, desiredQty)
    };
  });
  const materials = rows.filter(r=>normalizeCatalogCategory(r.category, 'materials')==='materials');
  const equipment = rows.filter(r=>normalizeCatalogCategory(r.category, 'materials')==='equipment');
  const other = rows.filter(r=>normalizeCatalogCategory(r.category, 'materials')==='other');
  const currentValue = rows.reduce((sum,r)=> sum + effectiveCatalogPrice(r), 0);
  const vendorValue = rows.reduce((sum,r)=> sum + vendorPriceValue(r), 0);
  const draftCost = draft.reduce((sum,r)=> sum + Number(r.cost||0), 0);
  const draftQty = draft.reduce((sum,r)=> sum + Number(r.desiredQty||0), 0);
  const orderNowQty = draft.reduce((sum,r)=> sum + Number(r.orderQty||0), 0);
  const orderNowCost = draft.reduce((sum,r)=> sum + Number(r.cost||0), 0);
  const typeGroups = [
    {label:'Materials', ...summarizeCatalogRows(materials)},
    {label:'Equipment', ...summarizeCatalogRows(equipment)},
    {label:'Other', ...summarizeCatalogRows(other)}
  ];
  const vendorMap = new Map();
  rows.forEach(row=>{
    const label = orderVendorLabel(row);
    if(!vendorMap.has(label)) vendorMap.set(label, []);
    vendorMap.get(label).push(row);
  });
  const vendorGroups = Array.from(vendorMap.entries()).map(([label, groupRows])=>({label, ...summarizeCatalogRows(groupRows)})).sort((a,b)=> a.label.localeCompare(b.label));
  const groupOrder = (items, labeler)=>Array.from(items.reduce((map,row)=>{
    const label = labeler(row);
    if(!map.has(label)) map.set(label, {label, lines:0, orderQty:0, orderCost:0});
    const slot = map.get(label);
    slot.lines += 1;
    slot.orderQty += Number(row.orderQty||0);
    slot.orderCost += Number(row.cost||0);
    return map;
  }, new Map()).values()).sort((a,b)=>a.label.localeCompare(b.label));
  const stockedRows = stockedItems(rows);
  const belowMinimum = stockedRows.filter(r=>inventoryOnHand(r) < reorderMinimum(r));
  const outOfStock = stockedRows.filter(r=>inventoryOnHand(r) <= 0);
  const highCost = rows.filter(r=>effectiveCatalogPrice(r) >= 100);
  const restockRows = stockedRows.map(r=>({
    ...r,
    minStock: reorderMinimum(r),
    targetStock: targetStock(r),
    onHand: inventoryOnHand(r),
    suggestedReorder: reorderNeed(r, 0, state.orderPurchaseMode || 'target'),
    flags: inventoryFlags(r, 0)
  })).filter(r=>r.suggestedReorder > 0 || r.flags.includes('Below minimum') || r.flags.includes('Out of stock'));
  return {
    rows, draft, materials, equipment, other, stockedRows,
    vendorValue, currentValue, draftCost, draftQty, orderNowQty, orderNowCost,
    lineCount: rows.length,
    materialValue: materials.reduce((sum,r)=> sum + effectiveCatalogPrice(r), 0),
    equipmentValue: equipment.reduce((sum,r)=> sum + effectiveCatalogPrice(r), 0),
    otherValue: other.reduce((sum,r)=> sum + effectiveCatalogPrice(r), 0),
    materialVendorValue: materials.reduce((sum,r)=> sum + vendorPriceValue(r), 0),
    equipmentVendorValue: equipment.reduce((sum,r)=> sum + vendorPriceValue(r), 0),
    otherVendorValue: other.reduce((sum,r)=> sum + vendorPriceValue(r), 0),
    typeGroups,
    vendorGroups,
    belowMinimum,
    outOfStock,
    highCost,
    restockRows,
    orderTypeGroups: groupOrder(draft, row=>({materials:'Materials',equipment:'Equipment',other:'Other'})[normalizeCatalogCategory(row.category,'materials')] || 'Materials'),
    orderVendorGroups: groupOrder(draft, row=>row.vendor || 'Unspecified vendor'),
    orderCategoryGroups: groupOrder(draft, row=>purchaseCategoryLabel(row)),
    orderMode: state.orderPurchaseMode || 'target'
  };
}
function buildOrderSheetEmailText(state){
  const s = orderSheetSummary(state);
  const includeRestock = !!state.includeStockedReorderInOrderSheet;
  const scopedRestock = includeRestock ? scopedOrderRestockRows(s) : [];
  const lines = [
    APP_META.orderSheetTitle,
    '',
    `Current order lines: ${s.draft.length}`,
    `Desired qty: ${s.draftQty.toFixed(2)}`,
    `Recommended buy qty: ${s.orderNowQty.toFixed(2)}`,
    `Recommended buy total: ${money(s.orderNowCost)}`,
    `Include stocked reorder lines: ${includeRestock ? 'Yes' : 'No'}`,
    '',
    'Order by vendor:'
  ].filter(Boolean);
  s.orderVendorGroups.forEach(group=> lines.push(`- ${group.label}: ${group.lines} lines | qty ${group.orderQty.toFixed(2)} | total ${money(group.orderCost)}`));
  if(includeRestock){
    lines.push('', 'Stocked reorder lines:');
    if(scopedRestock.length){
      scopedRestock.slice(0,25).forEach(r=> lines.push(`- ${r.sku||''} ${r.name} | on hand ${Number(r.onHand||0).toFixed(2)} | min ${Number(r.minStock||0).toFixed(2)} | target ${Number(r.targetStock||0).toFixed(2)} | suggested reorder ${Number(r.suggestedReorder||0).toFixed(2)} ${r.unit||r.pack_size||''}`.trim()));
    } else {
      lines.push('- No stocked reorder lines included.');
    }
  }
  lines.push('', 'Order by category:');
  s.orderCategoryGroups.forEach(group=> lines.push(`- ${group.label}: ${group.lines} lines | qty ${group.orderQty.toFixed(2)} | total ${money(group.orderCost)}`));
  if(s.draft.length){
    lines.push('', 'Order lines:');
    s.draft.forEach(r=> lines.push(`- ${r.sku||''} ${r.name} | need ${Number(r.desiredQty||0).toFixed(2)} | on hand ${Number(r.onHand||0).toFixed(2)} | buy ${Number(r.orderQty||0).toFixed(2)} ${r.unit||''} | ${money(orderRowLineTotal(state, r))} | ${orderDraftLinkForRow(state, r) || 'No link saved'}`.trim()));
  }
  return lines.join('\n');
}
function buildOrderSheetPrintBody(state){
  const s = orderSheetSummary(state);
  const includeRestock = !!state.includeStockedReorderInOrderSheet;
  const scopedRestock = includeRestock ? scopedOrderRestockRows(s) : [];
  return `<div class="meta">Genesis Development vendor ordering summary</div>
  <div class="grid2" style="margin:14px 0">
    <div class="box"><strong>Current order</strong><br><br>Mode: ${s.orderMode==='program' ? 'Buy for current program only' : 'Buy to target stock'}<br>Lines: ${s.draft.length}<br>Desired qty: ${s.draftQty.toFixed(2)}<br>Recommended buy qty: ${s.orderNowQty.toFixed(2)}<br>Order total: ${money(s.orderNowCost)}</div>
    <div class="box"><strong>Stocked inventory</strong><br><br>Tracked items: ${s.stockedRows.length}<br>Below minimum: ${scopedRestock.filter(r=>r.flags.includes('Below minimum')).length}<br>Out of stock: ${scopedRestock.filter(r=>r.flags.includes('Out of stock')).length}<br>Included reorder lines: ${includeRestock ? scopedRestock.length : 0}</div>
  </div>
  <table class="tbl"><thead><tr><th>Vendor</th><th>Lines</th><th>Order Qty</th><th>Order Total</th></tr></thead><tbody>${s.orderVendorGroups.map(group=>`<tr><td>${group.label}</td><td>${group.lines}</td><td>${group.orderQty.toFixed(2)}</td><td>${money(group.orderCost)}</td></tr>`).join('') || '<tr><td colspan="4">No vendor order lines selected yet.</td></tr>'}</tbody></table>
  <div style="height:12px"></div>
  <table class="tbl"><thead><tr><th>Category</th><th>Lines</th><th>Order Qty</th><th>Order Total</th></tr></thead><tbody>${s.orderCategoryGroups.map(group=>`<tr><td>${group.label}</td><td>${group.lines}</td><td>${group.orderQty.toFixed(2)}</td><td>${money(group.orderCost)}</td></tr>`).join('') || '<tr><td colspan="4">No category order lines selected yet.</td></tr>'}</tbody></table>
  ${includeRestock ? `<div style="height:12px"></div>
  <table class="tbl"><thead><tr><th>SKU</th><th>Product</th><th>On Hand</th><th>Min</th><th>Target</th><th>Suggested Reorder</th><th>Unit</th></tr></thead><tbody>${scopedRestock.map(r=>`<tr><td>${r.sku||''}</td><td>${r.name}</td><td>${Number(r.onHand||0).toFixed(2)}</td><td>${Number(r.minStock||0).toFixed(2)}</td><td>${Number(r.targetStock||0).toFixed(2)}</td><td>${Number(r.suggestedReorder||0).toFixed(2)}</td><td>${r.unit||r.pack_size||''}</td></tr>`).join('') || '<tr><td colspan="7">No stocked reorder lines included.</td></tr>'}</tbody></table>` : ''}
  <div style="height:12px"></div>
  <table class="tbl"><thead><tr><th>SKU</th><th>Product</th><th>Need for Program</th><th>Inventory</th><th>Min</th><th>Target</th><th>Buy Now</th><th>Unit</th><th>Unit Price</th><th>Line Total</th><th>Vendor</th></tr></thead><tbody>${s.draft.map(r=>`<tr><td>${r.sku||''}</td><td>${r.name}</td><td>${Number(r.desiredQty||0).toFixed(2)}</td><td>${isStockedItem(findCatalogProductForRow(state, r)||r) ? Number(r.onHand||0).toFixed(2) : 'Catalog only'}</td><td>${isStockedItem(findCatalogProductForRow(state, r)||r) ? Number(r.minStock||0).toFixed(2) : '—'}</td><td>${isStockedItem(findCatalogProductForRow(state, r)||r) ? Number(r.targetStock||0).toFixed(2) : '—'}</td><td>${Number(r.orderQty||0).toFixed(2)}</td><td>${r.unit||''}</td><td>${money(orderRowUnitPrice(state, r))}</td><td>${money(orderRowLineTotal(state, r))}</td><td>${r.vendor||''}</td></tr>`).join('') || '<tr><td colspan="11">No order lines selected yet.</td></tr>'}</tbody></table>`;
}
function vendorPriceValue(product){
  if(!product) return 0;
  const info = resolveCatalogPrice({...product, manual_price:''});
  return Number(info.price||0);
}
function effectiveCatalogPrice(product){
  if(!product) return 0;
  return Number(resolveCatalogPrice(product).price||0);
}
function orderRowUnitPrice(state, row){
  if(row && row.unit_price !== undefined && row.unit_price !== null && row.unit_price !== '' && !Number.isNaN(Number(row.unit_price))) return Number(row.unit_price);
  const product = findCatalogProductForRow(state, row) || row;
  return effectiveCatalogPrice(product);
}
function orderRowLineTotal(state, row){
  return orderRowUnitPrice(state, row) * orderRowOrderNow(state, row);
}
function orderRowPriceLabel(state, row){
  const price = orderRowUnitPrice(state, row);
  const manual = !!(row && row.manual_override);
  return `${money(price)}${manual ? ' · Manual override' : ''}`;
}
function inventoryOnHand(product){
  if(!product) return 0;
  const raw = product.inventory_on_hand;
  return raw !== undefined && raw !== null && raw !== '' && !Number.isNaN(Number(raw)) ? Number(raw) : 0;
}
function reorderMinimum(product){
  if(!product) return 0;
  const raw = product.reorder_min;
  return raw !== undefined && raw !== null && raw !== '' && !Number.isNaN(Number(raw)) ? Number(raw) : 0;
}
function targetStock(product){
  if(!product) return 0;
  const raw = product.target_stock;
  return raw !== undefined && raw !== null && raw !== '' && !Number.isNaN(Number(raw)) ? Number(raw) : 0;
}
function isStockedItem(product){
  return !!(product && (product.track_inventory === true || product.track_inventory === 'true' || product.track_inventory === 1 || product.track_inventory === '1'));
}
function stockedItems(rows){
  return (rows||[]).filter(isStockedItem);
}
function inventoryTrackingLabel(product){
  return isStockedItem(product) ? 'Tracked in inventory' : 'Catalog only';
}
function wholeUnitOnly(productOrRow){
  const unit = String(productOrRow?.unit || productOrRow?.pack_size || '').toLowerCase();
  return /(ea|bag|jug|bottle|case|box|pail|bucket|pack|spreader|sprayer)/.test(unit) || unit.includes('gal jug') || unit.includes('lb bag');
}
function roundedOrderQuantity(productOrRow, qty){
  const n = Number(qty||0);
  if(!(n>0)) return 0;
  if(wholeUnitOnly(productOrRow)) return Math.ceil(n);
  return Math.round(n*100)/100;
}
function reorderNeed(product, desiredQty, mode='target'){
  const desired = Number(desiredQty||0);
  if(!isStockedItem(product)) return roundedOrderQuantity(product, desired);
  const onHand = inventoryOnHand(product);
  const target = targetStock(product);
  const useTarget = mode !== 'program';
  const raw = useTarget ? Math.max(0, Math.max(desired, target) - onHand) : Math.max(0, desired - onHand);
  return roundedOrderQuantity(product, raw);
}
function purchaseCategoryLabel(productOrRow){
  const raw = String(productOrRow?.category || '').trim();
  if(!raw) return normalizeCatalogCategory(raw, 'materials') === 'equipment' ? 'Equipment' : 'General';
  const map = {
    nutrient:'Nutrient', bio:'Bio', soil:'Soil', equipment:'Equipment', herbicide:'Herbicide', fungicide:'Fungicide', insecticide:'Insecticide', adjuvant:'Adjuvant', other:'Other'
  };
  const key = raw.toLowerCase();
  return map[key] || raw;
}
function inventoryFlags(product, desiredQty=0){
  const flags = [];
  const active = effectiveCatalogPrice(product);
  if(!isStockedItem(product)){
    flags.push('Catalog only');
    if(Number(desiredQty||0) > 0) flags.push('Used in current order');
    if(active >= 100) flags.push('High-cost');
    return flags;
  }
  const onHand = inventoryOnHand(product);
  const min = reorderMinimum(product);
  const target = targetStock(product);
  if(onHand <= 0) flags.push('Out of stock');
  if(min > 0 && onHand < min) flags.push('Below minimum');
  if(Number(desiredQty||0) > 0) flags.push('Used in current order');
  if(target > 0 && onHand < target) flags.push('Restock');
  if(active >= 100) flags.push('High-cost');
  return flags;
}
function orderRowDesiredQty(row){
  return Number(row?.qty||0);
}
function orderRowOnHand(state, row){
  const product = findCatalogProductForRow(state, row) || row;
  if(!isStockedItem(product)) return 0;
  if(row && row.on_hand !== undefined && row.on_hand !== null && row.on_hand !== '' && !Number.isNaN(Number(row.on_hand))) return Number(row.on_hand);
  return inventoryOnHand(product);
}
function orderRowOrderNow(state, row){
  const product = findCatalogProductForRow(state, row) || row || {};
  return reorderNeed(product, orderRowDesiredQty(row), state?.orderPurchaseMode || 'target');
}

function upsertOrderDraftLine(state, product, qty, sourceType='manual'){
  const desiredQty = Number(qty||0);
  if(!product || !(desiredQty>0)) return false;
  const priceInfo = resolveCatalogPrice(product);
  if(priceInfo.missing){
    alert(`Cannot add ${product.name || 'this item'} because no price is saved yet. Add a vendor price or manual override first.`);
    return false;
  }
  state.orderSheetDraft = state.orderSheetDraft || [];
  const unit = product.unit || product.pack_size || '';
  const productId = catalogProductIdentifier(product);
  const idx = state.orderSheetDraft.findIndex(r => (r.product_id && productId && String(r.product_id)===String(productId)) || (r.sku && product.sku && r.sku===product.sku) || (r.name && product.name && r.name===product.name));
  const base = {
    product_id: productId,
    sku: product.sku || '',
    name: product.name || '',
    qty: desiredQty,
    unit,
    unit_price: Number(priceInfo.price||0),
    manual_override: !!priceInfo.manual,
    price_source: priceInfo.source,
    cost: Number(priceInfo.price||0) * reorderNeed(product, desiredQty, state?.orderPurchaseMode || 'target'),
    url: productOpenUrl(product),
    category: product.category || '',
    vendor: orderVendorLabel(product),
    on_hand: inventoryOnHand(product),
    reorder_min: reorderMinimum(product),
    target_stock: targetStock(product),
    source_type: sourceType
  };
  if(idx >= 0){
    state.orderSheetDraft[idx] = {...state.orderSheetDraft[idx], ...base, qty: Number(state.orderSheetDraft[idx].qty||0) + desiredQty};
    const nextDesired = Number(state.orderSheetDraft[idx].qty||0);
    state.orderSheetDraft[idx].cost = orderRowUnitPrice(state, state.orderSheetDraft[idx]) * reorderNeed(product, nextDesired, state?.orderPurchaseMode || 'target');
    state.orderSheetDraft[idx].on_hand = inventoryOnHand(product);
    state.orderSheetDraft[idx].reorder_min = reorderMinimum(product);
    state.orderSheetDraft[idx].target_stock = targetStock(product);
  } else {
    state.orderSheetDraft.push(base);
  }
  return true;
}

function removeSavedProgram(state, key, mode){
  const useMode = mode || state.builderMode;
  const collection = activeProgramCollection(state, useMode);
  if(!collection || !key || !collection[key]) return false;
  const keys = Object.keys(collection);
  if(keys.length <= 1) return false;
  const treatmentKey = state.selectedSpecialTreatment || specialsCatalog[0]?.key || 'newSod';
  const isDefault = useMode === "ornamental"
    ? isBuiltInOrnamentalProgramKey(key)
    : useMode === "special"
      ? isBuiltInSpecialProgramKey(treatmentKey, key)
      : isBuiltInProgramKey(key);
  if(isDefault){
    if(useMode === "special"){
      state.deletedBuiltInSpecialPrograms = state.deletedBuiltInSpecialPrograms || structuredClone(defaultDeletedBuiltInSpecialPrograms);
      const next = new Set(state.deletedBuiltInSpecialPrograms[treatmentKey] || []);
      next.add(key);
      state.deletedBuiltInSpecialPrograms[treatmentKey] = Array.from(next);
    } else {
      const listKey = useMode === "ornamental" ? "deletedBuiltInOrnamentalPrograms" : "deletedBuiltInPrograms";
      const next = new Set(state[listKey] || []);
      next.add(key);
      state[listKey] = Array.from(next);
    }
  }
  delete collection[key];
  const liveCollection = activeProgramCollection(state, useMode);
  const remainingKeys = Object.keys(liveCollection || {});
  const preferredFallback = useMode === 'ornamental' ? 'orn_april' : useMode === 'special' ? `special_${treatmentKey}_base` : 'april';
  const nextKey = remainingKeys.includes(preferredFallback) ? preferredFallback : (remainingKeys[0] || '');
  if(activeProgramKey(state, useMode) === key || !liveCollection[activeProgramKey(state, useMode)]) setActiveProgramKey(state, nextKey, useMode);
  return true;
}
function createProductRecord(row){
  const category = normalizeCatalogCategory(row.category, "materials");
  const hasVendorPrice = row.vendor_price !== undefined && row.vendor_price !== null && row.vendor_price !== '' && !Number.isNaN(Number(row.vendor_price));
  const hasBasePrice = row.price !== undefined && row.price !== null && row.price !== '' && !Number.isNaN(Number(row.price));
  const vendor_price = hasVendorPrice ? Number(row.vendor_price) : (hasBasePrice ? Number(row.price) : '');
  const manual_price = row.manual_price !== undefined && row.manual_price !== null && row.manual_price !== '' && !Number.isNaN(Number(row.manual_price)) ? Number(row.manual_price) : null;
  return {
    id: row.id || `prod_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,8)}`,
    name: String(row.name||"").trim(),
    sku: String(row.sku||"").trim(),
    price: vendor_price,
    vendor_price,
    manual_price,
    notes: String(row.notes||"").trim(),
    npk: String(row.npk || inferNpk(row.name) || inferNpk(row.notes) || "").trim(),
    category,
    unit_type: String(row.unit_type||"").trim(),
    pack_size: String(row.pack_size||"").trim(),
    source_type: row.source_type || "manual",
    source_file: row.source_file || "",
    source_vendor: row.source_vendor || "",
    source_quote_number: row.source_quote_number || "",
    officialPageUrl: row.officialPageUrl || "",
    officialLabelUrl: row.officialLabelUrl || "",
    labelImage: row.labelImage || "",
    labelFileName: row.labelFileName || "",
    unit: String(row.unit||'').trim(),
    inventory_on_hand: row.inventory_on_hand !== undefined && row.inventory_on_hand !== null && row.inventory_on_hand !== '' && !Number.isNaN(Number(row.inventory_on_hand)) ? Number(row.inventory_on_hand) : 0,
    reorder_min: row.reorder_min !== undefined && row.reorder_min !== null && row.reorder_min !== '' && !Number.isNaN(Number(row.reorder_min)) ? Number(row.reorder_min) : 0,
    target_stock: row.target_stock !== undefined && row.target_stock !== null && row.target_stock !== '' && !Number.isNaN(Number(row.target_stock)) ? Number(row.target_stock) : 0,
    track_inventory: row.track_inventory === true || row.track_inventory === 'true' || row.track_inventory === 1 || row.track_inventory === '1',
    active: row.active !== false,
    created_at: row.created_at || new Date().toISOString(),
    updated_at: new Date().toISOString()
  };
}
function rebuildVendorCatalogFromProducts(products){
  const out = emptyCatalog();
  (products||[]).forEach(prod=>{
    const category = normalizeCatalogCategory(prod.category, "materials");
    out[category].push({
      id: prod.id,
      name: prod.name,
      sku: prod.sku || "",
      price: prod.price !== undefined && prod.price !== null ? prod.price : vendorPriceValue(prod),
      vendor_price: prod.vendor_price !== undefined && prod.vendor_price !== null ? prod.vendor_price : '',
      manual_price: prod.manual_price !== undefined && prod.manual_price !== null && prod.manual_price !== '' ? Number(prod.manual_price) : null,
      current_price: effectiveCatalogPrice(prod),
      notes: prod.notes || "",
      npk: prod.npk || "",
      category,
      unit_type: prod.unit_type || "",
      pack_size: prod.pack_size || "",
      source_type: prod.source_type || "manual",
      source_file: prod.source_file || "",
      source_vendor: prod.source_vendor || "",
      source_quote_number: prod.source_quote_number || "",
      officialPageUrl: prod.officialPageUrl || "",
      officialLabelUrl: prod.officialLabelUrl || "",
      labelImage: prod.labelImage || "",
      labelFileName: prod.labelFileName || "",
      unit: prod.unit || "",
      inventory_on_hand: inventoryOnHand(prod),
      reorder_min: reorderMinimum(prod),
      target_stock: targetStock(prod),
      track_inventory: isStockedItem(prod)
    });
  });
  return out;
}
function migrateCatalogState(s){
  const byId = new Map();
  const feed = (row, source_type="legacy") => {
    if(!row || !String(row.name||"").trim()) return;
    const prod = createProductRecord({...row, source_type});
    const key = `${prod.category}::${(prod.sku||"").toLowerCase()}::${prod.name.toLowerCase()}`;
    if(!byId.has(key)) byId.set(key, prod);
  };
  (s.catalogState?.products||[]).forEach(r=>feed(r, r.source_type||"catalog"));
  const legacy = s.vendorCatalog || emptyCatalog();
  Object.entries(legacy).forEach(([category, rows])=> (rows||[]).forEach(r=>feed({...r, category}, r.source_type||"legacy")));
  const products = Array.from(byId.values());
  return {
    products,
    vendorCatalog: rebuildVendorCatalogFromProducts(products)
  };
}

const { hydrateStateSnapshot, loadState, saveState, exportBackup, importBackupText } = createStateStorage({
  STORAGE_KEY,
  LEGACY_STORAGE_KEYS,
  APP_META,
  defaultState,
  migrateCatalogState,
  PRELOADED_CATALOG_PRODUCTS,
  rebuildVendorCatalogFromProducts,
  defaultDeletedBuiltInSpecialPrograms,
  defaultPrograms,
  defaultOrnamentalPrograms,
  defaultSpecialPrograms,
  defaultSelectedSpecialPrograms,
  specialsCatalog,
  withLegacyAliases,
  blankQuote,
  ornamentalDensityTier,
  downloadText
});
function todayKey(){ return new Date().toISOString().slice(0,10); }
function dailyRefresh(state){ if(state.lastDailyRefresh !== todayKey()){ state.lastDailyRefresh = todayKey(); saveState(state); } }
function money(n){ return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"}).format(Number(n||0)); }
function currentFact(){ const slot=Math.floor(Date.now()/(15*60*1000)); return facts[slot % facts.length]; }
function turfRate(sqft){ if(sqft<=3000) return 25; if(sqft<=6000) return 24; if(sqft<=10000) return 23; return 22; }
function ornRate(sqft){ if(sqft<=2000) return 33; if(sqft<=4000) return 31; if(sqft<=7000) return 29; return 27; }
function ornamentalDensityTier(value){ const v=String(value||"medium").toLowerCase(); return v==="low"||v==="high" ? v : "medium"; }
function ornamentalDensityMultiplier(value){ const tier = ornamentalDensityTier(value); if(tier==="low") return 0.9; if(tier==="high") return 1.15; return 1; }
function ornamentalRateForQuote(q){ const sqft = Number(q?.ornamentalSqft||0); return round2(ornRate(sqft) * ornamentalDensityMultiplier(q?.ornamentalDensity)); }
function ornamentalDensityLabel(value){ const tier = ornamentalDensityTier(value); return tier.charAt(0).toUpperCase()+tier.slice(1); }
function palmPrice(count){ count=Number(count||0); if(count<=0) return {price:0,label:""}; const price=Math.max(25, count*4); const label=price===25 ? "$25 monthly minimum" : "$4 per palm / month"; return {price:round2(price),label}; }
function round2(n){ return Math.round(Number(n||0) * 100) / 100; }
function resetQuoteSelections(q){
  q.services.turf.selected = false;
  q.services.ornamental.selected = false;
  q.services.palm.selected = false;
  Object.values(q.specials||{}).forEach(s=>{
    if(!s) return;
    s.selected = false;
    if('price' in s && (s.price===undefined || s.price===null || s.price==='')) s.price = 0;
    s.notes = '';
    s.dbh = '';
    s.palmHeights = {upTo15:0,ft15to30:0,ft30to45:0,ft45plus:0};
  });
}
function blankRegressionQuote(){
  const q = blankQuote();
  q.customer = 'Regression Scenario';
  q.address = '';
  q.phone = '';
  q.email = '';
  q.notes = '';
  q.customNotes = '';
  q.includeBlurb = true;
  q.manualDiscountPct = 0;
  resetQuoteSelections(q);
  return q;
}
const { regressionScenarios, applyRegressionScenario, getRegressionScenario, getRegressionPreview, runLockedRegressionChecks } = createRegressionTools({
  blankRegressionQuote,
  todayKey,
  quoteTotals,
  seasonalWindow,
  advisory
});
function renderRegressionPack(state){
  const activeScenario = getRegressionScenario(state.regressionState?.activeScenario||'');
  const regressionResults = runLockedRegressionChecks(state);
  const failing = regressionResults.filter(r=>!r.ok);
  return `<div class="row space"><div><h2>Regression Pack</h2><div class="sub">Locked acceptance scenarios to protect turf math, ornamental math, palm pricing, discounts, Daily Positioning, and packaging before you adopt a new build.</div></div><div class="small">Last applied: ${state.regressionState?.lastAppliedAt ? new Date(state.regressionState.lastAppliedAt).toLocaleString() : 'None yet'}</div></div>
    <div class="grid4">
      <div class="card stat"><div class="label">Locked Scenarios</div><div class="value">${regressionScenarios.length}</div></div>
      <div class="card stat"><div class="label">Current Baseline</div><div class="value">Build 94</div></div>
      <div class="card stat"><div class="label">Active Scenario</div><div class="value" style="font-size:18px">${activeScenario ? activeScenario.title : 'None loaded'}</div></div>
      <div class="card stat"><div class="label">Automated Check</div><div class="value" style="font-size:18px">${failing.length ? `${failing.length} failing` : 'All passing'}</div></div>
    </div>
    <div class="card" style="margin-top:14px"><div class="kicker">How to use this pack</div><ol class="list"><li>Load one scenario into the live app.</li><li>Verify Program Builder / Quote Lab / PDF output match the expected values below.</li><li>Only adopt a new build if all locked scenarios still pass and packaging opens correctly.</li></ol><div class="small" style="margin-top:12px">${failing.length ? `Automated checks are flagging: ${failing.map(r=>r.title).join(', ')}` : 'Automated checks are matching the locked baseline for every scenario.'}</div></div>
    <div class="grid2" style="margin-top:14px">
      ${regressionScenarios.map(sc=>{ const result = regressionResults.find(r=>r.key===sc.key); const preview = result?.preview; const t = preview ? preview.totals : null; return `<div class="card"><div class="row space"><div><div class="kicker">${sc.kind==='daily' ? 'Daily positioning' : 'Quote scenario'}</div><h3 style="margin:0 0 6px 0">${sc.title}</h3><div class="small">${sc.focus}</div></div><button class="btn primary" data-run-scenario="${sc.key}">Load Scenario</button></div><div class="small" style="margin-top:10px"><strong>Status:</strong> ${result?.ok ? 'PASS' : 'FAIL'}</div>${sc.kind==='daily' ? `<div class="grid2" style="margin-top:12px"><div class="serviceCard"><strong>Expected mode</strong><div class="small" style="margin-top:8px">${preview?.sw ? preview.sw.mode : 'Waiting on soil temp input'}</div></div><div class="serviceCard"><strong>Expected summary</strong><div class="small" style="margin-top:8px">${preview?.adv?.summary || 'Enter the current soil temperature to unlock the timing summary.'}</div></div></div>` : `<div class="grid4" style="margin-top:12px"><div class="serviceCard"><strong>Monthly total</strong><div class="small" style="margin-top:8px">${money(t?.total||0)}</div></div><div class="serviceCard"><strong>Modeled cost</strong><div class="small" style="margin-top:8px">${money(t?.metrics?.cost||0)}</div></div><div class="serviceCard"><strong>Gross profit</strong><div class="small" style="margin-top:8px">${money(t?.metrics?.profit_after_discount||0)}</div></div><div class="serviceCard"><strong>Gross margin</strong><div class="small" style="margin-top:8px">${Number(t?.metrics?.margin_after_discount_pct||0).toFixed(1)}%</div></div></div><div class="grid4" style="margin-top:12px"><div class="serviceCard"><strong>Turf</strong><div class="small" style="margin-top:8px">Revenue ${money(t?.turfRev||0)}<br>Cost ${money(t?.metrics?.cost_breakdown?.turf||0)}</div></div><div class="serviceCard"><strong>Ornamental</strong><div class="small" style="margin-top:8px">Revenue ${money(t?.ornRev||0)}<br>Cost ${money(t?.metrics?.cost_breakdown?.ornamental||0)}</div></div><div class="serviceCard"><strong>Palms</strong><div class="small" style="margin-top:8px">Revenue ${money(t?.palmRev?.price||0)}<br>Cost ${money(t?.metrics?.cost_breakdown?.palm||0)}</div></div><div class="serviceCard"><strong>Discount / Annual</strong><div class="small" style="margin-top:8px">Discount ${money(t?.discountAmount||0)}<br>Annual ${money(t?.metrics?.annual_revenue_total||0)}</div></div></div>`}<div style="margin-top:12px">${(result?.checks||[]).map(check=>`<div class="small">${check.pass ? 'PASS' : 'FAIL'} · ${check.label}: expected ${typeof check.expected === 'number' ? check.expected.toFixed(2) : check.expected} | actual ${typeof check.actual === 'number' ? check.actual.toFixed(2) : check.actual}</div>`).join('')}</div><div class="small" style="margin-top:12px">Check these surfaces: Program Builder cost basis, Quote Lab totals, Customer Estimate PDF, Pricing Snapshot PDF, and local-open packaging.</div></div>`; }).join('')}
    </div>
    <div class="card" style="margin-top:14px"><div class="kicker">Rollback checkpoint</div><div class="small">Keep one known-good zip before every patch. If a build breaks packaging or wipes layout, roll back first and patch only the failing path.</div></div>`;
}
function turfVisitSellPer1000(state, sqft){
  const raw = state?.actualSell?.turfPer1000;
  if(raw !== "" && raw !== undefined && raw !== null && !Number.isNaN(Number(raw))) return round2(Number(raw));
  return round2(turfRate(Number(sqft||0)));
}
function ornamentalVisitSellPer1000(state, sqft){
  const raw = state?.actualSell?.ornamentalPer1000;
  if(raw !== "" && raw !== undefined && raw !== null && !Number.isNaN(Number(raw))) return round2(Number(raw));
  return round2(ornRate(Number(sqft||0)));
}
function seasonalWindow(state){
  const soil = Number(state.soilTemp);
  if(state.soilTemp==="" || Number.isNaN(soil)) return null;
  if(soil<60) return {mode:"Protective chemistry discipline", root:"Limited root activity", bio:"Low biostimulant expression"};
  if(soil<68) return {mode:"Controlled transition", root:"Developing root activity", bio:"Opening response window"};
  if(soil<80) return {mode:"Prime optimization window", root:"Active root activity", bio:"High nutrient-efficiency window"};
  if(soil<85) return {mode:"Summer stress awareness", root:"High metabolic activity", bio:"Stress-mitigation + performance window"};
  return {mode:"Shift from push to protection", root:"Heat-stress modified activity", bio:"Protective biostimulant role"};
}
function intelligence(state){
  const sw = seasonalWindow(state);
  const base = "We optimize the landscape through advanced biological support, precise nutrient chemistry, hybrid chelation, and identification-based pest control so the entire soil-plant system performs at a higher level.";
  return {
    descriptor:"Precision landscape positioning",
    science:`Drive efficiency over volume. Use disciplined fertility, rhizosphere optimization, hybrid chelation, temporary rhizosphere acidification, plant signaling, osmotic balance, and targeted intervention rather than crude fertility loading.${sw ? ` Current operating mode: ${sw.mode}.` : ""}`,
    blurb:`${base}\n\nThis program is designed to improve transport efficiency, response quality, and visual performance across the landscape rather than relying on generic input loading.\n\nOur approach emphasizes rhizosphere management, plant signaling, stress physiology, and nutrient-use efficiency so the landscape performs with more resilience and consistency under real field conditions.\n\nWhere intervention is needed, chemistry is selected and timed with greater precision so the program remains efficient, technically grounded, and visually refined.`
  };
}
function advisory(state){
  const soil = Number(state.soilTemp), month = new Date().getMonth()+1;
  if(state.soilTemp==="" || Number.isNaN(soil)){
    return {headline:"Source-required mode", summary:"Enter the current FAWN North Port 4-inch soil reading before relying on timing calls.", disease:"No disease timing call should fire until a legitimate soil reading is entered.", pest:"Identification and threshold logic remain primary.", agronomy:["Optimization begins with verified field data."], warnings:[]};
  }
  let headline="", summary="", disease="", pest="", agronomy=[], warnings=[];
  if(state.turf==="staug"){
    headline = soil>=85 ? "Heat-modified St. Augustine management window" : soil>=68 ? "Active St. Augustine optimization window" : "Early St. Augustine transition";
    summary = soil>=85 ? "Shift emphasis toward stress buffering, disease awareness, and precision timing." : soil>=68 ? "Biostimulant and rhizosphere response windows are open." : "Response is developing; stay precise and avoid force-feeding.";
    disease = soil>=80 ? "Large patch / brown patch is no longer a primary concern under these temperatures. Shift attention toward warm, wet-season diseases such as gray leaf spot, take-all root rot, and Pythium only when moisture, site history, and stress fit the disease." : (month>=11 || month<=5 ? "Large patch / brown patch remains the cool-season Rhizoctonia concern while soil temperatures stay below the stronger summer range." : "The system is moving out of large patch timing and toward warm-season disease awareness.");
    pest = "Scout-only posture for chinch bugs unless hot reflective zones and real feeding margins are confirmed. Use active ingredient logic after identification.";
    agronomy = soil>=85 ? ["Reduce emphasis on push-growth nitrogen and shift toward stress reducers, potassium support, and root-zone efficiency.","Use seaweed, carbon, and soil conditioners to support response quality under heat load.","Heat and moisture patterns should trigger herbicide and fungicide review before application."] : ["Restrained soluble N; response quality beats raw surge growth.","Potassium, carbon, and seaweed support are favored when root-zone response is open.","Use hybrid chelation and temporary rhizosphere acidification to improve access and transport."];
  } else if(state.turf==="bermuda"){
    headline = soil>=85 ? "High-activity Bermuda summer window" : soil>=72 ? "Bermuda response building" : "Bermuda still transitional";
    summary = soil>=85 ? "Shift from transition support to performance + stress management." : soil>=72 ? "Transition support can be scaled up cautiously." : "Do not force sleepy Bermuda. Better timing beats more chemistry.";
    disease = soil>=80 ? "Large patch is no longer the meaningful disease frame here. Summer disease logic should be warm-season, moisture-driven, and site-history specific." : "No broad turf preventative fungicide alert is justified from current conditions alone.";
    pest = "Mole cricket timing is better aimed at young post-hatch stages after spring reproduction than at adults by default.";
    agronomy = soil>=85 ? ["Support performance with potassium, soil conditioning, and stress mitigation rather than crude growth escalation.","High-temperature herbicide review becomes more important as heat load increases."] : ["Use soil-conditioning inputs, bioactives, and measured potassium support to improve transition efficiency."];
  } else {
    headline = soil>=85 ? "High-temperature Zoysia management window" : soil>=70 ? "Controlled Zoysia response window" : "Conservative Zoysia transition";
    summary = soil>=85 ? "Protect response quality under heat and watch for stress interactions." : "Favor stability, controlled response, and efficient chemistry rather than spring force.";
    disease = soil>=80 ? "Large patch is not the right primary disease frame now. Evaluate warm-season disease risk by moisture, site history, and stress interaction." : "Keep disease logic moisture- and site-history-specific rather than broad and prophylactic.";
    pest = "Escalate only with confirmed pressure and site fit, using active ingredient logic after identification.";
    agronomy = soil>=85 ? ["Prioritize stress buffering, moisture management, and response quality over push-growth chemistry.","Use biostimulants in a protective rather than purely stimulatory role."] : ["Use moderate fertility with bioactive and soil-chemistry support.","Use hybrid chelation and rhizosphere acidification where they improve actual nutrient access."];
  }
  if(soil>=85){
    Object.values(state.labels).forEach(prod=>{
      const max = Number(prod.maxTempF);
      if(prod.maxTempF && !Number.isNaN(max) && soil>=max){
        warnings.push(`${prod.name}: threshold warning at ${max} F - ${prod.warning}`);
      }
    });
  }
  return {headline, summary, disease, pest, agronomy, warnings};
}
function unitCost(product, amount){
  if(!product) return 0;
  const unitPrice = effectiveCatalogPrice(product);
  const u = String(product.unit||"").toLowerCase();
  if(u.includes("50 lb")) return (amount/50)*unitPrice;
  if(u.includes("25 lb")) return (amount/25)*unitPrice;
  if(u.includes("2.5 gal")) return (amount/320)*unitPrice;
  if(u.includes("1 gal")) return (amount/128)*unitPrice;
  if(u.includes("10 oz")) return (amount/10)*unitPrice;
  return 0;
}
const templateDescriptions = {
  low_n_lawn:"Low N efficiency and color response",
  summer_stress:"Stress mitigation and summer survivability",
  fungicide_rotation:"Protective rotation structure for higher-risk windows",
  palm_health:"Palm nutrition and appearance support",
  ornamental_deep_feed:"Root-zone and shrub response support"
};
function isBuiltInProgramKey(key){
  return Object.prototype.hasOwnProperty.call(defaultPrograms, key);
}
function isBuiltInOrnamentalProgramKey(key){
  return Object.prototype.hasOwnProperty.call(defaultOrnamentalPrograms, key);
}
function isBuiltInSpecialProgramKey(treatmentKey, key){
  return Object.prototype.hasOwnProperty.call(defaultSpecialPrograms[treatmentKey] || {}, key);
}
function activeProgramCollection(state, mode){
  const useMode = mode || state.builderMode;
  if(useMode === "ornamental") return state.ornamentalPrograms;
  if(useMode === "special"){
    const treatmentKey = state.selectedSpecialTreatment || specialsCatalog[0]?.key || 'newSod';
    state.specialPrograms = state.specialPrograms || structuredClone(defaultSpecialPrograms);
    state.specialPrograms[treatmentKey] = state.specialPrograms[treatmentKey] || {};
    return state.specialPrograms[treatmentKey];
  }
  return state.programs;
}
function activeProgramKey(state, mode){
  const useMode = mode || state.builderMode;
  if(useMode === "ornamental") return state.selectedOrnamentalProgram;
  if(useMode === "special"){
    const treatmentKey = state.selectedSpecialTreatment || specialsCatalog[0]?.key || 'newSod';
    state.selectedSpecialPrograms = state.selectedSpecialPrograms || structuredClone(defaultSelectedSpecialPrograms);
    return state.selectedSpecialPrograms[treatmentKey];
  }
  return state.selectedProgram;
}
function activeProgramRecord(state, mode){
  const collection = activeProgramCollection(state, mode);
  return collection?.[activeProgramKey(state, mode)] || null;
}
function setActiveProgramKey(state, key, mode){
  const useMode = mode || state.builderMode;
  if(useMode === "ornamental") state.selectedOrnamentalProgram = key;
  else if(useMode === "special"){
    const treatmentKey = state.selectedSpecialTreatment || specialsCatalog[0]?.key || 'newSod';
    state.selectedSpecialPrograms = state.selectedSpecialPrograms || structuredClone(defaultSelectedSpecialPrograms);
    state.selectedSpecialPrograms[treatmentKey] = key;
  }
  else state.selectedProgram = key;
}
function lineEditorBucket(state, mode){
  const useMode = mode || state.builderMode || "turf";
  state.programLineEditors = state.programLineEditors || {turf:{}, ornamental:{}, specials:{}};
  state.programLineEditors.turf = state.programLineEditors.turf || {};
  state.programLineEditors.ornamental = state.programLineEditors.ornamental || {};
  state.programLineEditors.specials = state.programLineEditors.specials || {};
  if(useMode === "special"){
    const treatmentKey = state.selectedSpecialTreatment || specialsCatalog[0]?.key || 'newSod';
    state.programLineEditors.specials[treatmentKey] = state.programLineEditors.specials[treatmentKey] || {};
    return state.programLineEditors.specials[treatmentKey];
  }
  return useMode === "ornamental" ? state.programLineEditors.ornamental : state.programLineEditors.turf;
}
function isProgramLineExpanded(state, idx, mode){
  const bucket = lineEditorBucket(state, mode);
  return !!bucket[String(idx)];
}
function setProgramLineExpanded(state, idx, expanded, mode){
  const bucket = lineEditorBucket(state, mode);
  if(expanded) bucket[String(idx)] = true;
  else delete bucket[String(idx)];
}
function getManualTemplatePrograms(state, mode){
  const useMode = mode || state.builderMode;
  const collection = activeProgramCollection(state, useMode);
  const treatmentKey = state.selectedSpecialTreatment || specialsCatalog[0]?.key || 'newSod';
  const isBuiltIn = useMode === "ornamental"
    ? isBuiltInOrnamentalProgramKey
    : useMode === "special"
      ? (key=>isBuiltInSpecialProgramKey(treatmentKey, key))
      : isBuiltInProgramKey;
  return Object.entries(collection||{})
    .filter(([key, program])=>!isBuiltIn(key) && program && Array.isArray(program.lines) && program.lines.length)
    .map(([key, program])=>({
      key,
      name: program.name || key,
      description: program.templateNote || templateDescriptions[key] || (useMode === "ornamental" ? "Previously built ornamental program" : useMode === "special" ? "Previously built special treatment program" : "Previously saved program template")
    }));
}
function applyTemplateToProgram(state, templateKey, mode){
  const useMode = mode || state.builderMode;
  const collection = activeProgramCollection(state, useMode);
  const t = collection?.[templateKey];
  const active = activeProgramRecord(state, useMode);
  if(!t || !Array.isArray(t.lines) || !active) return;
  active.lines = JSON.parse(JSON.stringify(t.lines));
  if(t.tankCoverageSqft) active.tankCoverageSqft = t.tankCoverageSqft;
}
function ornamentalForecastProfile(state){
  const avgSqft = Number(state.forecasts?.avgOrnSqft||0);
  const canopyFactor = avgSqft <= 4000 ? 0.72 : avgSqft <= 8000 ? 0.68 : 0.64;
  const routeDensityFactor = 0.80;
  const monthlyTouchFactor = 0.88;
  const combined = round2(canopyFactor * routeDensityFactor * monthlyTouchFactor);
  return {canopyFactor, routeDensityFactor, monthlyTouchFactor, combined};
}
function forecastCoverageFactor(state, mode){
  const useMode = mode || state.builderMode;
  if(useMode !== "ornamental") return 1;
  return ornamentalForecastProfile(state).combined;
}
function forecastBasisLabel(state, mode){
  const useMode = mode || state.builderMode;
  const props = Number(state.forecasts?.properties||0);
  if(useMode === "special") return `${props} props`;
  if(useMode !== "ornamental") return `${props} props`;
  const profile = ornamentalForecastProfile(state);
  return `${props} props | canopy ${(profile.canopyFactor*100).toFixed(0)}% x route ${(profile.routeDensityFactor*100).toFixed(0)}% x monthly touch ${(profile.monthlyTouchFactor*100).toFixed(0)}%`;
}
function forecastEffectiveSqft(state, mode){
  const useMode = mode || state.builderMode;
  const props = Number(state.forecasts?.properties||0);
  const avgSqft = useMode === "ornamental" ? Number(state.forecasts?.avgOrnSqft||0) : useMode === "special" ? Number(state.forecasts?.avgSpecialSqft||0) : Number(state.forecasts?.avgTurfSqft||0);
  return props * avgSqft * forecastCoverageFactor(state, useMode);
}
function forecastMaterialUsage(state, mode){
  const useMode = mode || state.builderMode;
  const p = activeProgramRecord(state, useMode);
  if(!p) return [];
  const totalSqft = forecastEffectiveSqft(state, useMode);
  const tanksNeeded = p.tankCoverageSqft ? (totalSqft / p.tankCoverageSqft) : 0;
  return p.lines.map(line=>{
    const qty = Number(line.rate||0) * tanksNeeded;
    const cost = lineChemicalCost(state, line) * tanksNeeded;
    return { name: state.labels[line.sku]?.name || line.sku, unit: line.unit, qty, cost };
  });
}
function lineChemicalCost(state, line){
  const product = state.labels[line.sku];
  if(!product) return 0;
  return unitCost(product, Number(line.rate||0));
}
function materialMetrics(state, mode){
  const p = activeProgramRecord(state, mode);
  if(!p) return {perTank:0, per1000:0, perAcre:0};
  const perTank = p.lines.reduce((sum,l)=>sum+unitCost(state.labels[l.sku], Number(l.rate||0)),0);
  const per1000 = p.tankCoverageSqft ? perTank/(p.tankCoverageSqft/1000) : 0;
  return {perTank, per1000, perAcre:per1000*43.56};
}
function oakTreePrice(dbh){ if(dbh<=12) return dbh*28; if(dbh<=24) return dbh*32; if(dbh<=36) return dbh*36; return Math.min(dbh*40,1050); }
function specialsRows(state){
  const q = state.currentQuote, rows = [];
  specialsCatalog.forEach(s=>{
    const e = q.specials[s.key];
    if(!e?.selected) return;
    if(s.mode==="oak"){
      const dbhs=(e.dbh||"").split(/[\s,]+/).map(Number).filter(Boolean);
      rows.push({name:s.name, description:s.description, detail:dbhs.length?`${dbhs.length} trees | DBH list: ${dbhs.join(", ")}`:"No DBH entered", notes:e.notes, price:dbhs.reduce((sum,v)=>sum+oakTreePrice(v),0)});
    } else if(s.mode==="palm"){
      const h=e.palmHeights||{};
      rows.push({name:s.name, description:s.description, detail:`Up to 15 ft: ${h.upTo15||0}, 15-30 ft: ${h.ft15to30||0}, 30-45 ft: ${h.ft30to45||0}, over 45 ft: ${h.ft45plus||0}`, notes:e.notes, price:(Number(h.upTo15||0)*225)+(Number(h.ft15to30||0)*250)+(Number(h.ft30to45||0)*300)+(Number(h.ft45plus||0)*350)});
    } else {
      rows.push({name:s.name, description:s.description, detail:"", notes:e.notes, price:Number(e.price||0)});
    }
  });
  return rows;
}
function applySmartQuoteDefaults(state){
  const q = state.currentQuote;
  q.services.turf.selected = true;
  q.services.ornamental.selected = true;
  q.services.palm.selected = Number(q.palmCount||0) > 0;
  if(q.specials.fireAnt) q.specials.fireAnt.selected = true;
  if(Number(q.turfSqft||0) > 4000 && q.specials.growthReg) q.specials.growthReg.selected = true;
}
function buildQuoteServiceRows(state){
  const q = state.currentQuote;
  const rows = [];
  if(q.services.turf.selected){
    rows.push({sourceKey:"turf", group:"core", name:"Turf Program", frequency:"monthly", annual_visits:12, recurring:true, price:(Number(q.turfSqft||0)/1000)*turfRate(Number(q.turfSqft||0)), notes:q.services.turf.notes||"", description:q.services.turf.description||""});
  }
  if(q.services.ornamental.selected){
    rows.push({sourceKey:"ornamental", group:"core", name:"Ornamental Program", frequency:"monthly", annual_visits:12, recurring:true, price:(Number(q.ornamentalSqft||0)/1000)*ornamentalRateForQuote(q), notes:q.services.ornamental.notes||"", description:q.services.ornamental.description||"", density:ornamentalDensityTier(q.ornamentalDensity)});
  }
  if(q.services.palm.selected){
    rows.push({sourceKey:"palm", group:"core", name:"Palm Program", frequency:"monthly", annual_visits:12, recurring:true, price:palmPrice(Number(q.palmCount||0)).price, notes:q.services.palm.notes||"", description:q.services.palm.description||""});
  }
  specialsRows(state).forEach((r, idx) => rows.push({sourceKey:`special_${idx}` , group:"additional", name:r.name, frequency:"as-needed", annual_visits:1, recurring:false, price:Number(r.price||0), notes:r.notes||"", description:r.description||"", detail:r.detail||""}));
  return rows;
}
function quoteMetrics(state){
  const job = {
    revenue_type:"recurring",
    property:{
      turf_sqft:Number(state.currentQuote.turfSqft||0),
      ornamental_sqft:Number(state.currentQuote.ornamentalSqft||0),
      palm_count:Number(state.currentQuote.palmCount||0)
    },
    service_rows: buildQuoteServiceRows(state)
  };
  return window.PA_Calc ? PA_Calc.calcJobMetrics(job) : {rows:[], revenue:0, cost:0, profit:0, margin_pct:0, arr:0, mrr:0, annual_revenue_total:0, flags:[]};
}
function quoteRevenueBreakdown(state){
  const metrics = quoteMetrics(state);
  const turfRow = metrics.rows.find(r => r.sourceKey === "turf") || {revenue:0};
  const ornRow = metrics.rows.find(r => r.sourceKey === "ornamental") || {revenue:0};
  const palmRow = metrics.rows.find(r => r.sourceKey === "palm") || {revenue:0};
  return {
    metrics,
    turfMonthlyRevenue: round2(turfRow.revenue),
    ornamentalMonthlyRevenue: round2(ornRow.revenue),
    palmMonthlyRevenue: round2(palmRow.revenue),
    totalMonthlyRevenue: round2(metrics.revenue)
  };
}
function quoteDiscountPct(state){
  return Number(state.currentQuote?.manualDiscountPct || 0);
}
function quoteDiscountAmount(state, subtotal){
  return round2(Number(subtotal||0) * (quoteDiscountPct(state) / 100));
}
function quoteModeledCostBreakdown(state, metrics){
  const q = state.currentQuote || {};
  const turfSelected = !!q.services?.turf?.selected;
  const ornamentalSelected = !!q.services?.ornamental?.selected;
  const turfCost = turfSelected ? round2((Number(q.turfSqft||0) / 1000) * Number(materialMetrics(state, "turf").per1000 || 0)) : 0;
  const ornamentalCost = ornamentalSelected ? round2((Number(q.ornamentalSqft||0) / 1000) * Number(materialMetrics(state, "ornamental").per1000 || 0) * ornamentalDensityMultiplier(q.ornamentalDensity)) : 0;
  const palmCost = round2((metrics.rows || []).filter(r => r.sourceKey === "palm").reduce((sum, r) => sum + Number(r.cost||0), 0));
  const specialsCost = round2((metrics.rows || []).filter(r => String(r.sourceKey||"").startsWith("special_")).reduce((sum, r) => sum + Number(r.cost||0), 0));
  return {
    turf: turfCost,
    ornamental: ornamentalCost,
    palm: palmCost,
    specials: specialsCost,
    total: round2(turfCost + ornamentalCost + palmCost + specialsCost)
  };
}
function quoteTotals(state){
  const revenue = quoteRevenueBreakdown(state);
  const extra = specialsRows(state);
  const subtotal = revenue.totalMonthlyRevenue;
  const discountPct = quoteDiscountPct(state);
  const discountAmount = quoteDiscountAmount(state, subtotal);
  const discountedTotal = round2(subtotal - discountAmount);
  const minimumServiceCharge = subtotal > 0 ? 125 : 0;
  const minimumServiceAdjustment = discountedTotal > 0 && discountedTotal < minimumServiceCharge ? round2(minimumServiceCharge - discountedTotal) : 0;
  const total = round2(discountedTotal + minimumServiceAdjustment);
  const metrics = { ...revenue.metrics };
  const costBreakdown = quoteModeledCostBreakdown(state, metrics);
  const rows = (metrics.rows || []).map(row => {
    let cost = Number(row.cost || 0);
    if(row.sourceKey === "turf") cost = costBreakdown.turf;
    else if(row.sourceKey === "ornamental") cost = costBreakdown.ornamental;
    else if(row.sourceKey === "palm") cost = costBreakdown.palm;
    const revenueValue = Number(row.revenue || 0);
    const profit = round2(revenueValue - cost);
    const margin_pct = revenueValue > 0 ? round2((profit / revenueValue) * 100) : 0;
    return { ...row, cost: round2(cost), profit, margin_pct };
  });
  metrics.rows = rows;
  metrics.cost_breakdown = costBreakdown;
  metrics.cost = costBreakdown.total;
  metrics.profit = round2(Number(metrics.revenue||0) - metrics.cost);
  metrics.margin_pct = Number(metrics.revenue||0) > 0 ? round2((metrics.profit / Number(metrics.revenue||0)) * 100) : 0;
  metrics.discount_pct = discountPct;
  metrics.discount_amount = discountAmount;
  metrics.minimum_service_charge = minimumServiceCharge;
  metrics.minimum_service_adjustment = minimumServiceAdjustment;
  metrics.revenue_after_discount = discountedTotal;
  metrics.revenue_final = total;
  metrics.profit_after_discount = round2(total - metrics.cost);
  metrics.margin_after_discount_pct = total > 0 ? round2((metrics.profit_after_discount / total) * 100) : 0;
  return {
    turfRev: revenue.turfMonthlyRevenue,
    ornRev: revenue.ornamentalMonthlyRevenue,
    palmRev: {price: revenue.palmMonthlyRevenue, label:""},
    specialsRows: extra,
    subtotal,
    discountPct,
    discountAmount,
    minimumServiceCharge,
    minimumServiceAdjustment,
    total,
    metrics,
    revenue
  };
}
function buildEstimateText(state, totals, intel){
  const q=state.currentQuote;
  const lines=["PROGRAM ARCHITECT ESTIMATE", q.customer||"Customer", q.address||"", q.phone||"", q.email||"", ""];
  if(q.services.turf.selected) lines.push(`Turf Program: ${money(totals.turfRev)}`);
  if(q.services.ornamental.selected) lines.push(`Ornamental Program: ${money(totals.ornRev)}`);
  if(q.services.palm.selected) lines.push(`Palm Program: ${money(totals.palmRev.price)}`);
  totals.specialsRows.forEach(r=>lines.push(`${r.name}: ${money(r.price)}${r.detail?` (${r.detail})`:""}`));
  lines.push(`Subtotal: ${money(totals.subtotal)}`);
  if(totals.discountPct){
    lines.push(`Manual Discount (${totals.discountPct}%): -${money(totals.discountAmount)}`);
  }
  if(totals.minimumServiceAdjustment){
    lines.push(`Minimum Service Charge Adjustment: ${money(totals.minimumServiceAdjustment)}`);
  }
  lines.push(`Total: ${money(totals.total)}`);
  if(q.includeBlurb && (q.notes || q.customNotes)){
    lines.push("", "Notes:");
    if(q.notes) lines.push(q.notes);
    if(q.customNotes) lines.push(q.customNotes);
  }
  return lines.join("\n");
}
function pdfDoc(title, body){
  return `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title><style>
  @page{size:Letter;margin:.45in}
  body{font-family:Arial,sans-serif;color:#111}
  .header{display:flex;gap:12px;align-items:center;border-bottom:2px solid #111;padding-bottom:12px;margin-bottom:16px}
  .logo{width:56px;height:56px;object-fit:contain}
  .h{font-size:24px;margin:0}.sub{font-size:11px;color:#555}.meta{font-size:12px;color:#333;margin:10px 0 14px}
  .tbl{width:100%;border-collapse:collapse}.tbl th,.tbl td{padding:8px 6px;border-bottom:1px solid #ddd;font-size:12px;text-align:left;vertical-align:top}
  .tbl th{font-size:11px;color:#555;text-transform:uppercase;letter-spacing:.06em}
  .box{border:1px solid #ccc;border-radius:10px;padding:10px;margin-top:12px;background:#fafafa}.note{font-size:12px;line-height:1.5;color:#222;margin-top:12px}
  </style></head><body><div class="header"><img class="logo" src="logo-white-ver.webp"><div><h1 class="h">${title}</h1><div class="sub">Program Architect | Precision plant health design</div></div></div>${body}</body></html>`;
}

function openPrint(html){
  const w = window.open("about:blank", "_blank");
  if(!w){
    alert("Please allow popups for printing.");
    return null;
  }
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(()=>{ try{ w.print(); }catch(err){} }, 300);
  return w;
}
function openLabelAssetTab(dataUrl, title="Label"){
  const w = window.open("about:blank", "_blank");
  if(!w){
    alert("Please allow popups for Label Center.");
    return null;
  }
  const safeTitle = String(title || "Label").replace(/[&<>"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[ch]));
  const isPdf = isPdfDataUrl(dataUrl);
  const body = isPdf
    ? `<iframe src="${dataUrl}#view=FitH&page=1" style="position:fixed;inset:0;border:0;width:100%;height:100%"></iframe>`
    : `<div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:#111"><img src="${dataUrl}" alt="${safeTitle}" style="max-width:100%;max-height:100%;object-fit:contain"></div>`;
  w.document.open();
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${safeTitle}</title><style>html,body{margin:0;height:100%;background:#111}</style></head><body>${body}</body></html>`);
  w.document.close();
  return w;
}
function readLabelAsset(product){
  if(!product || !product.labelImage) return;
  openLabelAssetTab(product.labelImage, product.labelFileName || product.name || "Label");
}
function printLabelAsset(product){
  if(!product || !product.labelImage) return;
  const w = openLabelAssetTab(product.labelImage, product.labelFileName || product.name || "Label");
  if(!w) return;
  const tryPrint = ()=>{ try{ w.focus(); w.print(); }catch(err){} };
  setTimeout(tryPrint, 900);
  setTimeout(tryPrint, 1700);
}
function downloadText(filename, content, type="text/plain"){
  const blob = new Blob([content], {type});
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}
function operationsSummary(state){
  const history = Array.isArray(state.history) ? state.history : [];
  const manualSales = Array.isArray(state.manualSales) ? state.manualSales : [];
  const accepted = history.filter(r => r && r.accepted);
  const pending = history.filter(r => r && !r.accepted);
  const acceptedRevenue = accepted.reduce((s,r)=>s+Number(r.finalSoldValue || r.total || 0),0);
  const manualRevenue = manualSales.reduce((s,r)=>s+Number(r.value||0),0);
  const pipelineValue = pending.reduce((s,r)=>s+Number(r.total||0),0);
  const totalRevenue = acceptedRevenue + manualRevenue;
  const closeRate = history.length ? ((accepted.length/history.length)*100) : 0;
  const avgEstimate = history.length ? history.reduce((s,r)=>s+Number(r.total||0),0)/history.length : 0;
  const avgSold = accepted.length ? accepted.reduce((s,r)=>s+Number(r.finalSoldValue||r.total||0),0)/accepted.length : 0;
  const revByCat = {turf:0, ornamental:0, palm:0, specials:0};
  accepted.forEach(r=>{
    const total = Number(r.finalSoldValue || r.total || 0);
    const cats = [];
    if(r.services && r.services.turf && r.services.turf.selected) cats.push("turf");
    if(r.services && r.services.ornamental && r.services.ornamental.selected) cats.push("ornamental");
    if(r.services && r.services.palm && r.services.palm.selected) cats.push("palm");
    if(r.specials && Object.values(r.specials).some(x => x && x.selected)) cats.push("specials");
    const share = cats.length ? total / cats.length : 0;
    cats.forEach(c => revByCat[c] += share);
  });
  manualSales.forEach(r=>{
    const c = ["turf","ornamental","palm","specials"].includes(r.category) ? r.category : "specials";
    revByCat[c] += Number(r.value||0);
  });
  return {history, manualSales, accepted, pending, acceptedRevenue, manualRevenue, pipelineValue, totalRevenue, closeRate, avgEstimate, avgSold, revByCat};
}
function buildOperationsReportText(state){
  const s = operationsSummary(state);
  const lines = [
    'Genesis Development Operations Report',
    '',
    `Total monthly revenue: ${money(s.totalRevenue)}`,
    `Accepted monthly revenue: ${money(s.acceptedRevenue)}`,
    `Manual monthly revenue: ${money(s.manualRevenue)}`,
    `Pipeline monthly value: ${money(s.pipelineValue)}`,
    '',
    `Estimates: ${s.history.length}`,
    `Accepted: ${s.accepted.length}`,
    `Pending: ${s.pending.length}`,
    `Close rate: ${s.closeRate.toFixed(0)}%`,
    `Average monthly estimate: ${money(s.avgEstimate)}`,
    `Average monthly sold value: ${money(s.avgSold)}`,
    `Estimated monthly profit / property: ${money(estimatedProfitPerProperty(state))}`,
    '',
    'Revenue by category:',
    `- Turf: ${money(s.revByCat.turf)}`,
    `- Ornamental: ${money(s.revByCat.ornamental)}`,
    `- Palm: ${money(s.revByCat.palm)}`,
    `- Specials: ${money(s.revByCat.specials)}`,
  ];
  if(s.manualSales.length){
    lines.push('', 'Manual sales:');
    s.manualSales.forEach((r, idx)=> lines.push(`${idx+1}. ${r.name||'Manual sale'} | ${r.category||'specials'} | ${money(r.value||0)}${r.notes ? ' | '+r.notes : ''}`));
  }
  return lines.join('\n');
}
function buildOperationsPrintBody(state){
  const s = operationsSummary(state);
  const stat = (label, value)=>`<div class="serviceCard"><strong>${label}</strong><div style="margin-top:8px">${value}</div></div>`;
  const manualRows = s.manualSales.length
    ? `<table class="table"><thead><tr><th>Name</th><th>Category</th><th>Value</th><th>Notes</th></tr></thead><tbody>${s.manualSales.map(r=>`<tr><td>${escapeHtml(r.name||'')}</td><td>${escapeHtml(r.category||'')}</td><td>${money(r.value||0)}</td><td>${escapeHtml(r.notes||'')}</td></tr>`).join('')}</tbody></table>`
    : '<div class="note">No manual sales recorded.</div>';
  return `
    <div class="grid4">
      ${stat('Total Monthly Revenue', money(s.totalRevenue))}
      ${stat('Accepted Monthly Revenue', money(s.acceptedRevenue))}
      ${stat('Manual Monthly Revenue', money(s.manualRevenue))}
      ${stat('Pipeline Monthly Value', money(s.pipelineValue))}
    </div>
    <div class="grid4" style="margin-top:14px">
      ${stat('Estimates', s.history.length)}
      ${stat('Accepted', s.accepted.length)}
      ${stat('Pending', s.pending.length)}
      ${stat('Close Rate', s.closeRate.toFixed(0)+'%')}
    </div>
    <div class="grid4" style="margin-top:14px">
      ${stat('Average Monthly Estimate', money(s.avgEstimate))}
      ${stat('Average Monthly Sold Value', money(s.avgSold))}
      ${stat('Estimated Monthly Profit / Property', money(estimatedProfitPerProperty(state)))}
      ${stat('Annual Revenue Projection', money(s.acceptedRevenue * 12))}
    </div>
    <div class="grid4" style="margin-top:14px">
      ${stat('Turf Monthly Revenue', money(s.revByCat.turf))}
      ${stat('Ornamental Monthly Revenue', money(s.revByCat.ornamental))}
      ${stat('Palm Monthly Revenue', money(s.revByCat.palm))}
      ${stat('Specials Monthly Revenue', money(s.revByCat.specials))}
    </div>
    <div class="card" style="margin-top:14px"><div class="kicker">Manual Sales</div>${manualRows}</div>
  `;
}
async function shareOperationsReport(state){
  const text = buildOperationsReportText(state);
  if(navigator.share){
    try{
      const file = new File([text], "genesis-operations-report.txt", {type:"text/plain"});
      const data = navigator.canShare && navigator.canShare({ files:[file] }) ? { title:"Genesis Operations Report", text:"Operations report attached.", files:[file] } : { title:"Genesis Operations Report", text };
      await navigator.share(data);
      return true;
    }catch(err){}
  }
  return false;
}
async function shareEstimate(state, totals, intel){
  const text = buildEstimateText(state, totals, intel);
  if(navigator.share){
    try{
      const file = new File([text], "program-architect-estimate.txt", {type:"text/plain"});
      const data = navigator.canShare && navigator.canShare({ files:[file] }) ? { title:"Program Architect Estimate", text:"Program Architect estimate attached.", files:[file] } : { title:"Program Architect Estimate", text };
      await navigator.share(data);
      return;
    }catch(e){}
  }
  alert("Share sheet is not available on this device/browser.");
}
function applyForecastToOrderSheet(state){
  const items = forecastMaterialUsage(state);
  state.orderSheetDraft = [];
  items.forEach(r => {
    const product = Object.values(state.labels||{}).find(p=>p.name===r.name || p.sku===r.sku) || Object.values(state.catalogState?.products||[]).find(p=>p.name===r.name || p.sku===r.sku) || {};
    upsertOrderDraftLine(state, {
      ...product,
      name: product.name || r.name,
      sku: product.sku || r.sku || '',
      unit: String(r.unit).split(" per ")[0],
      category: product.category || 'materials'
    }, Number(r.qty||0), 'forecast');
    const idx = state.orderSheetDraft.findIndex(x => (x.sku && (product.sku||r.sku) && x.sku === (product.sku||r.sku)) || x.name === (product.name||r.name));
    if(idx >= 0) state.orderSheetDraft[idx].cost = Number(r.cost||0);
  });
}
function estimatedProfitPerProperty(state){
  const metrics = materialMetrics(state);
  const avgSqft = Number(state.forecasts?.avgTurfSqft||0);
  const avgCostPerProperty = (avgSqft / 1000) * metrics.per1000;
  const avgMonthlyRevenuePerProperty = (avgSqft / 1000) * turfVisitSellPer1000(state, avgSqft);
  return round2(avgMonthlyRevenuePerProperty - avgCostPerProperty);
}
function normalizeCatalogCategory(raw, fallback="materials"){
  const v = String(raw||"").trim().toLowerCase();
  if(v==="materials" || v==="material" || v==="herbicides" || v==="fungicides" || v==="insecticides" || v==="bio" || v==="soil") return "materials";
  if(v==="equipment" || v==="equip") return "equipment";
  if(v==="other") return "other";
  return fallback;
}
function splitCsvRow(line, delimiter=","){
  const out=[];
  let cur="", inQuotes=false;
  for(let i=0;i<line.length;i++){
    const ch=line[i];
    if(ch==='"'){
      if(inQuotes && line[i+1]==='"'){ cur+='"'; i++; }
      else inQuotes=!inQuotes;
    } else if(ch===delimiter && !inQuotes){
      out.push(cur.trim()); cur="";
    } else {
      cur += ch;
    }
  }
  out.push(cur.trim());
  return out;
}
function parseMoneyValue(v){
  const cleaned = String(v||"").replace(/[$,]/g,"").trim();
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : 0;
}
function normalizeCatalogRow(row, fallbackCategory="materials"){
  const category = normalizeCatalogCategory(row.category, fallbackCategory);
  return {
    id: row.id || `prod_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,8)}`,
    name: String(row.name||"").replace(/\s+/g,' ').trim(),
    sku: String(row.sku||"").trim(),
    price: parseMoneyValue(row.price),
    notes: String(row.notes||"").replace(/\s+/g,' ').trim(),
    npk: String(row.npk || inferNpk(row.name) || inferNpk(row.notes) || "").trim(),
    category,
    unit_type: String(row.unit_type||"").trim(),
    pack_size: String(row.pack_size||"").trim(),
    source_type: row.source_type || "manual",
    source_file: row.source_file || "",
    source_vendor: row.source_vendor || "",
    source_quote_number: row.source_quote_number || "",
    include: row.include !== false,
    warnings: Array.isArray(row.warnings) ? row.warnings : []
  };
}
function parseCatalogDelimited(text, fallbackCategory="materials", sourceMeta={}){
  const cleaned = String(text||"").trim();
  if(!cleaned) return [];
  
  if(!lines.length) return [];
  const delimiter = lines[0].includes("	") ? "	" : ",";
  const rawHeaders = splitCsvRow(lines[0], delimiter).map(h => h.trim().toLowerCase());
  const mapHeader = (h) => {
    if(["name","product","item","description","material","equipment"].includes(h)) return "name";
    if(["sku","item #","item#","code","product code","part","part #","part#"].includes(h)) return "sku";
    if(["price","unit price","cost","amount","net price"].includes(h)) return "price";
    if(["notes","note","comments","comment","details"].includes(h)) return "notes";
    if(["size","package","pack","uom","unit"].includes(h)) return "pack_size";
    if(["category","type","class","group"].includes(h)) return "category";
    if(["npk","n-p-k","analysis","fertilizer analysis","grade"].includes(h)) return "npk";
    return h;
  };
  const headers = rawHeaders.map(mapHeader);
  const idx = {
    name:headers.indexOf("name"),
    sku:headers.indexOf("sku"),
    price:headers.indexOf("price"),
    notes:headers.indexOf("notes"),
    pack_size:headers.indexOf("pack_size"),
    category:headers.indexOf("category"),
    npk:headers.indexOf("npk")
  };
  const looksLikeHeader = headers.includes("name") || rawHeaders.some(h => /name|product|item|description|price|sku|code|category/.test(h));
  const parseLine = (parts) => {
    const row = {
      name: idx.name >= 0 ? (parts[idx.name]||"") : (parts[0]||""),
      sku: idx.sku >= 0 ? (parts[idx.sku]||"") : (parts[1]||""),
      price: idx.price >= 0 ? (parts[idx.price]||0) : (parts[2]||0),
      notes: idx.notes >= 0 ? (parts[idx.notes]||"") : (parts[3]||""),
      pack_size: idx.pack_size >= 0 ? (parts[idx.pack_size]||"") : "",
      npk: idx.npk >= 0 ? (parts[idx.npk]||"") : "",
      category: idx.category >= 0 ? (parts[idx.category]||fallbackCategory) : fallbackCategory,
      source_type: sourceMeta.source_type || "csv",
      source_file: sourceMeta.source_file || ""
    };
    return normalizeCatalogRow(row, fallbackCategory);
  };
  return (looksLikeHeader ? lines.slice(1) : lines)
    .map(line => parseLine(splitCsvRow(line, delimiter)))
    .filter(r => r.name);
}
function parseCatalogJson(text, fallbackCategory="materials", sourceMeta={}){
  const raw = JSON.parse(text);
  const arr = Array.isArray(raw) ? raw : (Array.isArray(raw.items) ? raw.items : []);
  return arr.map(r => normalizeCatalogRow({
    ...r,
    source_type: sourceMeta.source_type || "json",
    source_file: sourceMeta.source_file || ""
  }, fallbackCategory)).filter(r => r.name);
}
function upsertCatalogProducts(state, rows){
  state.catalogState = state.catalogState || {products:[], lastSelectedProductId:""};
  const existing = new Map((state.catalogState.products||[]).map(p=>[p.id,p]));
  rows.forEach(r=> existing.set(r.id, createProductRecord(r)));
  state.catalogState.products = Array.from(existing.values());
  state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products);
}
function addCatalogRows(state, rows){
  upsertCatalogProducts(state, rows);
}
async function ensurePdfJs(){
  try{
    return await ensurePdfJsModule(APP_META.pdfJsUrl, APP_META.pdfJsWorkerUrl);
  }catch(err){
    throw new Error(err?.message || APP_COPY.pdfOfflineHelp);
  }
}
async function extractPdfText(file){
  const pdfjsLib = await ensurePdfJs();
  const data = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({data}).promise;
  const pages = [];
  for(let p=1;p<=pdf.numPages;p++){
    const page = await pdf.getPage(p);
    const content = await page.getTextContent();
    const buckets = new Map();
    (content.items||[]).forEach(item=>{
      const y = Math.round((item.transform?.[5]||0) * 2) / 2;
      const arr = buckets.get(y) || [];
      arr.push({x:item.transform?.[4]||0, str:item.str||""});
      buckets.set(y, arr);
    });
    const lines = Array.from(buckets.entries())
      .sort((a,b)=>b[0]-a[0])
      .map(([,items])=>items.sort((a,b)=>a.x-b.x).map(i=>i.str).join(' ').replace(/\s+/g,' ').trim())
      .filter(Boolean);
    pages.push(lines.join('\n'));
  }
  return pages.join('\n');
}
function parsePdfBidText(text, fallbackCategory="materials", sourceMeta={}){
  const lines = String(text||"").split(/\r?\n/).map(line=>line.replace(/\s+/g,' ').trim()).filter(Boolean);
  const rows = [];
  let currentCategory = fallbackCategory;
  const isCategoryLine = (line) => /^(?:\d+\s+)?(Herbicides|FUNGCICIDES|INSECTICIDES|BIO|SOIL|EQUIPMENT)\b/i.test(line);
  const categoryFromLine = (line) => {
    const m = line.match(/(Herbicides|FUNGCICIDES|INSECTICIDES|BIO|SOIL|EQUIPMENT)/i);
    return m ? normalizeCatalogCategory(m[1], fallbackCategory) : fallbackCategory;
  };
  const isNoise = (line) => /^(Bid|Bill To:|Ship To:|Quote#|Created|Printed|Line|#|Item #|Item Desc|Qty UOM|Unit Extended|Price|Job Name|Total Price:|Quoted price is for material only|Local tax may differ|%PDF|\/Parent|\/Resources|\/MediaBox|xref|stream|endstream|obj|endobj)/i.test(line);
  const isRowStart = (line) => /^(\d+\s+)?[A-Z0-9][A-Z0-9.-]{3,}\s+.+/.test(line) && !isNoise(line) && !isCategoryLine(line);
  let i = 0;
  while(i < lines.length){
    const line = lines[i];
    if(isCategoryLine(line)){ currentCategory = categoryFromLine(line); i++; continue; }
    if(isNoise(line)){ i++; continue; }
    if(!isRowStart(line)){ i++; continue; }
    const block = [line];
    let j = i + 1;
    while(j < lines.length && !isRowStart(lines[j]) && !isCategoryLine(lines[j]) && !/^Total Price:/i.test(lines[j])){
      block.push(lines[j]);
      j++;
    }
    const first = block[0].match(/^(?:(\d+)\s+)?([A-Z0-9][A-Z0-9.-]{3,})\s+(.+)$/);
    if(first){
      const [, lineNo, sku, descStart] = first;
      const product = {
        name: descStart,
        sku,
        price: 0,
        notes: lineNo ? `Line ${lineNo}` : "",
        category: currentCategory,
        source_type: 'pdf',
        source_file: sourceMeta.source_file || '',
        source_vendor: sourceMeta.source_vendor || '',
        source_quote_number: sourceMeta.source_quote_number || ''
      };
      let noteMode = false;
      const prices = [];
      for(let k=1;k<block.length;k++){
        const row = block[k];
        if(/^Item Note:/i.test(row)){
          noteMode = true;
          const cleaned = row.replace(/^Item Note:/i,'').trim();
          if(cleaned) product.notes += `${product.notes?'; ':''}${cleaned}`;
          continue;
        }
        const packed = row.match(/^(\d+)\s+(EA|BG|LB|GAL|OZ|QT|CS)\s+([\d,]+\.\d+)\s+([\d,]+\.\d+)$/i);
        if(packed){
          product.pack_size = `${packed[1]} ${packed[2].toUpperCase()}`;
          prices.push(parseMoneyValue(packed[3]), parseMoneyValue(packed[4]));
          noteMode = false;
          continue;
        }
        const packed3 = row.match(/^(\d+)\s+(EA|BG|LB|GAL|OZ|QT|CS)\s+([\d,]+\.\d+)$/i);
        if(packed3){
          product.pack_size = `${packed3[1]} ${packed3[2].toUpperCase()}`;
          prices.push(parseMoneyValue(packed3[3]));
          noteMode = false;
          continue;
        }
        if(/^[\d,]+\.\d+$/.test(row)){
          prices.push(parseMoneyValue(row));
          noteMode = false;
          continue;
        }
        if(/^(EA|BG|LB|GAL|OZ|QT|CS)$/i.test(row)){
          const qtyPart = product.pack_size ? product.pack_size.split(' ')[0] : '1';
          product.pack_size = `${qtyPart} ${row.toUpperCase()}`;
          noteMode = false;
          continue;
        }
        if(/^\d+$/.test(row) && !noteMode){
          const unitPart = product.pack_size ? product.pack_size.split(' ').slice(1).join(' ') : '';
          product.pack_size = `${row} ${unitPart}`.trim();
          continue;
        }
        if(noteMode) product.notes += `${product.notes?'; ':''}${row}`;
        else product.name += ` ${row}`;
      }
      if(prices.length) product.price = prices[prices.length-1];
      const normalized = normalizeCatalogRow(product, currentCategory);
      const badName = /^(0|Herbicides|FUNGCICIDES|INSECTICIDES|BIO|SOIL|EQUIPMENT)$/i.test(normalized.name);
      if(normalized.name && !badName) rows.push(normalized);
    }
    i = j;
  }
  return rows.filter(r=>r.name && !/^(Total Price|Quoted price)/i.test(r.name));
}
function buildImportBatch(rows, meta={}){
  return {
    id: `batch_${Date.now().toString(36)}`,
    source_type: meta.source_type || 'manual',
    source_file: meta.source_file || '',
    source_vendor: meta.source_vendor || '',
    source_quote_number: meta.source_quote_number || '',
    created_at: new Date().toISOString(),
    total_rows: rows.length
  };
}
function stageImportRows(state, rows, meta={}){
  state.importState = state.importState || {batch:null, stagingRows:[], warnings:[], duplicateMatches:[]};
  const existingProducts = state.catalogState?.products || [];
  const normalized = rows.map(row=>{
    const product = normalizeCatalogRow({...row, ...meta}, row.category || meta.category || 'materials');
    const dup = existingProducts.find(p => (p.sku && product.sku && p.sku.toLowerCase()===product.sku.toLowerCase()) || p.name.toLowerCase()===product.name.toLowerCase());
    if(dup){ product.warnings = [...product.warnings, `Possible duplicate of ${dup.name}`]; }
    return product;
  });
  state.importState.batch = buildImportBatch(normalized, meta);
  state.importState.stagingRows = normalized;
  state.importState.warnings = normalized.flatMap(r=>r.warnings||[]);
}
function commitStagedRows(state){
  const staged = (state.importState?.stagingRows||[]).filter(r=>r.include !== false);
  if(!staged.length) return 0;
  addCatalogRows(state, staged);
  state.importState = {...defaultState.importState};
  return staged.length;
}
const FORM_SCHEMAS = {
  dailyPositioning:[
    {id:"soilTemp", label:"4-inch soil temp (F)", type:"number", path:"soilTemp", requiredWhen:()=>true, visibleWhen:()=>true, calcRelevant:true}
  ],
  quoteLab:[
    {id:"qCustomer", label:"Customer name", type:"text", path:"currentQuote.customer", requiredWhen:(state)=>Boolean(state.currentQuote.email || state.currentQuote.phone), visibleWhen:()=>true},
    {id:"qAddress", label:"Address", type:"text", path:"currentQuote.address", requiredWhen:(state)=>Boolean(state.currentQuote.customer), visibleWhen:()=>true},
    {id:"qTurfSqft", label:"Turf square footage", type:"number", path:"currentQuote.turfSqft", requiredWhen:(state)=>Boolean(state.currentQuote.services?.turf?.selected), visibleWhen:()=>true, calcRelevant:true},
    {id:"qOrnSqft", label:"Ornamental square footage", type:"number", path:"currentQuote.ornamentalSqft", requiredWhen:(state)=>Boolean(state.currentQuote.services?.ornamental?.selected), visibleWhen:()=>true, calcRelevant:true},
    {id:"qPalmCount", label:"Recurring palm count", type:"number", path:"currentQuote.palmCount", requiredWhen:(state)=>Boolean(state.currentQuote.services?.palm?.selected), visibleWhen:()=>true, calcRelevant:true}
  ],
  catalogManual:[
    {id:"catalogName", label:"Item name", type:"text", path:"catalogManual.name", requiredWhen:()=>true, visibleWhen:()=>true},
    {id:"catalogPrice", label:"Unit price", type:"number", path:"catalogManual.price", requiredWhen:()=>true, visibleWhen:()=>true}
  ],
  manualSale:[
    {id:"manualSaleName", label:"Customer / reference", type:"text", path:"manualSale.name", requiredWhen:()=>true, visibleWhen:()=>true},
    {id:"manualSaleValue", label:"Value", type:"number", path:"manualSale.value", requiredWhen:()=>true, visibleWhen:()=>true}
  ]
};
function getValueByPath(obj, path){
  return String(path||'').split('.').reduce((acc, key)=>acc && acc[key] !== undefined ? acc[key] : undefined, obj);
}
function isBlankFieldValue(value, type){
  if(value===undefined || value===null) return true;
  if(type==='number') return value==='' || Number.isNaN(Number(value));
  return String(value).trim()==='';
}
function auditFormSchema(state, schemaKey){
  const fields = FORM_SCHEMAS[schemaKey] || [];
  return fields.map(field=>{
    const visible = field.visibleWhen ? !!field.visibleWhen(state) : true;
    const required = field.requiredWhen ? !!field.requiredWhen(state) : false;
    const value = field.path ? getValueByPath(state, field.path) : undefined;
    const missing = visible && required && isBlankFieldValue(value, field.type);
    const hiddenConflict = !visible && required;
    return {...field, visible, required, value, missing, hiddenConflict};
  });
}
function getValidationAudit(state){
  const sections = Object.keys(FORM_SCHEMAS).map(key=>({
    key,
    title: key==='dailyPositioning' ? 'Daily Positioning' : key==='quoteLab' ? 'Quote Lab' : key==='catalogManual' ? 'Catalog Manual Add' : 'Manual Sale',
    fields: auditFormSchema(state, key)
  }));
  const allFields = sections.flatMap(section=>section.fields.map(field=>({...field, section:section.title})));
  const missingRequired = allFields.filter(f=>f.missing);
  const hiddenRequired = allFields.filter(f=>f.hiddenConflict);
  const calcBlank = allFields.filter(f=>f.calcRelevant && f.visible && isBlankFieldValue(f.value, f.type));
  return {sections, missingRequired, hiddenRequired, calcBlank};
}
function renderValidationAudit(state, audit){
  return `<div class="card" style="margin-top:14px"><div class="row space"><div><div class="kicker">Validation Audit</div><div class="small">Build 33 schema check: required fields, visibility rules, and calculation inputs now come from one audit path.</div></div><div class="small">Missing required: ${audit.missingRequired.length} | Hidden conflicts: ${audit.hiddenRequired.length}</div></div>
    <div class="grid3" style="margin-top:12px">
      <div class="serviceCard"><strong>Visible required fields</strong><div class="small" style="margin-top:8px">${audit.sections.map(section=>`${section.title}: ${section.fields.filter(f=>f.visible && f.required).map(f=>f.label).join(', ') || 'None'}`).join('<br>')}</div></div>
      <div class="serviceCard"><strong>Missing right now</strong><div class="small" style="margin-top:8px">${audit.missingRequired.length ? audit.missingRequired.map(f=>`${f.section}: ${f.label}`).join('<br>') : 'None'}</div></div>
      <div class="serviceCard"><strong>Hidden-required conflicts</strong><div class="small" style="margin-top:8px">${audit.hiddenRequired.length ? audit.hiddenRequired.map(f=>`${f.section}: ${f.label}`).join('<br>') : 'None'}</div></div>
    </div>
  </div>`;
}
function render(){
  const state = loadState();
  dailyRefresh(state);
  const intel = intelligence(state), totals = quoteTotals(state), metrics = materialMetrics(state), sw = seasonalWindow(state), estText = buildEstimateText(state, totals, intel), validationAudit = getValidationAudit(state);
  state.validationState.lastAuditAt = new Date().toISOString();
  state.validationState.lastView = state.view;
  saveState(state);
  const nav = document.getElementById("nav");
  const views = [["dashboard","Dashboard"],["builder","Turf Builder"],["builder-orn","Ornamental Builder"],["builder-special","Special Builder"],["quote","Quote Lab"],["operations","Operations"],["catalog","Vendor Catalog"],["orders","Order Sheet"],["labels","Label Center"],["history","Estimate History"],["regression","Regression Pack"]];
  nav.innerHTML = views.map(([k,l])=>{
    const active = (k === "builder" && state.view === "builder" && (state.builderMode || "turf") === "turf") || (k === "builder-orn" && state.view === "builder" && state.builderMode === "ornamental") || (k === "builder-special" && state.view === "builder" && state.builderMode === "special") || state.view === k;
    return `<button class="navbtn ${active?'active':''}" data-view="${k}">${l}</button>`;
  }).join("");
  nav.querySelectorAll(".navbtn").forEach(btn=>btn.onclick=()=>{ 
    if(btn.dataset.view === "builder-orn"){
      state.view = "builder";
      state.builderMode = "ornamental";
    } else if(btn.dataset.view === "builder-special"){
      state.view = "builder";
      state.builderMode = "special";
    } else if(btn.dataset.view === "builder"){
      state.view = "builder";
      state.builderMode = "turf";
    } else {
      state.view = btn.dataset.view;
    }
    saveState(state); render(); 
  });
  let html = "";
  if(state.view==="dashboard"){
    html = `<h2>Cockpit Overview</h2><div class="sub">Unified design and quoting build for desktop and mobile, with faster quoting and vendor catalog support.</div>
    <div class="grid4">
      <div class="card stat"><div class="label">Daily Positioning</div><div class="value">${sw ? sw.mode : "Waiting on soil temp input"}</div><div class="small">${state.lastDailyRefresh || 'No soil reading saved yet'}</div></div>
      <div class="card stat"><div class="label">Material Cost / Tank</div><div class="value">${money(metrics.perTank)}</div></div>
      <div class="card stat"><div class="label">Quote Monthly Total</div><div class="value">${money(totals.total)}</div></div>
      <div class="card stat"><div class="label">Saved Estimates</div><div class="value">${state.history.length}</div></div>
    </div>
    <div class="gridMain" style="margin-top:14px">
      <div class="card"><div class="kicker">Optimization Positioning</div><div class="note">${intel.science}</div><div class="note" style="margin-top:10px">${currentFact()}</div></div>
      <div class="card"><div class="kicker">Daily Positioning Input</div><h2>Field-Driven Timing</h2><label class="small" style="display:block;margin:10px 0 4px">Current 4-inch soil temperature (F)</label><input id="soilInput" type="number" placeholder="Enter current soil temp" value="${state.soilTemp}"><div class="small" style="margin-top:8px">This field is now visible whenever the app expects a soil temperature for daily positioning logic.</div><div class="note" style="margin-top:10px"><strong>Current summary:</strong> ${sw ? advisory(state).summary : 'Enter the current soil temperature to unlock the timing summary.'}</div></div>
    </div>
    <div class="card" style="margin-top:14px">
      <div class="kicker">Data Safety</div>
      <div class="grid2" style="align-items:end">
        <div>
          <div class="note"><strong>Last saved:</strong> ${state.appMeta?.lastSavedAt ? new Date(state.appMeta.lastSavedAt).toLocaleString() : 'Not saved yet in this session.'}</div>
          <div class="note" style="margin-top:8px"><strong>Last backup export:</strong> ${state.appMeta?.lastBackupAt ? new Date(state.appMeta.lastBackupAt).toLocaleString() : 'No backup exported yet.'}</div>
          <div class="note" style="margin-top:8px"><strong>Last restore:</strong> ${state.appMeta?.lastRestoreAt ? new Date(state.appMeta.lastRestoreAt).toLocaleString() : 'No backup restored yet.'}</div>
          <label class="toggle" style="margin-top:12px"><input id="autoBackupOnSave" type="checkbox" ${state.settings?.autoBackupOnSave ? "checked" : ""}><span class="small">Auto-export backup on save every 5 minutes max</span></label>
          <div class="small" style="margin-top:10px">Backups include quotes, catalog data, inventory settings, labels, programs, and order sheet drafts.</div>
        </div>
        <div class="btnrow" style="justify-content:flex-end">
          <button class="btn primary" id="exportBackup">Export Backup</button>
          <button class="btn" id="importBackupTrigger">Import Backup</button>
          <button class="btn" id="resetAppData">Reset App Data</button>
          <input id="importBackupFile" type="file" accept=".json,application/json" class="hidden">
        </div>
      </div>
    </div>${renderValidationAudit(state, validationAudit)}`;
  } else if(state.view==="builder"){
    const mode = state.builderMode || "turf";
    const specialTreatment = specialsCatalog.find(s=>s.key === (state.selectedSpecialTreatment || 'newSod')) || specialsCatalog[0];
    const current = activeProgramRecord(state, mode);
    const metricsBuilder = materialMetrics(state, mode);
    const avgSqft = mode === "ornamental" ? Number(state.forecasts?.avgOrnSqft||3000) : mode === "special" ? Number(state.forecasts?.avgSpecialSqft||3000) : Number(state.forecasts?.avgTurfSqft||5000);
    const actualSellPer1000 = mode === "ornamental" ? ornamentalVisitSellPer1000(state, avgSqft) : mode === "special" ? Number(state.actualSell?.specialsPer1000||0) : turfVisitSellPer1000(state, avgSqft);
    const actualRevenuePerTank = actualSellPer1000 * ((Number(current?.tankCoverageSqft||0)) / 1000);
    const actualProfitPerTank = actualRevenuePerTank - metricsBuilder.perTank;
    const actualMarginPerTank = actualRevenuePerTank > 0 ? (actualProfitPerTank / actualRevenuePerTank) * 100 : 0;
    const projectedUsage = forecastMaterialUsage(state, mode);
    const projectedTanks = projectedUsage.length ? (forecastEffectiveSqft(state, mode) / (Number(current?.tankCoverageSqft||1)||1)) : 0;
    const projectedCost = projectedUsage.reduce((s,r)=>s+r.cost,0);
    const builderTitle = mode === "ornamental" ? "Ornamental Program Builder" : mode === "special" ? `${specialTreatment?.name || 'Special Treatment'} Builder` : "Turf Program Builder";
    const builderSub = mode === "ornamental"
      ? "Build ornamental chemistry separately from turf so shrub and bed care can follow its own products, coverage, and profit logic."
      : mode === "special"
        ? "Build special treatment chemistry with the same template, forecasting, and product-line controls used in turf and ornamental builders."
        : "Build turf chemistry separately from ornamentals so lawn pricing and tank performance stay on their own track.";
    html = `<div class="row space"><div><h2>${builderTitle}</h2><div class="sub">${builderSub}</div></div><div class="btnrow"><button class="btn ${mode==="turf"?"primary":""}" id="builderModeTurf">Turf Builder</button><button class="btn ${mode==="ornamental"?"primary":""}" id="builderModeOrnamental">Ornamental Builder</button><button class="btn ${mode==="special"?"primary":""}" id="builderModeSpecial">Special Builder</button></div></div>
    <div class="card" style="margin-top:14px"><div class="kicker">Builder Split</div><div class="note">Turf, ornamentals, and special treatments now use separate builder tracks so each program type can keep its own templates, coverage, and chemistry logic.</div></div>
    ${mode === "special" ? `<div class="card" style="margin-top:14px"><div class="kicker">Special Treatment Type</div><div class="grid2" style="align-items:end"><div><label class="small" style="display:block;margin-bottom:4px">Treatment</label><select id="specialTreatmentSelect">${specialsCatalog.map(s=>`<option value="${s.key}" ${s.key===specialTreatment?.key?'selected':''}>${s.name}</option>`).join("")}</select><div class="small" style="margin-top:6px">Each special treatment keeps its own templates and saved programs.</div></div><div class="note">Use the same builder flow here as turf and ornamentals: choose the treatment, manage the template, forecast materials, and build the product list.</div></div></div>` : ''}
    <div class="grid4">
      <div class="card stat"><div class="label">Material Cost / Acre</div><div class="value">${money(metricsBuilder.perAcre)}</div></div>
      <div class="card stat"><div class="label">Total Program Cost / Tank</div><div class="value">${money(metricsBuilder.perTank)}</div><div class="small">Coverage: ${Number(current?.tankCoverageSqft||0).toLocaleString()} sq ft</div></div>
      <div class="card stat"><div class="label">Material Cost / 1,000</div><div class="value">${money(metricsBuilder.per1000)}</div></div>
      <div class="card stat"><div class="label">Actual ${mode === "ornamental" ? "Ornamental" : mode === "special" ? "Special Treatment" : "Turf"} Margin / Tank</div><div class="value">${actualMarginPerTank.toFixed(1)}%</div><div class="small">Gross profit: ${money(actualProfitPerTank)} / tank</div></div>
    </div>
    <div class="card" style="margin-top:14px">
      <div class="kicker">Program Templates</div>
      ${(()=>{ const currentKey = activeProgramKey(state, mode); const currentProgram = activeProgramRecord(state, mode) || {}; const collectionKeys = Object.keys(activeProgramCollection(state, mode) || {}); const canDeleteCurrent = Boolean(currentKey && currentProgram && collectionKeys.length > 1); const savedTemplates = getManualTemplatePrograms(state, mode).filter(t=>t.key!==currentKey); const hasSavedTemplates = savedTemplates.length>0; return hasSavedTemplates ? `<div class="grid3">
        <div><label class="small" style="display:block;margin-bottom:4px">Current ${mode === "ornamental" ? "ornamental" : mode === "special" ? "special treatment" : "turf"} program</label><select id="programSelect"><option value="">Select program</option>${Object.entries(activeProgramCollection(state, mode)).map(([k,v])=>`<option value="${k}" ${currentKey===k?'selected':''}>${v.name}</option>`).join("")}</select><div class="small" style="margin-top:6px">${mode === "ornamental" ? "Ornamental templates stay separate from turf templates." : mode === "special" ? "Templates stay separate for each special treatment type." : "Turf templates stay separate from ornamental templates."}</div></div>
        <div><label class="small" style="display:block;margin-bottom:4px">Load saved template</label><select id="templateSelect"><option value="">Select saved program</option>${savedTemplates.map(t=>`<option value="${t.key}">${t.name}</option>`).join("")}</select><div class="small" style="margin-top:6px">Templates come only from manually saved or previously built ${mode === "special" ? "special treatment" : mode} programs.</div></div>
        <div class="btnrow" style="align-items:end"><button class="btn primary" id="applyTemplate">Apply Saved Template</button><button class="btn" id="saveAsNewProgram">Save As New Program</button>${canDeleteCurrent?`<button class="btn" id="deleteCurrentProgram">Delete Current Program</button>`:''}<button class="btn" id="deleteSelectedTemplate" ${savedTemplates.length?'':'disabled'}>Delete Selected Saved Template</button></div>
      </div>` : `<div class="grid2">
        <div><label class="small" style="display:block;margin-bottom:4px">Current ${mode === "ornamental" ? "ornamental" : mode === "special" ? "special treatment" : "turf"} program</label><select id="programSelect"><option value="">Select program</option>${Object.entries(activeProgramCollection(state, mode)).map(([k,v])=>`<option value="${k}" ${currentKey===k?'selected':''}>${v.name}</option>`).join("")}</select><div class="small" style="margin-top:6px">${mode === "ornamental" ? "Ornamental templates stay separate from turf templates." : mode === "special" ? "Templates stay separate for each special treatment type." : "Turf templates stay separate from ornamental templates."}</div></div>
        <div><div class="small" style="margin:26px 0 10px 0">No saved ${mode === "special" ? "special treatment" : mode} templates yet. Use Save As New Program to create one first.</div><div class="btnrow"><button class="btn" id="saveAsNewProgram">Save As New Program</button>${canDeleteCurrent?`<button class="btn" id="deleteCurrentProgram">Delete Current Program</button>`:''}</div></div>
      </div>`; })()}
    </div>
    <div class="card" style="margin-top:14px">
      <div class="kicker">Material Forecasting</div>
      <div class="grid4">
        <div><label class="small" style="display:block;margin-bottom:4px">Properties</label><input id="forecastProperties" type="number" value="${state.forecasts.properties}"></div>
        <div><label class="small" style="display:block;margin-bottom:4px">Avg ${mode === "ornamental" ? "Ornamental" : mode === "special" ? "Special Treatment" : "Turf"} Sq Ft</label><input id="${mode === "ornamental" ? "forecastAvgOrn" : mode === "special" ? "forecastAvgSpecial" : "forecastAvgTurf"}" type="number" value="${avgSqft}"></div>
        <div><label class="small" style="display:block;margin-bottom:4px">Tank Coverage Sq Ft</label><input id="builderCoverageSqft" type="number" value="${Number(current?.tankCoverageSqft||0)}"></div>
        <div><label class="small" style="display:block;margin-bottom:4px">Actual ${mode === "ornamental" ? "Ornamental" : mode === "special" ? "Special Treatment" : "Turf"} Sell / 1,000</label><input id="${mode === "ornamental" ? "actualSellOrn" : mode === "special" ? "actualSellSpecial" : "actualSellTurf"}" type="number" step="0.01" value="${actualSellPer1000}"></div>
      </div>
      <div class="grid4" style="margin-top:12px"><div class="rowline"><span class="label">Projected Tanks</span><span class="value">${projectedTanks.toFixed(2)}</span></div><div class="rowline"><span class="label">Projected Program Cost</span><span class="value">${money(projectedCost)}</span></div><div class="rowline"><span class="label">Forecast Basis</span><span class="value">${forecastBasisLabel(state, mode)}</span></div><div style="display:flex;align-items:center;justify-content:flex-end"><button class="btn" id="forecastToOrderSheet">Add Forecast to Order Sheet</button></div></div><div class="scrollTable" style="margin-top:12px"><table class="table"><thead><tr><th>Product</th><th>Projected Qty</th><th>Projected Cost</th></tr></thead><tbody>
      ${projectedUsage.map(r=>`<tr><td>${r.name}</td><td>${r.qty.toFixed(2)} ${String(r.unit).split(" per ")[0]}</td><td>${money(r.cost)}</td></tr>`).join("")}
      </tbody></table></div>
    </div>
    <div class="card" style="margin-top:14px"><div class="grid2" style="align-items:end"><div><label class="small" style="display:block;margin-bottom:4px">Material search</label><input id="newLineProductSearch" placeholder="Search by material, SKU, active, or function" value="${escapeHtml((state.programProductSearch||{})[mode === 'ornamental' ? 'ornamental' : mode === 'special' ? 'special' : 'turf'] || '')}"><div class="small" style="margin-top:6px">${filteredProgramProducts(state, mode).length} match(es) in product selection.</div></div><div><label class="small" style="display:block;margin-bottom:4px">Product</label><select id="newLineProduct"><option value="">Select product</option>${filteredProgramProducts(state, mode).map(p=>`<option value="${p.sku}" ${state.orderBuilder?.sku===p.sku?'selected':''}>${productLabel(p)}</option>`).join("")}</select><div class="small" style="margin-top:6px">Choose one product, add it, then adjust the line only if needed. Rate changes now save as you type and persist through save/reload.</div></div></div><div class="btnrow" style="margin-top:10px"><button class="btn primary" id="addLine">Add to Program</button></div>
    <div style="margin-top:12px;display:grid;gap:10px">
    ${(current?.lines||[]).map((line,idx)=>`<div class="serviceCard" style="padding:12px">
      <div class="row space" style="align-items:flex-start;gap:12px">
        <div style="flex:1;min-width:0">
          <div><strong>${productLabel(state.labels[line.sku] || {sku:line.sku,name:line.sku})}</strong></div>
          <div class="small" style="margin-top:4px">${Number(line.rate||0)} ${lineUnitOnly(line)} per ${lineCarrier(line)} · Chemical cost: ${money(lineChemicalCost(state, line))}</div>
          <div class="small" style="margin-top:4px">${(state.labels[line.sku]||{}).active || 'No active/function listed'}${(state.labels[line.sku]||{}).npk?` · NPK: ${(state.labels[line.sku]||{}).npk}`:""}</div>
          ${((state.labels[line.sku]||{}).warning)?`<div class="small" style="margin-top:4px">${(state.labels[line.sku]||{}).warning}</div>`:''}
        </div>
        <div class="btnrow" style="justify-content:flex-end">
          <button class="btn" data-line-edit-toggle="${idx}">${isProgramLineExpanded(state, idx, mode) ? 'Close' : 'Edit'}</button>
          <button class="btn" data-delete-line="${idx}">Remove</button>
        </div>
      </div>
      ${isProgramLineExpanded(state, idx, mode) ? `<div class="grid3" style="margin-top:12px"><div><label class="small" style="display:block;margin-bottom:4px">Rate</label><input type="number" step="0.01" value="${line.rate}" data-line-rate="${idx}"></div><div><label class="small" style="display:block;margin-bottom:4px">Unit</label><select data-line-uom="${idx}"><option value="oz" ${lineUnitOnly(line)==='oz'?'selected':''}>oz</option><option value="lb" ${lineUnitOnly(line)==='lb'?'selected':''}>lb</option><option value="gal" ${lineUnitOnly(line)==='gal'?'selected':''}>gal</option><option value="mL" ${lineUnitOnly(line)==='mL'?'selected':''}>mL</option></select></div><div><label class="small" style="display:block;margin-bottom:4px">Per</label><select data-line-carrier="${idx}"><option value="150-gal tank" ${lineCarrier(line)==='150-gal tank'?'selected':''}>150-gal tank</option><option value="50-gal shrub tank" ${lineCarrier(line)==='50-gal shrub tank'?'selected':''}>50-gal shrub tank</option><option value="4-gal electric backpack" ${lineCarrier(line)==='4-gal electric backpack'?'selected':''}>4-gal electric backpack</option></select></div></div>` : ''}
    </div>`).join("") || `<div class="small">No products in this program yet.</div>`}
    </div></div>`;
  } else if(state.view==="quote"){

    const q = state.currentQuote;
    html = `<div class="row space"><div><h2>Quote Lab</h2><div class="btnrow" style="margin-top:6px"><button class="btn" id="smartDefaults">Apply Smart Defaults</button></div><div class="sub">Build your quote, monthly pricing, and notes in one place without auto-generated marketing copy.</div></div></div>
    <div class="grid2">
      <div class="card">
        <div class="grid2"><input id="qCustomer" placeholder="Customer name" value="${q.customer}"><input id="qAddress" placeholder="Address" value="${q.address}"></div>
        <div class="grid2" style="margin-top:10px"><input id="qPhone" placeholder="Phone number" value="${q.phone}"><input id="qEmail" placeholder="Email" value="${q.email}"></div>
        <div class="grid4" style="margin-top:10px"><div><label class="small" style="display:block;margin-bottom:4px">Turf square footage</label><input id="qTurfSqft" type="number" value="${q.turfSqft}" placeholder="5000"></div><div><label class="small" style="display:block;margin-bottom:4px">Ornamental square footage</label><input id="qOrnSqft" type="number" value="${q.ornamentalSqft}" placeholder="3000"></div><div><label class="small" style="display:block;margin-bottom:4px">Shrub density</label><select id="qOrnDensity"><option value="low" ${ornamentalDensityTier(q.ornamentalDensity)==="low"?"selected":""}>Low</option><option value="medium" ${ornamentalDensityTier(q.ornamentalDensity)==="medium"?"selected":""}>Medium</option><option value="high" ${ornamentalDensityTier(q.ornamentalDensity)==="high"?"selected":""}>High</option></select></div><div><label class="small" style="display:block;margin-bottom:4px">Recurring palm count</label><input id="qPalmCount" type="number" value="${q.palmCount}" placeholder="8"></div></div><div class="small" style="margin-top:8px">Ornamental pricing now uses shrub density tiers: low, medium, or high.</div>
        <div style="margin-top:10px"><textarea id="qNotes" placeholder="Program notes">${q.notes}</textarea></div>
        <div style="margin-top:10px"><label class="small" style="display:block;margin-bottom:4px">Project Notes / Instructions</label><textarea id="qCustomNotes" placeholder="Gate code, irrigation notes, pets, access issues, customer requests, or other important instructions">${q.customNotes}</textarea></div>
        <div class="toggle" style="margin-top:12px"><input id="qIncludeBlurb" type="checkbox" ${q.includeBlurb?"checked":""}><label>Include notes</label></div>
        <div class="card" style="margin-top:12px;padding:12px;border:1px solid rgba(255,255,255,.12)">
          <div class="kicker">Manual Discount</div>
          <div class="small" style="margin:4px 0 8px 0">Apply only when requested.</div>
          <select id="qManualDiscount"><option value="0" ${Number(q.manualDiscountPct||0)===0?"selected":""}>None</option><option value="5" ${Number(q.manualDiscountPct||0)===5?"selected":""}>5%</option><option value="10" ${Number(q.manualDiscountPct||0)===10?"selected":""}>10%</option></select>
        </div>
        <div class="btnrow" style="margin-top:14px">
          <button class="btn primary" id="saveEstimatePdf">Open Customer Estimate PDF</button>
          <button class="btn" id="savePricingPdf">Open Pricing Snapshot PDF</button>
          <button class="btn" id="shareEstimate">Share Estimate</button>
          <button class="btn" id="emailEstimate">Email</button>
          <button class="btn" id="textEstimate">Text</button>
          <button class="btn" id="downloadEstimateText">Download Estimate TXT</button>
        </div>
      </div>
      <div class="card"><div class="kicker">Quote Totals</div>
        <div class="rowline"><span class="label">Manual Discount Selection</span><span class="value">${Number(q.manualDiscountPct||0) ? `${Number(q.manualDiscountPct||0)}%` : "None"}</span></div>
        <div class="rowline"><span class="label">Core Programs → Turf (monthly, 12x/year)</span><span class="value">${money(totals.turfRev)}</span></div>
        <div class="rowline"><span class="label">Core Programs → Ornamental (monthly, 12x/year)</span><span class="value">${money(totals.ornRev)}</span></div>
        <div class="rowline"><span class="label">Core Programs → Palm (monthly, 12x/year)</span><span class="value">${money(totals.palmRev.price)}</span></div>
        ${totals.specialsRows.map(r=>`<div class="rowline"><span class="label">${r.name}</span><span class="value">${money(r.price)}</span></div>`).join("")}
        <div class="rowline"><span class="label">Subtotal</span><span class="value">${money(totals.subtotal)}</span></div>
        ${totals.discountPct?`<div class="rowline"><span class="label">Manual Discount (${totals.discountPct}%)</span><span class="value">-${money(totals.discountAmount)}</span></div>`:""}
        ${totals.minimumServiceAdjustment?`<div class="rowline"><span class="label">Minimum Service Charge</span><span class="value">${money(totals.minimumServiceAdjustment)}</span></div>`:""}
        <div class="rowline"><span class="label">Quoted Revenue</span><span class="value">${money(totals.total)}</span></div>
        <div class="rowline"><span class="label">Modeled Cost</span><span class="value">${money(totals.metrics.cost)}</span></div>
        <div class="rowline"><span class="label">Turf Modeled Cost</span><span class="value">${money(totals.metrics.cost_breakdown?.turf || 0)}</span></div>
        <div class="rowline"><span class="label">Ornamental Modeled Cost</span><span class="value">${money(totals.metrics.cost_breakdown?.ornamental || 0)}</span></div>
        <div class="rowline"><span class="label">Palm Modeled Cost</span><span class="value">${money(totals.metrics.cost_breakdown?.palm || 0)}</span></div>
        ${(totals.metrics.cost_breakdown && totals.metrics.cost_breakdown.specials) ? `<div class="rowline"><span class="label">Specials Modeled Cost</span><span class="value">${money(totals.metrics.cost_breakdown.specials)}</span></div>` : ""}
        <div class="rowline"><span class="label">Gross Profit</span><span class="value">${money(totals.metrics.profit_after_discount)}</span></div>
        <div class="rowline"><span class="label">Gross Margin</span><span class="value">${totals.metrics.margin_after_discount_pct.toFixed(1)}%</span></div>
        <div class="rowline"><span class="label">MRR (recurring only)</span><span class="value">${money(totals.metrics.mrr)}</span></div>
        <div class="rowline"><span class="label">ARR (recurring only)</span><span class="value">${money(totals.metrics.arr)}</span></div>
        <div class="rowline"><span class="label">Annual Revenue (incl. one-time once)</span><span class="value">${money(totals.metrics.annual_revenue_total)}</span></div>
        <div class="rowline"><span class="label">Total</span><span class="value">${money(totals.total)}</span></div>
      </div>
    </div>
    <div class="card" style="margin-top:14px"><div class="kicker">Recommended Services</div><div class="grid3">
      ${Object.entries(q.services).map(([k,s])=>`<div class="serviceCard"><div class="toggle"><input type="checkbox" data-service-check="${k}" ${s.selected?"checked":""}><label>${k==="turf"?"Turf Program":k==="ornamental"?"Ornamental Program":"Palm Program"}</label></div><div class="note" style="margin-top:8px">${s.description}</div><textarea data-service-notes="${k}" placeholder="Service-specific notes" style="margin-top:8px">${s.notes||""}</textarea></div>`).join("")}
    </div></div>
    <div class="card" style="margin-top:14px"><div class="kicker">Special Treatments</div><div class="grid2">
      ${specialsCatalog.map(s=>{ const e=q.specials[s.key]; return `<div class="serviceCard"><div class="toggle"><input type="checkbox" data-special-check="${s.key}" ${e.selected?"checked":""}><label>${s.name}</label></div><div class="note" style="margin-top:8px">${s.description}</div>${s.mode==="oak"?`<div class="small" style="margin-top:10px">DBH entry</div><label class="small" style="display:block;margin-top:6px">Tree diameters at breast height (inches), separated by commas</label><input data-special-dbh="${s.key}" value="${e.dbh||""}" placeholder="Example: 12, 18, 24"><div class="small" style="margin-top:6px">Enter one DBH value for each oak tree.</div>`:s.mode==="palm"?`<div class="small" style="margin-top:10px">Palm height quantities</div><div class="grid2" style="margin-top:8px"><div><label class="small" style="display:block;margin-bottom:4px">Number of palms up to 15 ft</label><input type="number" data-palm-h="${s.key}|upTo15" value="${e.palmHeights.upTo15||0}" placeholder="0"></div><div><label class="small" style="display:block;margin-bottom:4px">Number of palms 15 to 30 ft</label><input type="number" data-palm-h="${s.key}|ft15to30" value="${e.palmHeights.ft15to30||0}" placeholder="0"></div><div><label class="small" style="display:block;margin-bottom:4px">Number of palms 30 to 45 ft</label><input type="number" data-palm-h="${s.key}|ft30to45" value="${e.palmHeights.ft30to45||0}" placeholder="0"></div><div><label class="small" style="display:block;margin-bottom:4px">Number of palms over 45 ft</label><input type="number" data-palm-h="${s.key}|ft45plus" value="${e.palmHeights.ft45plus||0}" placeholder="0"></div></div>`:`<div class="small" style="margin-top:10px">Service price</div><label class="small" style="display:block;margin-top:6px">Quoted price for this treatment</label><input type="number" data-special-price="${s.key}" value="${e.price}" style="margin-top:4px" placeholder="0"></input>`}<label class="small" style="display:block;margin-top:10px">Notes for this service</label><textarea data-special-notes="${s.key}" placeholder="Notes for this service" style="margin-top:6px">${e.notes||""}</textarea><div class="btnrow" style="margin-top:10px"><button class="btn" data-open-special-builder="${s.key}">Open Builder</button></div></div>`; }).join("")}
    </div></div>
    <div class="card" style="margin-top:14px"><div class="kicker">Calculation Breakdown</div>
      <div class="scrollTable"><table class="table"><thead><tr><th>Service</th><th>Type</th><th>Freq</th><th>Visits</th><th>Revenue</th><th>Cost</th><th>Profit</th><th>Margin</th><th>ARR</th></tr></thead><tbody>
      ${totals.metrics.rows.map(r=>`<tr><td>${r.name}</td><td>${r.recurring?"Recurring":"One-Time"}</td><td>${r.frequency||""}</td><td>${r.annual_visits}</td><td>${money(r.revenue)}</td><td>${money(r.cost)}</td><td>${money(r.profit)}</td><td>${r.margin_pct.toFixed(1)}%</td><td>${money(r.recurring ? r.arr_component : r.revenue)}</td></tr>`).join("") || `<tr><td colspan="9">No services selected.</td></tr>`}
      </tbody></table></div>
      <div style="margin-top:12px">${totals.metrics.flags.length ? totals.metrics.flags.map(f=>`<div class="serviceCard" style="margin-top:8px;border-color:${f.level==='bad'?'#8a3f3f':'#6b5831'}"><strong>${f.level.toUpperCase()}</strong> — ${f.message}</div>`).join("") : `<div class="note">No calculation warnings detected in this quote.</div>`}</div>
    </div>
    <div class="sheet" style="margin-top:14px"><div class="kicker">Estimate Preview</div><div class="pdfPreview">
      <div class="pdfHeader"><img src="logo-white-ver.webp" class="pdfLogo"><div><h3 class="pdfH">Customer Estimate</h3><div class="pdfSub">Program Architect | Precision plant health design</div></div></div>
      <div class="pdfMeta">${q.customer||"Customer"}<br>${q.address||""}${q.phone?`<br>${q.phone}`:""}${q.email?`<br>${q.email}`:""}<br>Turf Sq Ft: ${q.turfSqft||0} | Ornamental Sq Ft: ${q.ornamentalSqft||0} | Shrub Density: ${ornamentalDensityLabel(q.ornamentalDensity)} | Palm Count: ${q.palmCount||0}</div>
      <table class="pdfTable"><thead><tr><th>Recommended Service</th><th>Description</th><th>Price</th></tr></thead><tbody>
        ${q.services.turf.selected?`<tr><td>Turf Program (Monthly – 12 applications/year)</td><td>${q.services.turf.description}<div style="font-size:11px;color:#555">${q.services.turf.notes||""}</div></td><td>${money(totals.turfRev)}</td></tr>`:""}
        ${q.services.ornamental.selected?`<tr><td>Ornamental Program (Monthly – 12 visits/year)</td><td>${q.services.ornamental.description}<div style="font-size:11px;color:#555">${q.services.ornamental.notes||""}</div></td><td>${money(totals.ornRev)}</td></tr>`:""}
        ${q.services.palm.selected?`<tr><td>Palm Program (Monthly – 12 visits/year)</td><td>${q.services.palm.description}<div style="font-size:11px;color:#555">${q.services.palm.notes||""}</div></td><td>${money(totals.palmRev.price)}</td></tr>`:""}
        ${totals.specialsRows.map(r=>`<tr><td>${r.name}</td><td>${r.description}<div style="font-size:11px;color:#555">${r.detail||""}</div><div style="font-size:11px;color:#555">${r.notes||""}</div></td><td>${money(r.price)}</td></tr>`).join("")}
        <tr><td><strong>Subtotal</strong></td><td></td><td><strong>${money(totals.subtotal)}</strong></td></tr>
        ${totals.discountPct?`<tr><td>Manual Discount (${totals.discountPct}%)</td><td>Applied on request</td><td>-${money(totals.discountAmount)}</td></tr>`:""}
        <tr><td><strong>Total</strong></td><td></td><td><strong>${money(totals.total)}</strong></td></tr>
      </tbody></table>
      ${q.includeBlurb && (q.notes||q.customNotes)?`<div class="pdfBox"><strong>Notes</strong><br><br>${[q.notes,q.customNotes].filter(Boolean).join("<br><br>")}</div>`:""}<div class="pdfBox"><strong>Acceptance & Authorization:</strong><br><br>Client Signature: ________________________________<br>Date: ________________________________</div><div class="note"><strong>Office delivery contact:</strong> ${APP_COPY.officeDeliveryContact}</div></div></div>`;
  } else if(state.view==="regression") {
    html = renderRegressionPack(state);
  } else if(state.view==="operations"){
    const accepted = state.history.filter(r => r.accepted);
    const pending = state.history.filter(r => !r.accepted);
    const acceptedRevenue = accepted.reduce((s,r)=>s+Number(r.finalSoldValue || r.total || 0),0);
    const manualRevenue = (state.manualSales||[]).reduce((s,r)=>s+Number(r.value||0),0);
    const pipelineValue = pending.reduce((s,r)=>s+Number(r.total||0),0);
    const totalRevenue = acceptedRevenue + manualRevenue;
    const closeRate = state.history.length ? ((accepted.length/state.history.length)*100) : 0;
    const avgEstimate = state.history.length ? state.history.reduce((s,r)=>s+Number(r.total||0),0)/state.history.length : 0;
    const avgSold = accepted.length ? accepted.reduce((s,r)=>s+Number(r.finalSoldValue||r.total||0),0)/accepted.length : 0;
    const recurringCount = accepted.filter(r => (r.services?.turf?.selected || r.services?.ornamental?.selected || r.services?.palm?.selected)).length;
    const oneTimeCount = accepted.filter(r => (r.specials && Object.values(r.specials).some(x => x && x.selected)) && !(r.services?.turf?.selected || r.services?.ornamental?.selected || r.services?.palm?.selected)).length;
    const revByCat = {turf:0, ornamental:0, palm:0, specials:0};
    accepted.forEach(r=>{
      const total = Number(r.finalSoldValue || r.total || 0);
      const cats = [];
      if(r.services && r.services.turf && r.services.turf.selected) cats.push("turf");
      if(r.services && r.services.ornamental && r.services.ornamental.selected) cats.push("ornamental");
      if(r.services && r.services.palm && r.services.palm.selected) cats.push("palm");
      if(r.specials && Object.values(r.specials).some(x => x && x.selected)) cats.push("specials");
      const share = cats.length ? total / cats.length : 0;
      cats.forEach(c => revByCat[c] += share);
    });
    (state.manualSales||[]).forEach(r=>{
      const c = ["turf","ornamental","palm","specials"].includes(r.category) ? r.category : "specials";
      revByCat[c] += Number(r.value||0);
    });
    html = `<div class="row space"><div><h2>Operations</h2><div class="sub">Auto-fed monthly business numbers with manual override only when needed.</div></div></div>
    <div class="btnrow" style="margin-bottom:14px">
      <button class="btn primary" id="opsReportPdf">Open Operations Report PDF</button>
      <button class="btn" id="opsReportEmail">Email Operations Report</button>
      <button class="btn" id="opsExportText">Download Operations TXT</button>
    </div>
    <div class="grid4">
      <div class="card stat"><div class="label">Total Monthly Revenue</div><div class="value">${money(totalRevenue)}</div></div>
      <div class="card stat"><div class="label">Accepted Monthly Revenue</div><div class="value">${money(acceptedRevenue)}</div></div>
      <div class="card stat"><div class="label">Manual Monthly Revenue</div><div class="value">${money(manualRevenue)}</div></div>
      <div class="card stat"><div class="label">Pipeline Monthly Value</div><div class="value">${money(pipelineValue)}</div></div>
    </div>
    <div class="grid4" style="margin-top:14px">
      <div class="card stat"><div class="label">Estimates</div><div class="value">${state.history.length}</div></div>
      <div class="card stat"><div class="label">Accepted</div><div class="value">${accepted.length}</div></div>
      <div class="card stat"><div class="label">Pending</div><div class="value">${pending.length}</div></div>
      <div class="card stat"><div class="label">Close Rate</div><div class="value">${closeRate.toFixed(0)}%</div></div>
    </div>
    <div class="grid4" style="margin-top:14px">
      <div class="card stat"><div class="label">Average Monthly Estimate</div><div class="value">${money(avgEstimate)}</div></div>
      <div class="card stat"><div class="label">Average Monthly Sold Value</div><div class="value">${money(avgSold)}</div></div>
      <div class="card stat"><div class="label">Monthly Revenue / Property</div><div class="value">${money(accepted.length ? acceptedRevenue/accepted.length : 0)}</div></div>
      <div class="card stat"><div class="label">Estimated Monthly Profit / Property</div><div class="value">${money(estimatedProfitPerProperty(state))}</div></div>
    </div>
    <div class="grid4" style="margin-top:14px">
      <div class="card stat"><div class="label">Turf Monthly Revenue</div><div class="value">${money(revByCat.turf)}</div></div>
      <div class="card stat"><div class="label">Ornamental Monthly Revenue</div><div class="value">${money(revByCat.ornamental)}</div></div>
      <div class="card stat"><div class="label">Palm Monthly Revenue</div><div class="value">${money(revByCat.palm)}</div></div>
      <div class="card stat"><div class="label">Specials Monthly Revenue</div><div class="value">${money(revByCat.specials)}</div></div>
    </div>
    <div class="grid4" style="margin-top:14px">
      <div class="card stat"><div class="label">Monthly Revenue Projection</div><div class="value">${money(acceptedRevenue)}</div></div>
      <div class="card stat"><div class="label">Annual Revenue Projection</div><div class="value">${money(acceptedRevenue * 12)}</div></div>
      <div class="card stat"><div class="label">Close Rate (Simple)</div><div class="value">${closeRate.toFixed(0)}%</div></div>
      <div class="card stat"><div class="label">Accepted + Manual Monthly Total</div><div class="value">${money(acceptedRevenue + manualRevenue)}</div></div>
    </div>
    <div class="grid2" style="margin-top:14px">
      <div class="card"><div class="kicker">Add Manual Sale</div>
        <label class="small" style="display:block;margin-bottom:4px">Customer / reference</label><input id="manualSaleName" placeholder="Customer or note">
        <label class="small" style="display:block;margin-top:10px;margin-bottom:4px">Category</label><select id="manualSaleCategory"><option value="turf">Turf</option><option value="ornamental">Ornamental</option><option value="palm">Palm</option><option value="specials">Specials</option></select>
        <label class="small" style="display:block;margin-top:10px;margin-bottom:4px">Value</label><input id="manualSaleValue" type="number" placeholder="0">
        <label class="small" style="display:block;margin-top:10px;margin-bottom:4px">Notes</label><textarea id="manualSaleNotes" placeholder="Optional notes"></textarea>
        <div class="btnrow" style="margin-top:12px"><button class="btn primary" id="addManualSale">Add Manual Sale</button></div>
      </div>
      <div class="card"><div class="kicker">Manual Sales</div>${(state.manualSales||[]).length?`<div class="scrollTable"><table class="table"><thead><tr><th>Saved</th><th>Name</th><th>Category</th><th>Value</th><th>Delete</th></tr></thead><tbody>${state.manualSales.map((r,i)=>`<tr><td>${new Date(r.savedAt).toLocaleDateString()}</td><td>${r.name||""}</td><td>${r.category||""}</td><td>${money(r.value||0)}</td><td><button class="btn" data-del-manual="${i}">Remove</button></td></tr>`).join("")}</tbody></table></div>`:`<div class="note">No manual sales yet.</div>`}</div>
    </div>`;
  } else if(state.view==="catalog"){
    const cat = state.vendorCatalog || emptyCatalog();
    const filteredCat = filteredVendorCatalog(cat, state.catalogSearch || '');
    const staging = state.importState?.stagingRows || [];
    html = `<div class="row space"><div><h2>Vendor Catalog</h2><div class="sub">Build 32 importer path split: CSV, pasted rows, manual entry, and PDF bid import now stage rows for review before they save into the live catalog.</div></div></div>
    <div class="grid3">
      <div class="card"><div class="kicker">Import Center</div>
        <label class="small" style="display:block;margin-bottom:4px">Default category for imported rows</label>
        <select id="catalogImportCategory"><option value="materials">Materials</option><option value="equipment">Equipment</option><option value="other">Other</option></select>
        <label class="small" style="display:block;margin-top:10px;margin-bottom:4px">Upload catalog file</label>
        <input id="catalogFile" type="file" accept=".csv,.tsv,.txt,.json,.pdf">
        <div class="small" style="margin-top:8px">CSV and JSON import directly into staging. PDF bids use a separate extractor path and never save raw text directly into the catalog.</div>
        <label class="small" style="display:block;margin-top:10px;margin-bottom:4px">Or paste rows</label>
        <textarea id="catalogPaste" placeholder="name,sku,price,notes,category&#10;LESCO 46-0-0,510971,34.52,50 lb bag,materials"></textarea>
        <div class="btnrow" style="margin-top:12px">
          <button class="btn primary" id="importCatalogFile">Stage File Import</button>
          <button class="btn" id="importCatalogPaste">Stage Pasted Rows</button>
        </div>
      </div>
      <div class="card"><div class="kicker">Add Single Catalog Item</div>
        <label class="small" style="display:block;margin-bottom:4px">Category</label>
        <select id="catalogCategory"><option value="materials">Materials</option><option value="equipment">Equipment</option><option value="other">Other</option></select>
        <label class="small" style="display:block;margin-top:10px;margin-bottom:4px">Item name</label>
        <input id="catalogName" placeholder="Item name">
        <input id="catalogNpk" placeholder="NPK ratio (example 12-0-0)">
        <label class="small" style="display:block;margin-top:10px;margin-bottom:4px">SKU / reference</label>
        <input id="catalogSku" placeholder="SKU or reference">
        <label class="small" style="display:block;margin-top:10px;margin-bottom:4px">Unit price</label>
        <input id="catalogPrice" type="number" placeholder="0">
        <label class="small" style="display:block;margin-top:10px;margin-bottom:4px">Notes</label>
        <textarea id="catalogNotes" placeholder="Bid sheet notes, pack size, vendor, etc."></textarea>
        <div class="btnrow" style="margin-top:12px"><button class="btn primary" id="addCatalogItem">Add Item</button></div>
      </div>
      <div class="card"><div class="kicker">Catalog Totals</div>
        <div class="rowline"><span class="label">Materials</span><span class="value">${cat.materials.length}</span></div>
        <div class="rowline"><span class="label">Equipment</span><span class="value">${cat.equipment.length}</span></div>
        <div class="rowline"><span class="label">Other</span><span class="value">${cat.other.length}</span></div>
        <div class="rowline"><span class="label">Staging Rows</span><span class="value">${staging.length}</span></div>
        <div class="small" style="margin-top:10px">Nothing is saved until you review and commit the staged rows.</div>
      </div>
    </div>
    ${staging.length ? `<div class="card" style="margin-top:14px"><div class="row space"><div><div class="kicker">Import Review</div><div class="small">Review parsed rows before saving into the live product library.</div></div><div class="btnrow"><button class="btn primary" id="commitCatalogStaging">Save Selected</button><button class="btn" id="clearCatalogStaging">Clear</button></div></div><div class="scrollTable" style="margin-top:12px"><table class="table"><thead><tr><th>Use</th><th>Name</th><th>NPK</th><th>SKU</th><th>Price</th><th>Category</th><th>Notes</th><th>Warnings</th></tr></thead><tbody>${staging.map((r,i)=>`<tr><td><input type="checkbox" data-stage-include="${i}" ${r.include!==false?'checked':''}></td><td>${productLabel(r)}</td><td>${r.npk||"—"}</td><td>${r.sku||""}</td><td>${money(r.price||0)}</td><td>${r.category||"materials"}</td><td>${r.notes||""}</td><td>${(r.warnings||[]).join('; ')}</td></tr>`).join("")}</tbody></table></div></div>` : ''}
    <div class="card" style="margin-top:14px"><div class="row space" style="gap:12px;flex-wrap:wrap"><div><div class="kicker">Catalog Search</div><div class="small" style="margin-top:6px">Filter materials, equipment, and other items by product, SKU, notes, or category.</div></div><div style="min-width:280px;flex:1;max-width:420px"><input id="catalogSearch" value="${escapeHtml(state.catalogSearch||'')}" placeholder="Search main material lists" autocomplete="off" autocapitalize="off" spellcheck="false"></div></div></div>
    <div class="grid3" style="margin-top:14px">
      <div class="card"><div class="kicker">Materials</div>${filteredCat.materials.length?`<div class="scrollTable"><table class="table" id="vendorCatalogMaterialsTable"><thead><tr><th>Name</th><th>NPK</th><th>SKU</th><th>Vendor Price</th><th>Manual Override</th><th>Using Now</th><th>Source</th><th>Reset</th><th>Notes</th><th>Delete</th></tr></thead><tbody>${filteredCat.materials.map((r)=>`<tr data-catalog-row="material" data-searchtext="${escapeHtml(((productLabel(r)||'')+' '+(r.npk||'')+' '+(r.sku||'')+' '+(r.notes||'')+' '+(catalogPriceSourceLabel(r)||'')).toLowerCase())}"><td>${productLabel(r)}</td><td>${r.npk||"—"}</td><td>${r.sku||""}</td><td>${money(r.vendor_price ?? r.price ?? 0)}</td><td><input type="number" step="0.01" value="${r.manual_price ?? ''}" data-cat-override-id="${r.id}" placeholder="Use vendor" style="width:110px"></td><td>${money(r.current_price ?? r.vendor_price ?? r.price ?? 0)}</td><td>${catalogPriceSourceLabel(r)}</td><td><button class="btn" data-cat-reset-id="${r.id}">Reset</button></td><td>${r.notes||""}</td><td><button class="btn" data-del-cat-id="${r.id}">Remove</button></td></tr>`).join("")}</tbody></table></div><div class="small" style="margin-top:8px">Vendor price stays visible. Enter a manual override only when your real working cost changes; leave blank to keep using vendor pricing.</div>`:`<div class="note">${cat.materials.length?'No matching material items.':'No material items yet.'}</div>`}</div>
      <div class="card"><div class="kicker">Equipment</div>${filteredCat.equipment.length?`<div class="scrollTable"><table class="table" id="vendorCatalogEquipmentTable"><thead><tr><th>Name</th><th>SKU</th><th>Vendor Price</th><th>Manual Override</th><th>Using Now</th><th>Source</th><th>Reset</th><th>Notes</th><th>Delete</th></tr></thead><tbody>${filteredCat.equipment.map((r)=>`<tr data-catalog-row="equipment" data-searchtext="${escapeHtml(((r.name||'')+' '+(r.sku||'')+' '+(r.notes||'')+' '+(catalogPriceSourceLabel(r)||'')).toLowerCase())}"><td>${r.name}</td><td>${r.sku||""}</td><td>${money(r.vendor_price ?? r.price ?? 0)}</td><td><input type="number" step="0.01" value="${r.manual_price ?? ''}" data-cat-override-id="${r.id}" placeholder="Use vendor" style="width:110px"></td><td>${money(r.current_price ?? r.vendor_price ?? r.price ?? 0)}</td><td>${catalogPriceSourceLabel(r)}</td><td><button class="btn" data-cat-reset-id="${r.id}">Reset</button></td><td>${r.notes||""}</td><td><button class="btn" data-del-cat-id="${r.id}">Remove</button></td></tr>`).join("")}</tbody></table></div>`:`<div class="note">${cat.equipment.length?'No matching equipment items.':'No equipment items yet.'}</div>`}</div>
      <div class="card"><div class="kicker">Other</div>${filteredCat.other.length?`<div class="scrollTable"><table class="table" id="vendorCatalogOtherTable"><thead><tr><th>Name</th><th>SKU</th><th>Vendor Price</th><th>Manual Override</th><th>Using Now</th><th>Source</th><th>Reset</th><th>Notes</th><th>Delete</th></tr></thead><tbody>${filteredCat.other.map((r)=>`<tr data-catalog-row="other" data-searchtext="${escapeHtml(((r.name||'')+' '+(r.sku||'')+' '+(r.notes||'')+' '+(catalogPriceSourceLabel(r)||'')).toLowerCase())}"><td>${r.name}</td><td>${r.sku||""}</td><td>${money(r.vendor_price ?? r.price ?? 0)}</td><td><input type="number" step="0.01" value="${r.manual_price ?? ''}" data-cat-override-id="${r.id}" placeholder="Use vendor" style="width:110px"></td><td>${money(r.current_price ?? r.vendor_price ?? r.price ?? 0)}</td><td>${catalogPriceSourceLabel(r)}</td><td><button class="btn" data-cat-reset-id="${r.id}">Reset</button></td><td>${r.notes||""}</td><td><button class="btn" data-del-cat-id="${r.id}">Remove</button></td></tr>`).join("")}</tbody></table></div>`:`<div class="note">${cat.other.length?'No matching other items.':'No uncategorized items yet.'}</div>`}</div>
    </div>`;

  } else if(state.view==="orders"){
    const summary = orderSheetSummary(state);
    const draft = summary.draft;
    const catalogRows = orderSheetVisibleCatalogRows(state);
    html = `<div class="row space"><div><h2>Order Sheet</h2><div class="sub">Build a vendor order from your main catalog, factor in what you already have on hand, then generate a clean vendor-ready PDF or email.</div></div></div>
    <div class="btnrow" style="margin-bottom:14px">
      <button class="btn primary" id="orderSheetPdf">Generate Order Sheet PDF</button>
      <button class="btn" id="orderSheetEmail">Email Order Sheet</button>
      <button class="btn" id="copyOrderSheetText">Copy Order Sheet Text</button>
      <button class="btn" id="downloadOrderSheetText">Download TXT</button>
      <button class="btn" id="downloadOrderSheetCsv">Download CSV</button>
      <button class="btn" id="clearOrderDraft" ${draft.length?'':'disabled'}>Clear Current Order</button>
    </div>
    <div class="grid5" style="margin-bottom:14px">
      <div class="card stat"><div class="label">Catalog Line Count</div><div class="value">${summary.lineCount}</div></div>
      <div class="card stat"><div class="label">Order Lines</div><div class="value">${draft.length}</div></div>
      <div class="card stat"><div class="label">Desired Qty</div><div class="value">${summary.draftQty.toFixed(2)}</div></div>
      <div class="card stat"><div class="label">Recommended Buy Qty</div><div class="value">${summary.orderNowQty.toFixed(2)}</div></div>
      <div class="card stat"><div class="label">Recommended Buy Total</div><div class="value">${money(summary.orderNowCost)}</div></div>
    </div>
    <div class="card" style="margin-bottom:14px">
      <div class="row space" style="gap:12px;flex-wrap:wrap"><div><div class="kicker">Build Order From Main List</div><div class="small" style="margin-top:6px">Search the main materials/equipment list, then add only what you want into the current vendor order.</div></div><div style="min-width:280px;flex:1;max-width:420px"><input id="orderSheetSearch" value="${escapeHtml(state.orderSheetSearch||'')}" placeholder="Search catalog by product, SKU, notes, or category" autocomplete="off" autocapitalize="off" spellcheck="false"></div></div>
      <div class="grid4" style="align-items:end">
        <div style="grid-column:span 2"><label class="small" style="display:block;margin-bottom:4px">Choose product</label><select id="orderCatalogSelect"><option value="">Select product</option>${catalogRows.map(p=>`<option value="${catalogProductIdentifier(p)}" data-searchtext="${escapeHtml(((productLabel(p)||'')+' '+(p.sku||'')+' '+(p.notes||'')+' '+(purchaseCategoryLabel(p)||'')+' '+(p.unit||p.pack_size||'')).toLowerCase())}">${productLabel(p)}${p.sku?` · ${p.sku}`:''}</option>`).join('')}</select></div>
        <div><label class="small" style="display:block;margin-bottom:4px">Desired qty</label><input id="orderCatalogQty" type="number" step="0.01" min="0" value="1"></div>
        <div class="btnrow"><button class="btn primary" id="addCatalogItemToOrder">Add To Current Order</button></div>
      </div>
      <div class="small" style="margin-top:8px">Use the catalog below to track on-hand stock, minimums, and target levels, then build the order you want to send to the vendor.</div>
    </div>
    ${draft.length?`<div class="card" style="margin-bottom:14px"><div class="row space"><div><div class="kicker">Current Order Build</div><div class="small">Forecast-pushed items and manual picks both land here. Buy Now accounts for on-hand stock and target levels.</div></div><div class="small">${draft.length} lines · desired ${summary.draftQty.toFixed(2)} · recommended buy ${summary.orderNowQty.toFixed(2)} · ${money(summary.orderNowCost)}</div></div><div class="scrollTable"><table class="table"><thead><tr><th>SKU</th><th>Product</th><th>Need for Program</th><th>On Hand</th><th>Min</th><th>Target</th><th>Buy Now</th><th>Unit</th><th>Unit Price</th><th>Line Total</th><th>Flags</th><th>Vendor</th><th>Link</th><th>Delete</th></tr></thead><tbody>${draft.map((r,idx)=>`<tr><td>${r.sku||''}</td><td>${r.name}<div class="small">${r.price_source || catalogPriceSourceLabel(findCatalogProductForRow(state, r)||r)}${r.manual_override?' · Manual override':''}</div></td><td><input type="number" step="0.01" min="0" value="${Number(r.qty||0)}" data-draft-qty="${idx}" style="width:90px"></td><td>${isStockedItem(findCatalogProductForRow(state, r)||r) ? orderRowOnHand(state,r).toFixed(2) : '—'}</td><td>${isStockedItem(findCatalogProductForRow(state, r)||r) ? reorderMinimum(findCatalogProductForRow(state, r)||r).toFixed(2) : '—'}</td><td>${isStockedItem(findCatalogProductForRow(state, r)||r) ? targetStock(findCatalogProductForRow(state, r)||r).toFixed(2) : '—'}</td><td>${orderRowOrderNow(state,r).toFixed(2)}</td><td>${r.unit||""}</td><td><input type="number" step="0.01" min="0" value="${Number(orderRowUnitPrice(state,r)||0)}" data-draft-price="${idx}" style="width:96px"><div class="small">${r.manual_override?'Manual override':'Auto price'}</div></td><td>${money(orderRowLineTotal(state,r))}</td><td><span class="small">${inventoryFlags(findCatalogProductForRow(state, r)||r, Number(r.qty||0)).join(" · ") || "—"}</span></td><td>${r.vendor||orderVendorLabel(findCatalogProductForRow(state,r)||{})}</td><td>${orderDraftLinkForRow(state, r)?`<a href="${orderDraftLinkForRow(state, r)}" target="_blank" rel="noopener noreferrer">Open</a>`:'<span class="small">No link</span>'}</td><td><div class="btnrow"><button class="btn" data-reset-draft-price="${idx}">Auto</button><button class="btn" data-delete-draft="${idx}">Remove</button></div></td></tr>`).join("")}</tbody></table></div></div>`:""}
    <div class="grid3" style="margin-bottom:14px">
      <div class="card"><div class="kicker">Order By Type</div><div class="scrollTable" style="margin-top:10px"><table class="table"><thead><tr><th>Type</th><th>Lines</th><th>Order Qty</th><th>Order Total</th></tr></thead><tbody>${summary.orderTypeGroups.map(group=>`<tr><td>${group.label}</td><td>${group.lines}</td><td>${group.orderQty.toFixed(2)}</td><td>${money(group.orderCost)}</td></tr>`).join("")}</tbody></table></div></div>
      <div class="card"><div class="kicker">Order By Vendor</div><div class="scrollTable" style="margin-top:10px"><table class="table"><thead><tr><th>Vendor</th><th>Lines</th><th>Order Qty</th><th>Order Total</th></tr></thead><tbody>${summary.orderVendorGroups.map(group=>`<tr><td>${group.label}</td><td>${group.lines}</td><td>${group.orderQty.toFixed(2)}</td><td>${money(group.orderCost)}</td></tr>`).join("")}</tbody></table></div></div>
      <div class="card"><div class="kicker">Vendor Export</div><div class="small" style="margin-top:8px">Generate a printable PDF or email with the current selected order items. Stocked reorder lines stay optional and only appear when you intentionally include them.</div><div class="rowline" style="margin-top:12px"><span class="label">Catalog items</span><span class="value">${summary.materials.length} / ${summary.equipment.length} / ${summary.other.length}</span></div><div class="rowline"><span class="label">Tracked stocked items</span><span class="value">${summary.stockedRows.length}</span></div><div class="rowline"><span class="label">Current order lines</span><span class="value">${summary.draft.length}</span></div><div class="rowline"><span class="label">Recommended buy total</span><span class="value">${money(summary.orderNowCost)}</span></div><div class="rowline"><span class="label">Below minimum / out of stock</span><span class="value">${summary.belowMinimum.length} / ${summary.outOfStock.length}</span></div></div>
    </div>
    <div class="card" style="margin-bottom:14px"><div class="row space"><div><div class="kicker">Reorder Worksheet</div><div class="small" style="margin:8px 0 0 0">Suggested reorder now applies only to items marked Stock this item / Track in inventory. Whole-pack items round up automatically.</div></div><div class="row" style="gap:12px;align-items:center;flex-wrap:wrap"><div class="row" style="gap:8px;align-items:center"><span class="small">Buying mode</span><select id="orderPurchaseMode" style="width:220px"><option value="target" ${state.orderPurchaseMode!=='program'?'selected':''}>Buy to target stock</option><option value="program" ${state.orderPurchaseMode==='program'?'selected':''}>Buy for current program only</option></select></div><label class="toggle small" style="gap:6px"><input type="checkbox" id="includeStockedReorderInOrderSheet" ${state.includeStockedReorderInOrderSheet?'checked':''}> Include stocked reorder lines in PDF/email</label></div></div><div class="scrollTable"><table class="table"><thead><tr><th>SKU</th><th>Product</th><th>Category</th><th>On Hand</th><th>Min</th><th>Target</th><th>Suggested Reorder</th><th>Status</th><th>Unit</th></tr></thead><tbody>${summary.restockRows.map(r=>`<tr><td>${r.sku||""}</td><td>${r.name}</td><td>${purchaseCategoryLabel(r)}</td><td>${Number(r.onHand||0).toFixed(2)}</td><td>${Number(r.minStock||0).toFixed(2)}</td><td>${Number(r.targetStock||0).toFixed(2)}</td><td>${Number(r.suggestedReorder||0).toFixed(2)}</td><td><span class="small">${(r.flags||[]).join(" · ") || "—"}</span></td><td>${r.unit||r.pack_size||""}</td></tr>`).join("") || '<tr><td colspan="9">No stocked reorder alerts yet.</td></tr>'}</tbody></table></div></div><div class="card" style="margin-bottom:14px"><div class="row space"><div><div class="kicker">Main Catalog + Inventory</div><div class="small" style="margin:8px 0 0 0">Items stay available for one-off ordering even when not stocked. Turn on inventory tracking only for the items you intentionally keep in stock.</div></div><div class="row" style="gap:8px;flex-wrap:wrap"><select id="orderCatalogFilter" style="width:170px"><option value="all" ${state.orderCatalogFilter!=='stocked' && state.orderCatalogFilter!=='catalog' ? 'selected' : ''}>All items</option><option value="stocked" ${state.orderCatalogFilter==='stocked' ? 'selected' : ''}>Stocked only</option><option value="catalog" ${state.orderCatalogFilter==='catalog' ? 'selected' : ''}>Catalog only</option></select><button class="btn" id="resetInventoryOnHand">Clear On Hand</button><button class="btn" id="resetInventoryMin">Clear Minimums</button><button class="btn" id="resetInventoryTarget">Clear Targets</button><button class="btn" id="clearManualOverrides">Use Vendor Prices</button></div></div><div class="scrollTable"><table class="table"><thead><tr><th>SKU</th><th>Product</th><th>Category</th><th>Unit</th><th>Track</th><th>Source</th><th>Vendor Price</th><th>Using Now</th><th>On Hand</th><th>Min</th><th>Target</th><th>Suggested Reorder</th><th>Status</th><th>Qty To Add</th><th>Add</th><th>Open</th></tr></thead><tbody>
    ${catalogRows.map((p,idx)=>`<tr data-order-catalog-row="${idx}" data-searchtext="${escapeHtml(((productLabel(p)||'')+' '+(p.sku||'')+' '+(p.notes||'')+' '+(purchaseCategoryLabel(p)||'')+' '+(p.unit||p.pack_size||'')).toLowerCase())}"><td>${p.sku||''}</td><td><strong>${p.name}</strong></td><td>${purchaseCategoryLabel(p)}</td><td>${p.unit||p.pack_size||""}</td><td><label class="toggle small" style="gap:6px"><input type="checkbox" data-cat-stocked="${idx}" ${isStockedItem(p)?'checked':''}> ${isStockedItem(p)?'Stocked':'Catalog only'}</label></td><td>${catalogPriceSourceLabel(p)}</td><td>${money(vendorPriceValue(p))}</td><td>${money(effectiveCatalogPrice(p))}</td><td><input type="number" step="0.01" min="0" value="${inventoryOnHand(p)}" data-cat-inventory="${idx}" style="width:80px" ${isStockedItem(p)?'':'disabled'}></td><td><input type="number" step="0.01" min="0" value="${reorderMinimum(p)}" data-cat-min="${idx}" style="width:70px" ${isStockedItem(p)?'':'disabled'}></td><td><input type="number" step="0.01" min="0" value="${targetStock(p)}" data-cat-target="${idx}" style="width:70px" ${isStockedItem(p)?'':'disabled'}></td><td>${isStockedItem(p)?reorderNeed(p,0,state.orderPurchaseMode || 'target').toFixed(2):'—'}</td><td><span class="small">${inventoryFlags(p,0).join(" · ") || "—"}</span></td><td><input type="number" step="0.01" min="0" value="1" data-order-qty-row="${idx}" style="width:80px"></td><td><button class="btn" data-add-order-row="${idx}">Add</button></td><td>${productOpenUrl(p)?`<a href="${productOpenUrl(p)}" target="_blank" rel="noopener noreferrer">Open</a>`:'<span class="small">No link</span>'}</td></tr>`).join("")}
    </tbody></table></div></div>`;

} else if(state.view==="labels"){
  const stats = labelCenterStats(state);
  const prefs = {...defaultState.labelCenter, ...(state.labelCenter||{})};
  const products = stats.visible;
  html = `<div class="row space"><div><h2>Label Center</h2><div class="sub">Direct label reading, filtering, and SDS binder printing for materials used in programs.</div></div></div>
  <div class="card" style="margin-bottom:14px">
    <div class="grid4">
      <div><label class="small" style="display:block;margin-bottom:6px">Search labels</label><input id="labelSearch" value="${escapeHtml(prefs.query)}" placeholder="Filter by product, SKU, or file"></div>
      <div><label class="small" style="display:block;margin-bottom:6px">Sort</label><select id="labelSort"><option value="name" ${prefs.sort==='name'?'selected':''}>Product name</option><option value="sku" ${prefs.sort==='sku'?'selected':''}>SKU</option><option value="hasLabel" ${prefs.sort==='hasLabel'?'selected':''}>Uploaded labels first</option><option value="recentLabel" ${prefs.sort==='recentLabel'?'selected':''}>Label filename</option></select></div>
      <div style="display:flex;align-items:flex-end"><div class="toggle"><input type="checkbox" id="labelOnlyUploaded" ${prefs.onlyWithLabels?'checked':''}><label>Show only uploaded labels</label></div></div>
      <div style="display:flex;align-items:flex-end;justify-content:flex-end"><button type="button" class="btn" id="labelResetFilters">Reset Filters</button></div>
    </div>
    <div class="btnrow" style="margin-top:12px;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
      <div class="btnrow" style="gap:10px;flex-wrap:wrap">
        <button type="button" class="btn primary" id="printVisibleLabels" ${stats.visibleUploaded ? '' : 'disabled'}>Print Visible Labels / SDS</button>
      </div>
      <div class="small">Showing ${products.length} of ${stats.all.length} products · ${stats.visibleUploaded} visible with uploaded labels · ${stats.uploaded} total uploaded labels</div>
    </div>
  </div>
  <div class="grid3">
    ${products.map(p=>`<div class="card labelCard">
      <div class="kicker">${p.sku}</div>
      <h3 style="margin:0 0 8px 0;font-size:18px">${p.name}</h3>
      ${isPdfDataUrl(p.labelImage||"") ? labelPreviewHtml(p) : `<div class="labelImageWrap">${labelPreviewHtml(p)}</div>`}
      <div class="btnrow" style="margin-top:10px;align-items:center;flex-wrap:wrap">
        <label class="btn" style="display:inline-block">
          Upload label PDF or image
          <input type="file" accept="image/*,.pdf,application/pdf" data-label-file="${p.sku}" style="display:none">
        </label>
        ${p.labelImage?`<button type="button" class="btn" data-read-label="${p.sku}">Read Label</button><button type="button" class="btn" data-print-label="${p.sku}">Print Label</button><button type="button" class="btn" data-clear-label-image="${p.sku}">${isPdfDataUrl(p.labelImage)?"Remove label PDF":"Remove label image"}</button>`:`<span class="small">Upload a label, then use Read Label or Print Label.</span>`}
      </div>
    </div>`).join("") || '<div class="card"><div class="note">No labels match the current filter.</div></div>'}
  </div>`;
  } else if(state.view==="history"){
    html = `<h2>Estimate History</h2><div class="sub">Saved estimates can be revised, resent, accepted, overridden, or deleted.</div><div class="card">
    ${state.history.length?`<div class="scrollTable"><table class="table"><thead><tr><th>Saved</th><th>Customer</th><th>Phone</th><th>Email</th><th>Status</th><th>Final Sold</th><th>Actions</th></tr></thead><tbody>${state.history.map((r,idx)=>`<tr><td>${new Date(r.savedAt).toLocaleString()}</td><td>${r.customer||""}</td><td>${r.phone||""}</td><td>${r.email||""}</td><td><div class="toggle"><input type="checkbox" data-accept-est="${idx}" ${r.accepted?"checked":""}><label>${r.accepted?"Accepted":"Pending"}</label></div></td><td><input type="number" data-final-sold="${idx}" value="${Number(r.finalSoldValue || r.total || 0)}" style="max-width:120px"></td><td><div class="btnrow"><button class="btn" data-revise="${idx}">Revise</button><button class="btn" data-resend="${idx}">Resend</button><button class="btn" data-delete-est="${idx}">Delete</button></div></td></tr>`).join("")}</tbody></table></div>`:`<div class="note">No saved estimates yet.</div>`}
    </div>`;
  }
  document.getElementById("view").innerHTML = html;
  restoreBuilderSearchFocus();
  restoreBuilderLineFocus();
  const bind=(id,cb)=>{ const el=document.getElementById(id); if(el) el.onchange=cb; };
  const bindInput=(id,cb)=>{ const el=document.getElementById(id); if(el){ el.oninput=cb; el.onchange=cb; } };
  bind("programSelect",e=>{ flushProgramLineEditors(state, state.builderMode); window.__paLineDrafts = window.__paLineDrafts || {turf:{}, ornamental:{}, special:{}}; window.__paLineDrafts[state.builderMode === 'ornamental' ? 'ornamental' : state.builderMode === 'special' ? 'special' : 'turf'] = {}; setActiveProgramKey(state, e.target.value, state.builderMode); saveState(state); render(); });
  bind("turfSelect",e=>{ state.turf=e.target.value; saveState(state); render(); });
  bind("soilInput",e=>{ state.soilTemp=e.target.value; saveState(state); render(); });
  bind("marginTurf",e=>{ state.margins.turf=Number(e.target.value||0); saveState(state); render(); });
  bind("marginOrn",e=>{ state.margins.ornamental=Number(e.target.value||0); saveState(state); render(); });
  bind("marginPalm",e=>{ state.margins.palm=Number(e.target.value||0); saveState(state); render(); });
  bind("marginSpecials",e=>{ state.margins.specials=Number(e.target.value||0); saveState(state); render(); });
  bind("actualSellTurf",e=>{ state.actualSell.turfPer1000=e.target.value; saveState(state); render(); });
  bind("actualSellOrn",e=>{ state.actualSell.ornamentalPer1000=e.target.value; saveState(state); render(); });
  bind("actualSellSpecial",e=>{ state.actualSell.specialsPer1000=e.target.value; saveState(state); render(); });
  bind("forecastProperties",e=>{ state.forecasts.properties=Number(e.target.value||0); saveState(state); render(); });
  bind("forecastAvgTurf",e=>{ state.forecasts.avgTurfSqft=Number(e.target.value||0); saveState(state); render(); });
  bind("forecastAvgOrn",e=>{ state.forecasts.avgOrnSqft=Number(e.target.value||0); saveState(state); render(); });
  bind("forecastAvgSpecial",e=>{ state.forecasts.avgSpecialSqft=Number(e.target.value||0); saveState(state); render(); });
  bind("forecastAvgPalm",e=>{ state.forecasts.avgPalmCount=Number(e.target.value||0); saveState(state); render(); });
  ["qCustomer","qAddress","qPhone","qEmail","qNotes","qCustomNotes"].forEach((id,i)=>bind(id,e=>{ const keys=["customer","address","phone","email","notes","customNotes"]; state.currentQuote[keys[i]]=e.target.value; saveState(state); }));
  ["qTurfSqft","qOrnSqft","qPalmCount"].forEach((id,i)=>bind(id,e=>{ const keys=["turfSqft","ornamentalSqft","palmCount"]; state.currentQuote[keys[i]]=Number(e.target.value||0); saveState(state); render(); }));
  bind("qOrnDensity",e=>{ state.currentQuote.ornamentalDensity = ornamentalDensityTier(e.target.value); saveState(state); render(); });
  bind("qIncludeBlurb",e=>{ state.currentQuote.includeBlurb=e.target.checked; saveState(state); render(); });
  bind("qManualDiscount",e=>{ state.currentQuote.manualDiscountPct=Number(e.target.value||0); saveState(state); render(); });
  document.querySelectorAll("[data-service-check]").forEach(el=>el.onchange=()=>{ state.currentQuote.services[el.dataset.serviceCheck].selected=el.checked; saveState(state); render(); });
  document.querySelectorAll("[data-service-notes]").forEach(el=>el.onchange=()=>{ state.currentQuote.services[el.dataset.serviceNotes].notes=el.value; saveState(state); });
  document.querySelectorAll("[data-special-check]").forEach(el=>el.onchange=()=>{ state.currentQuote.specials[el.dataset.specialCheck].selected=el.checked; saveState(state); render(); });
  document.querySelectorAll("[data-special-price]").forEach(el=>el.onchange=()=>{ state.currentQuote.specials[el.dataset.specialPrice].price=Number(el.value||0); saveState(state); render(); });
  document.querySelectorAll("[data-special-notes]").forEach(el=>el.onchange=()=>{ state.currentQuote.specials[el.dataset.specialNotes].notes=el.value; saveState(state); });
  document.querySelectorAll("[data-special-dbh]").forEach(el=>el.onchange=()=>{ state.currentQuote.specials[el.dataset.specialDbh].dbh=el.value; saveState(state); render(); });
  document.querySelectorAll("[data-palm-h]").forEach(el=>el.onchange=()=>{ const [k,h]=el.dataset.palmH.split("|"); state.currentQuote.specials[k].palmHeights[h]=Number(el.value||0); saveState(state); render(); });
  document.querySelectorAll("[data-line-edit-toggle]").forEach(el=>el.onclick=()=>{ const idx = Number(el.dataset.lineEditToggle); const next = !isProgramLineExpanded(state, idx, state.builderMode); setProgramLineExpanded(state, idx, next, state.builderMode); if(next) window.__paLineFocus = {kind:'rate', idx}; saveState(state); render(); });
  document.querySelectorAll("[data-line-rate]").forEach(el=>{
    const idx = Number(el.dataset.lineRate);
    const commit = (shouldRender=false)=>{
      const raw = String(builderLineDraftValue(state.builderMode, idx, 'rate', el.value)).trim();
      const parsed = raw === '' ? 0 : Number(raw);
      if(Number.isNaN(parsed)) return;
      if(!commitProgramLineField(state, idx, line=>{ line.rate = parsed; }, state.builderMode)) return;
      clearBuilderLineDraft(state.builderMode, idx);
      if(shouldRender){ window.__paLineFocus = {kind:'rate', idx}; render(); }
      else saveState(state);
    };
    el.onfocus=()=>{ if(typeof el.select === 'function') el.select(); };
    el.oninput=()=>{
      setBuilderLineDraftValue(state.builderMode, idx, 'rate', el.value);
    };
    el.onchange=()=>commit(false);
    el.onblur=()=>commit(true);
    el.onkeydown=e=>{ if(e.key === 'Enter'){ e.preventDefault(); commit(true); } };
  });
  document.querySelectorAll("[data-line-uom]").forEach(el=>{
    const commit = (shouldRender=true)=>{
      const idx = Number(el.dataset.lineUom);
      if(!commitProgramLineField(state, idx, line=>{ line.unit = composeLineUnit(el.value, lineCarrier(line)); }, state.builderMode)) return;
      if(shouldRender){ window.__paLineFocus = {kind:'uom', idx}; render(); }
    };
    el.onchange=()=>commit(true);
    el.onblur=()=>commit(true);
  });
  document.querySelectorAll("[data-line-carrier]").forEach(el=>{
    const commit = (shouldRender=true)=>{
      const idx = Number(el.dataset.lineCarrier);
      if(!commitProgramLineField(state, idx, line=>{ line.unit = composeLineUnit(lineUnitOnly(line), el.value); }, state.builderMode)) return;
      if(shouldRender){ window.__paLineFocus = {kind:'carrier', idx}; render(); }
    };
    el.onchange=()=>commit(true);
    el.onblur=()=>commit(true);
  });
  document.querySelectorAll("[data-delete-line]").forEach(el=>el.onclick=()=>{ const active = activeProgramRecord(state); if(!active) return; const idx = Number(el.dataset.deleteLine); active.lines.splice(idx,1); const bucket = lineEditorBucket(state, state.builderMode); const remapped = {}; Object.keys(bucket||{}).forEach(key=>{ const n = Number(key); if(n < idx) remapped[String(n)] = true; else if(n > idx) remapped[String(n-1)] = true; }); if(state.builderMode === "ornamental") state.programLineEditors.ornamental = remapped; else if(state.builderMode === "special"){ const treatmentKey = state.selectedSpecialTreatment || specialsCatalog[0]?.key || 'newSod'; state.programLineEditors.specials = state.programLineEditors.specials || {}; state.programLineEditors.specials[treatmentKey] = remapped; } else state.programLineEditors.turf = remapped; remapBuilderLineDrafts(state.builderMode, idx); saveState(state); render(); });
  const newLineProductSearch=document.getElementById("newLineProductSearch");
  if(newLineProductSearch){
    newLineProductSearch.onfocus=()=>rememberInputFocus(newLineProductSearch);
    newLineProductSearch.oninput=()=>{
      const key = builderSearchKey(state.builderMode);
      rememberInputFocus(newLineProductSearch);
      state.programProductSearch = {...(state.programProductSearch||{}), [key]: newLineProductSearch.value};
      state.orderBuilder = {...(state.orderBuilder||{}), sku:""};
      saveState(state);
      refreshBuilderProductSelect(state, state.builderMode);
      restoreBuilderSearchFocus();
    };
    newLineProductSearch.onkeydown=(evt)=>{
      if(evt.key === 'Enter'){
        evt.preventDefault();
        const select = document.getElementById('newLineProduct');
        if(select && select.options.length > 1){
          select.selectedIndex = 1;
          state.orderBuilder = {...(state.orderBuilder||{}), sku:select.value};
          saveState(state);
        }
      }
    };
  }
  const newLineProduct=document.getElementById("newLineProduct");
  if(newLineProduct) newLineProduct.onchange=()=>{ state.orderBuilder = {...(state.orderBuilder||{}), sku:newLineProduct.value}; saveState(state); };
  const addLine=document.getElementById("addLine");
  if(addLine) addLine.onclick=()=>{
    flushProgramLineEditors(state, state.builderMode);
    const active = activeProgramRecord(state);
    if(!active) return;
    const sku=(document.getElementById("newLineProduct")?.value || state.orderBuilder?.sku || "").trim();
    if(!sku) return;
    const label = state.labels[sku];
    if(!label) return;
    const defaultUnit = String(label.unit||'').toLowerCase();
    const unitOnly = defaultUnit.includes('lb') ? 'lb' : defaultUnit.includes('gal') ? 'gal' : defaultUnit.includes('ml') ? 'mL' : 'oz';
    const carrier = state.builderMode === 'ornamental' ? '50-gal shrub tank' : '150-gal tank';
    const defaultRate = Number(label.default_rate||label.recommended_rate||0);
    active.lines.push({sku, rate:defaultRate, unit:composeLineUnit(unitOnly, carrier)});
    const newIdx = active.lines.length - 1;
    setProgramLineExpanded(state, newIdx, true, state.builderMode);
    window.__paLineFocus = {kind:'rate', idx:newIdx};
    const key = state.builderMode === 'ornamental' ? 'ornamental' : state.builderMode === 'special' ? 'special' : 'turf';
    state.orderBuilder = {...(state.orderBuilder||{}), sku:""};
    state.programProductSearch = {...(state.programProductSearch||{}), [key]:""};
    saveState(state);
    render();
  };
  const saveAsNewProgram=document.getElementById("saveAsNewProgram");
  if(saveAsNewProgram) saveAsNewProgram.onclick=()=>{ flushProgramLineEditors(state, state.builderMode); const modeLabel = state.builderMode === 'ornamental' ? 'ornamental' : state.builderMode === 'special' ? 'special treatment' : 'turf'; const name=prompt(`Name the new ${modeLabel} program:`); if(!name) return; const treatmentKey = state.selectedSpecialTreatment || 'newSod'; const key=(state.builderMode==="ornamental"?"orn_custom_":state.builderMode==="special"?`special_${treatmentKey}_custom_`:"custom_")+Date.now(); const collection = activeProgramCollection(state); collection[key]=JSON.parse(JSON.stringify(activeProgramRecord(state))); collection[key].name=name; collection[key].savedManually=true; collection[key].templateNote=state.builderMode==="ornamental"?"Previously built ornamental program":state.builderMode==="special"?"Previously built special treatment program":"Previously built manual program"; collection[key].treatmentKey = state.builderMode === 'special' ? treatmentKey : collection[key].treatmentKey; setActiveProgramKey(state, key, state.builderMode); saveState(state); render(); };
  const applyTemplate=document.getElementById("applyTemplate");
  if(applyTemplate) applyTemplate.onclick=()=>{ flushProgramLineEditors(state, state.builderMode); const select=document.getElementById("templateSelect"); if(!select || !select.value) return; applyTemplateToProgram(state, select.value, state.builderMode); saveState(state); render(); };
  const deleteCurrentProgram=document.getElementById("deleteCurrentProgram");
  if(deleteCurrentProgram) deleteCurrentProgram.onclick=()=>{ flushProgramLineEditors(state, state.builderMode); const key = activeProgramKey(state, state.builderMode); const record = activeProgramRecord(state, state.builderMode); if(!record) return; if(!confirm(`Delete ${state.builderMode} program "${record.name || key}"?`)) return; if(removeSavedProgram(state, key, state.builderMode)){ saveState(state); render(); } };
  const deleteSelectedTemplate=document.getElementById("deleteSelectedTemplate");
  if(deleteSelectedTemplate) deleteSelectedTemplate.onclick=()=>{ flushProgramLineEditors(state, state.builderMode); const select=document.getElementById("templateSelect"); if(!select || !select.value) return; const collection = activeProgramCollection(state, state.builderMode); const record = collection?.[select.value]; if(!record) return; if(!confirm(`Delete saved template "${record.name || select.value}"?`)) return; if(removeSavedProgram(state, select.value, state.builderMode)){ saveState(state); render(); } };
  const builderModeTurf=document.getElementById("builderModeTurf");
  if(builderModeTurf) builderModeTurf.onclick=()=>{ flushProgramLineEditors(state, state.builderMode); state.builderMode="turf"; saveState(state); render(); };
  const builderModeOrnamental=document.getElementById("builderModeOrnamental");
  if(builderModeOrnamental) builderModeOrnamental.onclick=()=>{ flushProgramLineEditors(state, state.builderMode); state.builderMode="ornamental"; saveState(state); render(); };
  const builderModeSpecial=document.getElementById("builderModeSpecial");
  if(builderModeSpecial) builderModeSpecial.onclick=()=>{ flushProgramLineEditors(state, state.builderMode); state.builderMode="special"; saveState(state); render(); };
  bind("specialTreatmentSelect",e=>{
    const nextTreatment = e.target.value;
    flushProgramLineEditors(state, state.builderMode);
    state.selectedSpecialTreatment = nextTreatment;
    state.selectedSpecialPrograms = state.selectedSpecialPrograms || structuredClone(defaultSelectedSpecialPrograms);
    const collection = activeProgramCollection(state, 'special');
    const currentKey = state.selectedSpecialPrograms[nextTreatment] || defaultSelectedSpecialPrograms[nextTreatment];
    const nextKey = collection[currentKey] ? currentKey : (Object.keys(collection)[0] || defaultSelectedSpecialPrograms[nextTreatment]);
    setActiveProgramKey(state, nextKey, 'special');
    saveState(state);
    render();
  });
  document.querySelectorAll('[data-open-special-builder]').forEach(el=>el.onclick=()=>{ state.view='builder'; state.builderMode='special'; state.selectedSpecialTreatment=el.dataset.openSpecialBuilder; saveState(state); render(); });
  bind("builderCoverageSqft",e=>{ const active = activeProgramRecord(state); if(!active) return; active.tankCoverageSqft = Number(e.target.value||0); saveState(state); render(); });

  document.querySelectorAll("[data-label-unit]").forEach(el=>el.onchange=()=>{ state.labels[el.dataset.labelUnit].unit=el.value; saveState(state); });
  document.querySelectorAll("[data-label-active]").forEach(el=>el.onchange=()=>{ state.labels[el.dataset.labelActive].active=el.value; saveState(state); });

bind("labelSearch",e=>{ state.labelCenter.query = e.target.value; saveState(state); render(); });
bind("labelSort",e=>{ state.labelCenter.sort = e.target.value; saveState(state); render(); });
bind("labelOnlyUploaded",e=>{ state.labelCenter.onlyWithLabels = e.target.checked; saveState(state); render(); });
const labelResetFilters=document.getElementById("labelResetFilters");
if(labelResetFilters) labelResetFilters.onclick=()=>{ state.labelCenter = structuredClone(defaultState.labelCenter); saveState(state); render(); };
const printVisibleLabels=document.getElementById("printVisibleLabels");
if(printVisibleLabels) printVisibleLabels.onclick=()=>printVisibleLabelsBinder(state);
  document.querySelectorAll("[data-label-file]").forEach(el=>el.onchange=(ev)=>{ const file = ev.target.files && ev.target.files[0]; if(!file) return; const lower = String(file.name||"").toLowerCase(); const isPdf = file.type === "application/pdf" || lower.endsWith(".pdf"); const isImage = !!file.type && file.type.startsWith("image/"); if(!isPdf && !isImage){ alert("Please choose an image or PDF label file."); ev.target.value=""; return; } const reader = new FileReader(); reader.onload = ()=>{ const product = state.labels[el.dataset.labelFile]; if(!product) return; product.labelImage = String(reader.result||""); product.labelFileName = file.name || ""; saveState(state); render(); }; reader.onerror = ()=> alert(isPdf ? "Could not read PDF file." : "Could not read image file."); reader.readAsDataURL(file); });
  document.querySelectorAll("[data-read-label]").forEach(el=>el.onclick=(ev)=>{ ev.preventDefault(); ev.stopPropagation(); const product = state.labels[el.dataset.readLabel]; if(!product || !product.labelImage) return; readLabelAsset(product); return false; });
  document.querySelectorAll("[data-print-label]").forEach(el=>el.onclick=(ev)=>{ ev.preventDefault(); ev.stopPropagation(); const product = state.labels[el.dataset.printLabel]; if(!product || !product.labelImage) return; printLabelAsset(product); return false; });
  document.querySelectorAll("[data-clear-label-image]").forEach(el=>el.onclick=(ev)=>{ ev.preventDefault(); ev.stopPropagation(); if(!state.labels[el.dataset.clearLabelImage]) return false; state.labels[el.dataset.clearLabelImage].labelImage = ""; state.labels[el.dataset.clearLabelImage].labelFileName = ""; saveState(state); render(); return false; });
  document.querySelectorAll("[data-cat-override-id]").forEach(el=>el.onchange=()=>{ const prod = (state.catalogState.products||[]).find(p=>String(p.id)===String(el.dataset.catOverrideId)); if(!prod) return; const raw = String(el.value||"").trim(); const nextOverride = raw === "" ? null : Number(raw); prod.manual_price = nextOverride; state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products||[]); saveState(state); render(); });
  document.querySelectorAll("[data-cat-reset-id]").forEach(el=>el.onclick=()=>{ const prod = (state.catalogState.products||[]).find(p=>String(p.id)===String(el.dataset.catResetId)); if(!prod) return; prod.manual_price = null; state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products||[]); saveState(state); render(); });
  document.querySelectorAll("[data-run-scenario]").forEach(btn=>btn.onclick=()=>{ if(applyRegressionScenario(state, btn.dataset.runScenario)){ saveState(state); render(); } });
  const forecastToOrderSheet=document.getElementById("forecastToOrderSheet");
  if(forecastToOrderSheet) forecastToOrderSheet.onclick=()=>{
    const mode = state.builderMode;
    const active = activeProgramRecord(state, mode);
    if(!active || !Array.isArray(active.lines) || !active.lines.length) return;
    const usage = forecastMaterialUsage(state, mode);
    const draft = usage.map((row, idx)=>({
      id:`forecast_${mode}_${Date.now()}_${idx}`,
      product_id:(state.labels[active.lines[idx]?.sku]||{}).id || active.lines[idx]?.sku || '',
      sku:active.lines[idx]?.sku || '',
      name:row.name,
      qty:Number(row.qty||0),
      unit:String(row.unit||'').split(' per ')[0] || 'oz',
      price:Number((row.cost||0) && row.qty ? row.cost/row.qty : 0),
      selected:true,
      source:'forecast'
    })).filter(r=>r.qty>0);
    state.orderSheetDraft = draft;
    state.view='orders';
    saveState(state);
    render();
  };
  const savePricingPdf=document.getElementById("savePricingPdf");
  if(savePricingPdf) savePricingPdf.onclick=()=>{
    const q=state.currentQuote;
    const body=`<div class="meta">${q.customer||""}<br>${q.address||""}${q.phone?`<br>${q.phone}`:""}${q.email?`<br>${q.email}`:""}<br>Turf Sq Ft: ${q.turfSqft||0} | Ornamental Sq Ft: ${q.ornamentalSqft||0} | Shrub Density: ${ornamentalDensityLabel(q.ornamentalDensity)} | Palm Count: ${q.palmCount||0}</div>
    <table class="tbl"><thead><tr><th>Service</th><th>Description</th><th>Price</th></tr></thead><tbody>
    ${q.services.turf.selected?`<tr><td>Turf Program (Monthly – 12 applications/year)</td><td>${q.services.turf.description}<div style="font-size:11px;color:#555">Includes routine site review, monthly service positioning, and technical support through the year.</div></td><td>${money(totals.turfRev)}</td></tr>`:""}
    ${q.services.ornamental.selected?`<tr><td>Ornamental Program (Monthly – 12 visits/year)</td><td>${q.services.ornamental.description}<div style="font-size:11px;color:#555">Designed for ongoing shrub and landscape plant health support with consistent monthly service.</div><div style="font-size:11px;color:#555">Shrub density tier: ${ornamentalDensityLabel(q.ornamentalDensity)}</div></td><td>${money(totals.ornRev)}</td></tr>`:""}
    ${q.services.palm.selected?`<tr><td>Palm Program (Monthly – 12 visits/year)</td><td>${q.services.palm.description}<div style="font-size:11px;color:#555">Ongoing palm service and nutritional support through the year. $4 per palm per month with a $25 monthly minimum.</div></td><td>${money(totals.palmRev.price)}</td></tr>`:""}
    ${totals.specialsRows.map(r=>`<tr><td>${r.name}</td><td>${r.description}<div style="font-size:11px;color:#555">${r.detail||""}</div><div style="font-size:11px;color:#555">${r.notes||""}</div></td><td>${money(r.price)}</td></tr>`).join("")}
    <tr><td><strong>Total Price</strong></td><td></td><td><strong>${money(totals.total)}</strong></td></tr>
    </tbody></table>`;
    openPrint(pdfDoc("Pricing Snapshot", body));
  };
  const saveEstimatePdf=document.getElementById("saveEstimatePdf");
  if(saveEstimatePdf) saveEstimatePdf.onclick=()=>{ const q=state.currentQuote; const body=`<div class="meta">${q.customer||""}<br>${q.address||""}${q.phone?`<br>${q.phone}`:""}${q.email?`<br>${q.email}`:""}</div><table class="tbl"><thead><tr><th>Recommended Service</th><th>Description</th><th>Price</th></tr></thead><tbody>${q.services.turf.selected?`<tr><td>Turf Program</td><td>${q.services.turf.description}<div style="font-size:11px;color:#555">${q.services.turf.notes||""}</div></td><td>${money(totals.turfRev)}</td></tr>`:""}${q.services.ornamental.selected?`<tr><td>Ornamental Program</td><td>${q.services.ornamental.description}<div style="font-size:11px;color:#555">${q.services.ornamental.notes||""}</div></td><td>${money(totals.ornRev)}</td></tr>`:""}${q.services.palm.selected?`<tr><td>Palm Program</td><td>${q.services.palm.description}<div style="font-size:11px;color:#555">${q.services.palm.notes||""}</div></td><td>${money(totals.palmRev.price)}</td></tr>`:""}${totals.specialsRows.map(r=>`<tr><td>${r.name}</td><td>${r.description}<div style="font-size:11px;color:#555">${r.detail||""}</div><div style="font-size:11px;color:#555">${r.notes||""}</div></td><td>${money(r.price)}</td></tr>`).join("")}<tr><td><strong>Subtotal</strong></td><td></td><td><strong>${money(totals.subtotal)}</strong></td></tr>${totals.discountPct?`<tr><td>Manual Discount (${totals.discountPct}%)</td><td>Applied on request</td><td>-${money(totals.discountAmount)}</td></tr>`:""}${totals.minimumServiceAdjustment?`<tr><td>Minimum Service Charge</td><td>Applied to quotes below the service minimum</td><td>${money(totals.minimumServiceAdjustment)}</td></tr>`:""}<tr><td><strong>Total</strong></td><td></td><td><strong>${money(totals.total)}</strong></td></tr></tbody></table>${q.includeBlurb && (q.notes||q.customNotes)?`<div class="box"><strong>Notes</strong><br><br>${[q.notes,q.customNotes].filter(Boolean).join("<br><br>")}</div>`:""}<div class="box"><strong>Acceptance & Authorization:</strong><br><br>Client Signature: ________________________________<br>Date: ________________________________</div><div class="note"><strong>Office delivery contact:</strong> ${APP_COPY.officeDeliveryContact}</div>`; openPrint(pdfDoc("Customer Estimate", body)); state.history.unshift({...JSON.parse(JSON.stringify(q)), total:totals.total, finalSoldValue:totals.total, accepted:false, status:"Pending", savedAt:new Date().toISOString()}); saveState(state); render(); };
  const shareBtn=document.getElementById("shareEstimate");
  if(shareBtn) shareBtn.onclick=()=>shareEstimate(state, totals, intel);
  const emailEstimate=document.getElementById("emailEstimate");
  if(emailEstimate) emailEstimate.onclick=()=>{ window.location.href=`mailto:${encodeURIComponent(state.currentQuote.email||"")}?subject=${encodeURIComponent(APP_META.estimateSubjectPrefix+" - "+(state.currentQuote.customer||"Customer"))}&body=${encodeURIComponent(estText)}`; };
  const textEstimate=document.getElementById("textEstimate");
  if(textEstimate) textEstimate.onclick=()=>{ window.location.href=`sms:?&body=${encodeURIComponent(estText)}`; };
  const downloadEstimateText=document.getElementById("downloadEstimateText");
  if(downloadEstimateText) downloadEstimateText.onclick=()=>downloadText("program-architect-estimate.txt", estText);
  
  const orderSheetPdf=document.getElementById("orderSheetPdf");
  if(orderSheetPdf) orderSheetPdf.onclick=()=>{
    openPrint(pdfDoc('Vendor Order Sheet', buildOrderSheetPrintBody(state)));
  };
  const orderSheetEmail=document.getElementById("orderSheetEmail");
  if(orderSheetEmail) orderSheetEmail.onclick=async ()=>{
    const body = buildOrderSheetEmailText(state);
    const to = encodeURIComponent('rick@genesiswm.net');
    const subject = encodeURIComponent(APP_META.orderSheetTitle);
    const mailtoUrl = `mailto:${to}?subject=${subject}&body=${encodeURIComponent(body)}`;
    let copied = false;
    try {
      if(navigator.clipboard && window.isSecureContext){
        await navigator.clipboard.writeText(body);
        copied = true;
      }
    } catch(err){}
    try {
      window.open(mailtoUrl, '_blank');
      if(window.location.href !== mailtoUrl) {
        const frame = document.createElement('iframe');
        frame.style.display = 'none';
        frame.src = mailtoUrl;
        document.body.appendChild(frame);
        setTimeout(()=>frame.remove(), 1500);
      }
    } catch(err){
      window.location.href = mailtoUrl;
    }
    if(copied) alert('Order sheet email draft opened for rick@genesiswm.net. The order sheet text was also copied to your clipboard as a fallback.');
    else alert('Order sheet email draft opened for rick@genesiswm.net. If your mail app does not launch, use Copy Order Sheet Text or PDF.');
  };
  const copyOrderSheetText=document.getElementById('copyOrderSheetText');
  if(copyOrderSheetText) copyOrderSheetText.onclick=async ()=>{
    const body = buildOrderSheetEmailText(state);
    try {
      if(navigator.clipboard && window.isSecureContext){
        await navigator.clipboard.writeText(body);
        alert('Order sheet text copied to clipboard.');
      } else {
        const ta = document.createElement('textarea');
        ta.value = body;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
        alert('Order sheet text copied to clipboard.');
      }
    } catch(err){
      alert('Clipboard copy was blocked by this browser. Use Download TXT instead.');
    }
  };
  const downloadOrderSheetText=document.getElementById('downloadOrderSheetText');
  if(downloadOrderSheetText) downloadOrderSheetText.onclick=()=>downloadText('genesis-order-sheet.txt', buildOrderSheetEmailText(state));
  const downloadOrderSheetCsv=document.getElementById('downloadOrderSheetCsv');
  if(downloadOrderSheetCsv) downloadOrderSheetCsv.onclick=()=>{
    const s = orderSheetSummary(state);
    const header = ['SKU','Product','Need for Program','On Hand','Min','Target','Buy Now','Unit','Unit Price','Line Total','Vendor','Price Source'];
    const rows = s.draft.map(r=>[
      r.sku||'',
      r.name||'',
      Number(r.qty||0).toFixed(2),
      isStockedItem(findCatalogProductForRow(state, r)||r) ? orderRowOnHand(state, r).toFixed(2) : '',
      isStockedItem(findCatalogProductForRow(state, r)||r) ? reorderMinimum(findCatalogProductForRow(state, r)||r).toFixed(2) : '',
      isStockedItem(findCatalogProductForRow(state, r)||r) ? targetStock(findCatalogProductForRow(state, r)||r).toFixed(2) : '',
      orderRowOrderNow(state, r).toFixed(2),
      r.unit||'',
      orderRowUnitPrice(state, r).toFixed(2),
      orderRowLineTotal(state, r).toFixed(2),
      r.vendor||'',
      r.price_source || catalogPriceSourceLabel(findCatalogProductForRow(state, r)||r)
    ]);
    const csv = [header, ...rows].map(cols=>cols.map(v=>`"${String(v??'').replace(/"/g,'""')}"`).join(',')).join('\n');
    downloadText('genesis-order-sheet.csv', csv);
  };

  document.querySelectorAll("[data-cat-inventory]").forEach(el=>el.onchange=()=>{ const row = orderSheetVisibleCatalogRows(state)[Number(el.dataset.catInventory)]; if(!row) return; const prod = findCatalogProductInList(state.catalogState.products||[], row); if(!prod) return; prod.inventory_on_hand = Number(el.value||0); state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products||[]); saveState(state); render(); });
  document.querySelectorAll("[data-cat-min]").forEach(el=>el.onchange=()=>{ const row = orderSheetVisibleCatalogRows(state)[Number(el.dataset.catMin)]; if(!row) return; const prod = findCatalogProductInList(state.catalogState.products||[], row); if(!prod || !isStockedItem(prod)) return; prod.reorder_min = Number(el.value||0); state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products||[]); saveState(state); render(); });
  document.querySelectorAll("[data-cat-target]").forEach(el=>el.onchange=()=>{ const row = orderSheetVisibleCatalogRows(state)[Number(el.dataset.catTarget)]; if(!row) return; const prod = findCatalogProductInList(state.catalogState.products||[], row); if(!prod || !isStockedItem(prod)) return; prod.target_stock = Number(el.value||0); state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products||[]); saveState(state); render(); });
  const orderCatalogFilter=document.getElementById('orderCatalogFilter');
  if(orderCatalogFilter) orderCatalogFilter.onchange = ()=>{ state.orderCatalogFilter = orderCatalogFilter.value || 'all'; saveState(state); render(); };
  document.querySelectorAll("[data-cat-stocked]").forEach(el=>el.onchange=()=>{ const row = orderSheetVisibleCatalogRows(state)[Number(el.dataset.catStocked)]; if(!row) return; const prod = findCatalogProductInList(state.catalogState.products||[], row); if(!prod) return; prod.track_inventory = !!el.checked; state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products||[]); saveState(state); render(); });
  const bindInventoryCommit=(selector, datasetKey, field, stockedOnly=false)=>{
    document.querySelectorAll(selector).forEach(el=>{
      const commit=()=>{
        const row = orderSheetVisibleCatalogRows(state)[Number(el.dataset[datasetKey])];
        if(!row) return;
        const prod = findCatalogProductInList(state.catalogState.products||[], row);
        if(!prod) return;
        if(stockedOnly && !isStockedItem(prod)) return;
        prod[field] = Number(el.value||0);
        state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products||[]);
        saveState(state);
      };
      el.addEventListener('change', ()=>{ commit(); render(); });
      el.addEventListener('blur', ()=>{ commit(); render(); });
      el.addEventListener('keydown', evt=>{ if(evt.key === 'Enter'){ evt.preventDefault(); commit(); render(); } });
    });
  };
  bindInventoryCommit("[data-cat-inventory]", "catInventory", "inventory_on_hand", false);
  bindInventoryCommit("[data-cat-min]", "catMin", "reorder_min", true);
  bindInventoryCommit("[data-cat-target]", "catTarget", "target_stock", true);
  const modeEl = document.getElementById('orderPurchaseMode');
  if(modeEl) modeEl.onchange = ()=>{ state.orderPurchaseMode = modeEl.value || 'target'; saveState(state); render(); };
  const clearOnHandBtn = document.getElementById('resetInventoryOnHand');
  if(clearOnHandBtn) clearOnHandBtn.onclick = ()=>{ (state.catalogState.products||[]).forEach(p=>{ if(isStockedItem(p)) p.inventory_on_hand = 0; }); state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products||[]); saveState(state); render(); };
  const clearMinBtn = document.getElementById('resetInventoryMin');
  if(clearMinBtn) clearMinBtn.onclick = ()=>{ (state.catalogState.products||[]).forEach(p=>{ if(isStockedItem(p)) p.reorder_min = 0; }); state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products||[]); saveState(state); render(); };
  const clearTargetBtn = document.getElementById('resetInventoryTarget');
  if(clearTargetBtn) clearTargetBtn.onclick = ()=>{ (state.catalogState.products||[]).forEach(p=>{ if(isStockedItem(p)) p.target_stock = 0; }); state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products||[]); saveState(state); render(); };
  const clearOverridesBtn = document.getElementById('clearManualOverrides');
  if(clearOverridesBtn) clearOverridesBtn.onclick = ()=>{ (state.catalogState.products||[]).forEach(p=>{ p.manual_price = ''; p.current_price = vendorPriceValue(p); }); state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products||[]); saveState(state); render(); };
  const filterByTokens=(haystack, query)=>{
    const q=(query||'').trim().toLowerCase();
    if(!q) return true;
    const tokens=q.split(/\s+/).filter(Boolean);
    return tokens.every(token => haystack.includes(token));
  };
  const applyLiveCatalogSearch=(query)=>{
    const q=(query||'').trim().toLowerCase();
    document.querySelectorAll('[data-catalog-row]').forEach(row=>{
      const hay=(row.dataset.searchtext||'').toLowerCase();
      row.style.display = filterByTokens(hay,q) ? '' : 'none';
    });
  };
  const applyLiveOrderSheetSearch=(query)=>{
    const q=(query||'').trim().toLowerCase();
    document.querySelectorAll('[data-order-catalog-row]').forEach(row=>{
      const hay=(row.dataset.searchtext||'').toLowerCase();
      row.style.display = filterByTokens(hay,q) ? '' : 'none';
    });
    const select=document.getElementById('orderCatalogSelect');
    if(select){
      Array.from(select.options).forEach((opt, idx)=>{
        if(idx===0){ opt.hidden=false; return; }
        const hay=(opt.dataset.searchtext||opt.textContent||'').toLowerCase();
        opt.hidden = !filterByTokens(hay,q);
      });
      if(select.selectedOptions[0]?.hidden) select.value='';
    }
  };
  const catalogSearch=document.getElementById("catalogSearch");
  if(catalogSearch){
    let catalogSearchTimer = null;
    const commitCatalogSearch = (shouldRender=true)=>{
      state.catalogSearch = catalogSearch.value || '';
      saveState(state);
      if(shouldRender) render();
    };
    catalogSearch.addEventListener('input', ()=>{
      const value = catalogSearch.value || '';
      state.catalogSearch = value;
      applyLiveCatalogSearch(value);
      if(catalogSearchTimer) clearTimeout(catalogSearchTimer);
      catalogSearchTimer = setTimeout(()=>saveState(state), 250);
    });
    catalogSearch.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter'){
        e.preventDefault();
        if(catalogSearchTimer) clearTimeout(catalogSearchTimer);
        commitCatalogSearch(true);
      }
    });
    catalogSearch.addEventListener('blur', ()=>commitCatalogSearch(false));
    catalogSearch.addEventListener('search', ()=>commitCatalogSearch(true));
    applyLiveCatalogSearch(catalogSearch.value || '');
  }
  const orderSheetSearch=document.getElementById("orderSheetSearch");
  if(orderSheetSearch){
    let orderSheetSearchTimer = null;
    const commitOrderSheetSearch = (shouldRender=true)=>{
      state.orderSheetSearch = orderSheetSearch.value || '';
      saveState(state);
      if(shouldRender) render();
    };
    orderSheetSearch.addEventListener('input', ()=>{
      const value = orderSheetSearch.value || '';
      state.orderSheetSearch = value;
      applyLiveOrderSheetSearch(value);
      if(orderSheetSearchTimer) clearTimeout(orderSheetSearchTimer);
      orderSheetSearchTimer = setTimeout(()=>saveState(state), 250);
    });
    orderSheetSearch.addEventListener('keydown', (e)=>{
      if(e.key === 'Enter'){
        e.preventDefault();
        if(orderSheetSearchTimer) clearTimeout(orderSheetSearchTimer);
        commitOrderSheetSearch(true);
      }
    });
    orderSheetSearch.addEventListener('blur', ()=>commitOrderSheetSearch(false));
    orderSheetSearch.addEventListener('search', ()=>commitOrderSheetSearch(true));
    applyLiveOrderSheetSearch(orderSheetSearch.value || '');
  }
  document.querySelectorAll("[data-add-order-row]").forEach(el=>el.onclick=()=>{ const idx = Number(el.dataset.addOrderRow); const product = orderSheetVisibleCatalogRows(state)[idx]; const qtyInput = document.querySelector(`[data-order-qty-row="${idx}"]`); const qty = Number(qtyInput?.value||0); if(!upsertOrderDraftLine(state, product, qty, 'manual')) return; saveState(state); render(); });
  document.querySelectorAll("[data-draft-qty]").forEach(el=>el.onchange=()=>{ const idx = Number(el.dataset.draftQty); if(!state.orderSheetDraft?.[idx]) return; state.orderSheetDraft[idx].qty = Number(el.value||0); saveState(state); render(); });
  document.querySelectorAll("[data-delete-draft]").forEach(el=>el.onclick=()=>{ const idx = Number(el.dataset.deleteDraft); if(!state.orderSheetDraft?.[idx]) return; state.orderSheetDraft.splice(idx,1); saveState(state); render(); });
  const clearOrderDraft=document.getElementById("clearOrderDraft");
  if(clearOrderDraft) clearOrderDraft.onclick=()=>{ state.orderSheetDraft = []; saveState(state); render(); };
  const addCatalogItemToOrder=document.getElementById("addCatalogItemToOrder");
  document.querySelectorAll('[data-draft-price]').forEach(el=>el.onchange=()=>{ const idx = Number(el.dataset.draftPrice); const row = state.orderSheetDraft?.[idx]; if(!row) return; const next = Number(el.value||0); row.unit_price = next; row.manual_override = true; row.price_source = 'Manual override'; row.cost = orderRowLineTotal(state, row); saveState(state); render(); });
  document.querySelectorAll('[data-reset-draft-price]').forEach(btn=>btn.onclick=()=>{ const idx = Number(btn.dataset.resetDraftPrice); const row = state.orderSheetDraft?.[idx]; if(!row) return; const product = findCatalogProductForRow(state, row) || row; const info = resolveCatalogPrice({...product, manual_price:''}); if(info.missing){ alert(`No vendor price is saved for ${row.name || 'this item'} yet.`); return; } row.unit_price = Number(info.price||0); row.manual_override = false; row.price_source = info.source; row.cost = orderRowLineTotal(state, row); saveState(state); render(); });
  if(addCatalogItemToOrder) addCatalogItemToOrder.onclick=()=>{ const select=document.getElementById("orderCatalogSelect"); const qtyEl=document.getElementById("orderCatalogQty"); const value = select?.value || ''; const product = orderSheetCatalogRows(state).find(p=>String(catalogProductIdentifier(p))===String(value)); const qty = Number(qtyEl?.value||0); if(!upsertOrderDraftLine(state, product, qty, 'manual')) return; saveState(state); render(); };
  const importCatalogPaste=document.getElementById("importCatalogPaste");
  if(importCatalogPaste) importCatalogPaste.onclick=()=>{
    const category = document.getElementById("catalogImportCategory")?.value || "materials";
    const text = document.getElementById("catalogPaste")?.value || "";
    const rows = parseCatalogDelimited(text, category, {source_type:"pasted"});
    if(!rows.length){ alert("No rows found to stage."); return; }
    stageImportRows(state, rows, {source_type:"pasted", category});
    saveState(state); render();
  };
  const importCatalogFile=document.getElementById("importCatalogFile");
  if(importCatalogFile) importCatalogFile.onclick=async()=>{
    const file = document.getElementById("catalogFile")?.files?.[0];
    if(!file){ alert("Choose a catalog file first."); return; }
    const category = document.getElementById("catalogImportCategory")?.value || "materials";
    let rows = [];
    try{
      const lower = file.name.toLowerCase();
      if(lower.endsWith('.json')){
        const text = await file.text();
        rows = parseCatalogJson(text, category, {source_type:'json', source_file:file.name});
      } else if(lower.endsWith('.pdf')){
        const text = await extractPdfText(file);
        if(/%PDF-|\/Parent|\/Resources|\/MediaBox/.test(text)) throw new Error('raw-pdf-tokens');
        rows = parsePdfBidText(text, category, {source_type:'pdf', source_file:file.name});
      } else {
        const text = await file.text();
        rows = parseCatalogDelimited(text, category, {source_type:'csv', source_file:file.name});
      }
    }catch(err){
      alert(file.name.toLowerCase().endsWith('.pdf') ? `${APP_COPY.pdfOfflineHelp} Try again while online, or convert the bid to CSV first.` : "That file could not be staged. Use CSV, TSV, TXT, JSON, or a readable vendor bid PDF.");
      return;
    }
    if(!rows.length){ alert("No rows found to stage."); return; }
    stageImportRows(state, rows, {source_type:file.name.toLowerCase().endsWith('.pdf')?'pdf':'file', source_file:file.name, category});
    saveState(state); render();
  };
  document.querySelectorAll('[data-stage-include]').forEach(el=>el.onchange=()=>{
    const idx = Number(el.dataset.stageInclude);
    if(state.importState?.stagingRows?.[idx]){
      state.importState.stagingRows[idx].include = !!el.checked;
      saveState(state);
    }
  });
  const commitCatalogStaging=document.getElementById('commitCatalogStaging');
  if(commitCatalogStaging) commitCatalogStaging.onclick=()=>{
    const count = commitStagedRows(state);
    if(!count){ alert('No staged rows selected.'); return; }
    saveState(state); render();
  };
  const clearCatalogStaging=document.getElementById('clearCatalogStaging');
  if(clearCatalogStaging) clearCatalogStaging.onclick=()=>{
    state.importState = {...defaultState.importState};
    saveState(state); render();
  };
  const addCatalogItem=document.getElementById("addCatalogItem");
  if(addCatalogItem) addCatalogItem.onclick=()=>{
    const catEl=document.getElementById("catalogCategory");
    const nameEl=document.getElementById("catalogName");
    const skuEl=document.getElementById("catalogSku");
    const npkEl=document.getElementById("catalogNpk");
    const priceEl=document.getElementById("catalogPrice");
    const notesEl=document.getElementById("catalogNotes");
    const category=catEl?.value||"materials";
    const name=(nameEl?.value||"").trim();
    if(!name){ alert("Enter an item name."); return; }
    const row=normalizeCatalogRow({name, sku:(skuEl?.value||"").trim(), npk:(npkEl?.value||"").trim(), price:Number(priceEl?.value||0), notes:(notesEl?.value||"").trim(), category, source_type:'manual'}, category);
    addCatalogRows(state, [row]);
    saveState(state); render();
  };
  document.querySelectorAll("[data-del-cat]").forEach(el=>el.onclick=()=>{
    const [category, idx] = el.dataset.delCat.split("|");
    const row = state.vendorCatalog?.[category]?.[Number(idx)];
    const removeId = row?.id;
    state.catalogState.products = (state.catalogState.products||[]).filter(p=>p.id !== removeId);
    state.vendorCatalog = rebuildVendorCatalogFromProducts(state.catalogState.products||[]);
    saveState(state); render();
  });
  const smartDefaults=document.getElementById("smartDefaults");
  if(smartDefaults) smartDefaults.onclick=()=>{
    applySmartQuoteDefaults(state);
    saveState(state);
    render();
  };
  const exportBackupBtn = document.getElementById("exportBackup");
  if(exportBackupBtn) exportBackupBtn.onclick=()=>{ exportBackup(state); render(); };
  const autoBackupOnSave = document.getElementById("autoBackupOnSave");
  if(autoBackupOnSave) autoBackupOnSave.onchange=()=>{ state.settings = {...defaultState.settings, ...(state.settings||{}), autoBackupOnSave: !!autoBackupOnSave.checked}; saveState(state); render(); };
  const importBackupFile = document.getElementById("importBackupFile");
  const importBackupTrigger = document.getElementById("importBackupTrigger");
  if(importBackupTrigger && importBackupFile) importBackupTrigger.onclick=()=>importBackupFile.click();
  if(importBackupFile) importBackupFile.onchange=async(ev)=>{
    const file = ev.target.files && ev.target.files[0];
    if(!file) return;
    try{
      importBackupText(await file.text());
      alert(`Backup restored from ${file.name}.`);
      render();
      return;
    }catch(err){
      alert(`Backup restore failed. ${err?.message || 'The selected file is not a valid Program Architect backup.'}`);
    }finally{
      ev.target.value = "";
    }
  };
  const resetAppDataBtn = document.getElementById("resetAppData");
  if(resetAppDataBtn) resetAppDataBtn.onclick=()=>{
    if(!confirm("Reset all local Program Architect data on this device? This clears quotes, catalog edits, labels, and saved programs.")) return;
    const reset = structuredClone(defaultState);
    saveState(reset);
    render();
  };
document.querySelectorAll("[data-revise]").forEach(el=>el.onclick=()=>{ state.currentQuote = JSON.parse(JSON.stringify(state.history[Number(el.dataset.revise)])); state.view="quote"; saveState(state); render(); });
  document.querySelectorAll("[data-resend]").forEach(el=>el.onclick=()=>{ const rec=state.history[Number(el.dataset.resend)]; const tmp={...state, currentQuote:rec}; const txt=buildEstimateText(tmp, quoteTotals(tmp), intel); window.location.href=`mailto:${encodeURIComponent(rec.email||"")}?subject=${encodeURIComponent(APP_META.estimateSubjectPrefix+" - "+(rec.customer||"Customer"))}&body=${encodeURIComponent(txt)}`; });
  document.querySelectorAll("[data-delete-est]").forEach(el=>el.onclick=()=>{ state.history.splice(Number(el.dataset.deleteEst),1); saveState(state); render(); });
}
window.addEventListener("beforeinstallprompt", e => {
  e.preventDefault();
  installPrompt = e;
  const btn = document.getElementById("installBtn");
  if(btn) btn.classList.remove("hidden");
});
window.addEventListener("DOMContentLoaded", ()=>{
  const btn = document.getElementById("installBtn");
  if(btn){
    btn.onclick = async ()=>{
      if(!installPrompt) return;
      installPrompt.prompt();
      await installPrompt.userChoice;
      installPrompt = null;
      btn.classList.add("hidden");
    };
  }
  if("serviceWorker" in navigator){ navigator.serviceWorker.register("./sw.js").catch(()=>{}); }
  render();
});
