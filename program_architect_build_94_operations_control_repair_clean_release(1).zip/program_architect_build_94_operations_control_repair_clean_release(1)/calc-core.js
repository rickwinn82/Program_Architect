(function(global){
  const defaultAssumptions = {
    frequency_map: {
      monthly: 12,
      quarterly: 4,
      "bi-monthly": 6,
      bimonthly: 6,
      "semi-annual": 2,
      semiannual: 2,
      annual: 1,
      yearly: 1,
      "one-time": 1,
      "one time": 1,
      one_time: 1,
      "as-needed": 1,
      asneeded: 1,
      "as needed": 1,
      custom: 1
    },
    tolerance: {
      money_warn: 0.01,
      money_bad: 25,
      margin_warn: 1,
      margin_bad: 7,
      screen_diff_warn: 0.01
    },
    target_margins: {
      turf: 45,
      ornamental: 50,
      palm: 55,
      specials: 60
    }
  };

  const defaultServiceCosts = {
    "Turf Program": {cost_mode:"per_1000_sqft", cost_value:3.25},
    "Ornamental Program": {cost_mode:"per_1000_sqft", cost_value:2.4},
    "Palm Program": {cost_mode:"palm_recurring", visit_base_cost:8, chemistry_cost_per_palm:0.55, labor_cost_per_palm:0.30, minimum_cost:10},
    "Fire Ant Treatment": {cost_mode:"flat", cost_value:65},
    "Growth Regulation Program": {cost_mode:"flat", cost_value:55},
    "Salinity Remediation": {cost_mode:"flat", cost_value:95}
  };

  let assumptions = JSON.parse(JSON.stringify(defaultAssumptions));
  let serviceCosts = Object.assign({}, defaultServiceCosts);

  function mergeInto(target, src){
    Object.keys(src || {}).forEach(key => {
      const value = src[key];
      if (value && typeof value === "object" && !Array.isArray(value)) {
        target[key] = target[key] && typeof target[key] === "object" && !Array.isArray(target[key]) ? target[key] : {};
        mergeInto(target[key], value);
      } else {
        target[key] = value;
      }
    });
    return target;
  }

  function normalizedName(value){
    return String(value || "").trim().toLowerCase();
  }
  function round2(n){
    return Math.round(Number(n || 0) * 100) / 100;
  }
  function money(n){
    return Number(n || 0).toLocaleString(undefined,{style:"currency",currency:"USD"});
  }
  function rowAnnualVisits(row){
    const explicit = Number(row?.annual_visits || 0);
    if (explicit > 0) return explicit;
    const freq = normalizedName(row?.frequency).replace(/\s+/g, " ");
    return Number(assumptions.frequency_map[freq] || 1);
  }
  function rowIsRecurring(row, jobRevenueType){
    if (typeof row?.recurring === "boolean") return row.recurring;
    const freq = normalizedName(row?.frequency).replace(/\s+/g, " ");
    if (["as-needed","as needed","asneeded","one-time","one time","one_time"].includes(freq)) return false;
    if (freq && assumptions.frequency_map[freq] > 1) return true;
    return normalizedName(jobRevenueType || row?.revenue_type || "recurring") === "recurring";
  }
  function costConfigForService(name){
    if (serviceCosts[name]) return serviceCosts[name];
    const key = Object.keys(serviceCosts).find(k => normalizedName(k) === normalizedName(name));
    return key ? serviceCosts[key] : null;
  }
  function serviceCost(row, property){
    const cfg = costConfigForService(row?.name) || {cost_mode:"flat", cost_value:0};
    const value = Number(cfg.cost_value || 0);
    if (cfg.cost_mode === "per_1000_sqft") {
      const name = String(row?.name || "");
      const turfSqft = Number(property?.turf_sqft || property?.turfSqft || 0);
      const ornamentalSqft = Number(property?.ornamental_sqft || property?.ornamentalSqft || 0);
      const sqft = /ornamental/i.test(name) ? ornamentalSqft : turfSqft;
      return round2((sqft / 1000) * value);
    }
    if (cfg.cost_mode === "per_unit") {
      const palmCount = Number(property?.palm_count || property?.palmCount || 0);
      const unitCost = round2(palmCount * value);
      const minimumCost = Number(cfg.minimum_cost || 0);
      return round2(unitCost > 0 ? Math.max(unitCost, minimumCost) : 0);
    }
    if (cfg.cost_mode === "palm_recurring") {
      const palmCount = Number(property?.palm_count || property?.palmCount || 0);
      if (palmCount <= 0) return 0;
      const visitBaseCost = Number(cfg.visit_base_cost || 0);
      const chemistryCost = Number(cfg.chemistry_cost_per_palm || 0);
      const laborCost = Number(cfg.labor_cost_per_palm || 0);
      const minimumCost = Number(cfg.minimum_cost || 0);
      const modeled = round2(visitBaseCost + (palmCount * chemistryCost) + (palmCount * laborCost));
      return round2(Math.max(modeled, minimumCost));
    }
    return round2(value);
  }
  function calcRowMetrics(row, property, jobRevenueType){
    const revenue = round2(Number(row?.price || 0));
    const cost = round2(serviceCost(row, property));
    const profit = round2(revenue - cost);
    const margin_pct = revenue > 0 ? round2((profit / revenue) * 100) : 0;
    const annual_visits = rowAnnualVisits(row);
    const recurring = rowIsRecurring(row, jobRevenueType);
    const arr_component = recurring ? round2(revenue * annual_visits) : 0;
    const annual_revenue_total = recurring ? arr_component : revenue;
    const annual_cost_total = recurring ? round2(cost * annual_visits) : cost;
    const annual_profit_total = round2(annual_revenue_total - annual_cost_total);
    return Object.assign({}, row || {}, {
      revenue,
      cost,
      profit,
      margin_pct,
      annual_visits,
      recurring,
      revenue_type: recurring ? "recurring" : "one_time",
      arr_component,
      mrr_component: recurring ? round2(arr_component / 12) : 0,
      annual_revenue_total,
      annual_cost_total,
      annual_profit_total
    });
  }
  function calcJobMetrics(job){
    const rows = Array.isArray(job?.service_rows) ? job.service_rows : [];
    const property = job?.property || {};
    const jobRevenueType = job?.revenue_type || "recurring";
    const rowMetrics = rows.map(row => calcRowMetrics(row, property, jobRevenueType));
    const revenue = round2(rowMetrics.reduce((sum, row) => sum + row.revenue, 0));
    const cost = round2(rowMetrics.reduce((sum, row) => sum + row.cost, 0));
    const profit = round2(revenue - cost);
    const margin_pct = revenue > 0 ? round2((profit / revenue) * 100) : 0;
    const arr = round2(rowMetrics.reduce((sum, row) => sum + row.arr_component, 0));
    const mrr = round2(arr / 12);
    const annual_revenue_total = round2(rowMetrics.reduce((sum, row) => sum + row.annual_revenue_total, 0));
    const annual_cost_total = round2(rowMetrics.reduce((sum, row) => sum + row.annual_cost_total, 0));
    const annual_profit_total = round2(annual_revenue_total - annual_cost_total);
    const annual_margin_pct = annual_revenue_total > 0 ? round2((annual_profit_total / annual_revenue_total) * 100) : 0;
    const flags = buildMathFlags({job, rows: rowMetrics, revenue, cost, profit, margin_pct, arr, mrr, annual_revenue_total, annual_cost_total, annual_profit_total, annual_margin_pct});
    return { rows: rowMetrics, revenue, cost, profit, margin_pct, arr, mrr, annual_revenue_total, annual_cost_total, annual_profit_total, annual_margin_pct, flags };
  }
  function buildMathFlags(metrics){
    const flags = [];
    const tolerance = assumptions.tolerance || {};
    const rows = metrics.rows || [];
    rows.forEach(row => {
      if (row.revenue > 0 && row.cost === 0) {
        flags.push({level:"warn", code:"ZERO_COST", message:`${row.name || "Service"} has revenue but zero modeled cost.`});
      }
      if (row.margin_pct < 0) {
        flags.push({level:"bad", code:"NEGATIVE_MARGIN", message:`${row.name || "Service"} has negative gross margin.`});
      }
      const implied = row.recurring ? row.arr_component : row.revenue;
      if (Math.abs(round2(implied - row.annual_revenue_total)) > Number(tolerance.screen_diff_warn || 0.01)) {
        flags.push({level:"warn", code:"ROW_ANNUALIZATION", message:`${row.name || "Service"} annualization is not internally aligned.`});
      }
    });
    if (metrics.revenue > 0 && metrics.cost === 0) {
      flags.push({level:"warn", code:"JOB_ZERO_COST", message:"Total revenue is positive but total modeled cost is zero."});
    }
    if (metrics.margin_pct < 0) {
      flags.push({level:"bad", code:"JOB_NEGATIVE_MARGIN", message:"Overall gross margin is negative."});
    }
    return flags;
  }
  function severityByDiff(absDiff, warnAt, badAt){
    if (absDiff > badAt) return "bad";
    if (absDiff > warnAt) return "warn";
    return "ok";
  }
  function worst(a, b){
    const order = {ok:0, warn:1, bad:2};
    return order[b] > order[a] ? b : a;
  }
  function compareMetric(actual, expected, label, formatter, warnAt, badAt){
    const diff = round2(actual - expected);
    return {
      status: severityByDiff(Math.abs(diff), warnAt, badAt),
      message: `${label} expected ${formatter(expected)} vs actual ${formatter(actual)} (diff ${formatter(diff)})`,
      diff
    };
  }
  function regressionPackFromJobs(jobs){
    return (Array.isArray(jobs) ? jobs : []).map(job => {
      const m = calcJobMetrics(job);
      return {
        job_name: job.job_name || "Unnamed Job",
        expected_revenue: m.revenue,
        expected_cost: m.cost,
        expected_margin_pct: m.margin_pct,
        expected_recurring_type: job.revenue_type || "recurring",
        expected_annual_revenue: m.annual_revenue_total,
        expected_arr: m.arr,
        expected_mrr: m.mrr
      };
    });
  }
  global.PA_Calc = {
    assumptions,
    getServiceCosts: () => Object.assign({}, serviceCosts),
    setServiceCosts: next => { serviceCosts = Object.assign({}, serviceCosts, next || {}); },
    normalizedName,
    round2,
    money,
    rowAnnualVisits,
    rowIsRecurring,
    costConfigForService,
    serviceCost,
    calcRowMetrics,
    calcJobMetrics,
    buildMathFlags,
    severityByDiff,
    worst,
    compareMetric,
    regressionPackFromJobs
  };
})(window);
