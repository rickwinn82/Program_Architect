export const STORAGE_KEY = "program-architect-unified-v2-build82";
export const LEGACY_STORAGE_KEYS = [
  "program-architect-unified-v2-build79",
  "program-architect-unified-v2-build78",
  "program-architect-unified-v2-build77",
  "program-architect-unified-v2-build73",
  "program-architect-unified-v2-build72",
  "program-architect-unified-v2-build71",
  "program-architect-unified-v2-build70"
];

export const APP_META = {
  appName: "Program Architect",
  buildLabel: "Build 94 Operations Control Repair",
  officeContactEmail: "rick@genesiswm.net",
  officeContactPhone: "941-720-6840",
  orderSheetTitle: "Genesis Development Order Sheet",
  estimateSubjectPrefix: "Program Architect Estimate",
  backupFilePrefix: "program-architect-backup"
};

export const APP_COPY = {
  officeDeliveryContact: `${APP_META.officeContactEmail} | ${APP_META.officeContactPhone}`,
  pdfOfflineHelp: "Vendor bid PDF import could not load the local PDF.js bundle."
};
