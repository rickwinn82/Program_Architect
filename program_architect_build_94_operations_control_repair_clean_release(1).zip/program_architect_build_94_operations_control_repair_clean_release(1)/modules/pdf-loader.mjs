let pdfModulePromise = null;

export async function ensurePdfJsModule(pdfUrl, workerUrl){
  if(globalThis.pdfjsLib) return globalThis.pdfjsLib;
  if(!pdfModulePromise){
    pdfModulePromise = import(/* @vite-ignore */ pdfUrl)
      .then(mod => mod?.default || mod)
      .then(pdfjsLib => {
        if(!pdfjsLib) throw new Error("PDF.js module failed to load.");
        pdfjsLib.GlobalWorkerOptions.workerSrc = workerUrl;
        globalThis.pdfjsLib = pdfjsLib;
        return pdfjsLib;
      });
  }
  return pdfModulePromise;
}
