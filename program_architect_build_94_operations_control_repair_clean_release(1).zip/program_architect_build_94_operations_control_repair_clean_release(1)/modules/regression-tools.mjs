export function createRegressionTools(deps){
  const {
    blankRegressionQuote,
    todayKey,
    quoteTotals,
    seasonalWindow,
    advisory
  } = deps;

  const regressionScenarios = [
    { key:'turf5000', title:'Turf only — 5,000 sq ft monthly', kind:'quote', focus:'Baseline turf monthly pricing', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 5000; q.ornamentalSqft = 0; q.palmCount = 0; q.services.turf.selected = true; state.currentQuote = q; state.view='quote'; } },
    { key:'orn3000', title:'Ornamental only — 3,000 sq ft monthly', kind:'quote', focus:'Baseline ornamental monthly pricing', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 0; q.ornamentalSqft = 3000; q.palmCount = 0; q.services.ornamental.selected = true; state.currentQuote = q; state.view='quote'; } },
    { key:'trio_base', title:'Turf + ornamental + palms', kind:'quote', focus:'Blended recurring monthly quote', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 5000; q.ornamentalSqft = 3000; q.palmCount = 8; q.services.turf.selected = true; q.services.ornamental.selected = true; q.services.palm.selected = true; state.currentQuote = q; state.view='quote'; } },
    { key:'trio_discount5', title:'Trio quote with 5% manual discount', kind:'quote', focus:'Discounted monthly quote — 5%', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 5000; q.ornamentalSqft = 3000; q.palmCount = 8; q.services.turf.selected = true; q.services.ornamental.selected = true; q.services.palm.selected = true; q.manualDiscountPct = 5; state.currentQuote = q; state.view='quote'; } },
    { key:'trio_discount10', title:'Trio quote with 10% manual discount', kind:'quote', focus:'Discounted monthly quote — 10%', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 5000; q.ornamentalSqft = 3000; q.palmCount = 8; q.services.turf.selected = true; q.services.ornamental.selected = true; q.services.palm.selected = true; q.manualDiscountPct = 10; state.currentQuote = q; state.view='quote'; } },
    { key:'palm3', title:'Palm minimum case — 3 palms', kind:'quote', focus:'Palm monthly minimum should hold at $25', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 0; q.ornamentalSqft = 0; q.palmCount = 3; q.services.palm.selected = true; state.currentQuote = q; state.view='quote'; } },
    { key:'palm8', title:'Palm count case — 8 palms', kind:'quote', focus:'Palm monthly price should be $32', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 0; q.ornamentalSqft = 0; q.palmCount = 8; q.services.palm.selected = true; state.currentQuote = q; state.view='quote'; } },
    { key:'palm20', title:'Palm count case — 20 palms', kind:'quote', focus:'Palm monthly price should be $80', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 0; q.ornamentalSqft = 0; q.palmCount = 20; q.services.palm.selected = true; state.currentQuote = q; state.view='quote'; } },
    { key:'fireant350', title:'Special treatment — Fire Ant add-on', kind:'quote', focus:'One-time special remains additive', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 5000; q.ornamentalSqft = 0; q.palmCount = 0; q.services.turf.selected = true; q.specials.fireAnt.selected = true; q.specials.fireAnt.price = 350; state.currentQuote = q; state.view='quote'; } },
    { key:'soil72', title:'Daily Positioning — 72°F soil', kind:'daily', focus:'Daily positioning should react smoothly', apply(state){ state.soilTemp = 72; state.turf = 'staug'; state.view = 'dashboard'; state.lastDailyRefresh = todayKey(); } }
  ];

  const lockedExpectations = {
    turf5000:{ kind:'quote', total:125, cost:5.01, profit:119.99, margin:95.99, annual:1440, discount:0, turfRevenue:120, ornamentalRevenue:0, palmRevenue:0, palmCost:0 },
    orn3000:{ kind:'quote', total:125, cost:8.61, profit:116.39, margin:93.11, annual:1116, discount:0, turfRevenue:0, ornamentalRevenue:93, palmRevenue:0, palmCost:0 },
    trio_base:{ kind:'quote', total:245, cost:28.42, profit:216.58, margin:88.4, annual:2940, discount:0, turfRevenue:120, ornamentalRevenue:93, palmRevenue:32, palmCost:14.8 },
    trio_discount5:{ kind:'quote', total:232.75, cost:28.42, profit:204.33, margin:87.79, annual:2940, discount:12.25, turfRevenue:120, ornamentalRevenue:93, palmRevenue:32, palmCost:14.8 },
    trio_discount10:{ kind:'quote', total:220.5, cost:28.42, profit:192.08, margin:87.11, annual:2940, discount:24.5, turfRevenue:120, ornamentalRevenue:93, palmRevenue:32, palmCost:14.8 },
    palm3:{ kind:'quote', total:125, cost:10.55, profit:114.45, margin:91.56, annual:300, discount:0, turfRevenue:0, ornamentalRevenue:0, palmRevenue:25, palmCost:10.55 },
    palm8:{ kind:'quote', total:125, cost:14.8, profit:110.2, margin:88.16, annual:384, discount:0, turfRevenue:0, ornamentalRevenue:0, palmRevenue:32, palmCost:14.8 },
    palm20:{ kind:'quote', total:125, cost:25, profit:100, margin:80, annual:960, discount:0, turfRevenue:0, ornamentalRevenue:0, palmRevenue:80, palmCost:25 },
    fireant350:{ kind:'quote', total:470, cost:70.01, profit:399.99, margin:85.1, annual:1790, discount:0, turfRevenue:120, ornamentalRevenue:0, palmRevenue:0, palmCost:0 },
    soil72:{ kind:'daily', mode:'Prime optimization window', summary:'Biostimulant and rhizosphere response windows are open.' }
  };

  function getRegressionScenario(key){ return regressionScenarios.find(s=>s.key===key); }
  function applyRegressionScenario(state, key){
    const scenario = getRegressionScenario(key);
    if(!scenario) return false;
    scenario.apply(state);
    state.regressionState = { ...(state.regressionState||{}), activeScenario:key, lastAppliedAt:new Date().toISOString() };
    return true;
  }
  function getRegressionPreview(state, key){
    const clone = JSON.parse(JSON.stringify(state));
    if(!applyRegressionScenario(clone, key)) return null;
    const totals = quoteTotals(clone);
    const sw = seasonalWindow(clone);
    const adv = advisory(clone);
    return { state: clone, totals, sw, adv };
  }
  function regressionMetricChecks(preview, expected){
    if(!preview || !expected) return [{label:'Scenario available', pass:false, actual:'Missing preview', expected:'Expected preview'}];
    if(expected.kind === 'daily'){
      return [
        {label:'Daily mode', pass:String(preview.sw?.mode||'') === String(expected.mode||''), actual:preview.sw?.mode||'', expected:expected.mode||''},
        {label:'Daily summary', pass:String(preview.adv?.summary||'') === String(expected.summary||''), actual:preview.adv?.summary||'', expected:expected.summary||''}
      ];
    }
    const actual = {
      total:Number(preview.totals?.total||0),
      cost:Number(preview.totals?.metrics?.cost||0),
      profit:Number(preview.totals?.metrics?.profit_after_discount||0),
      margin:Number(preview.totals?.metrics?.margin_after_discount_pct||0),
      annual:Number(preview.totals?.metrics?.annual_revenue_total||0),
      discount:Number(preview.totals?.discountAmount||0),
      turfRevenue:Number(preview.totals?.turfRev||0),
      ornamentalRevenue:Number(preview.totals?.ornRev||0),
      palmRevenue:Number(preview.totals?.palmRev?.price||0),
      palmCost:Number(preview.totals?.metrics?.cost_breakdown?.palm||0)
    };
    return Object.keys(expected).filter(key=>key!=='kind').map(key=>({
      label:key,
      pass:Math.abs(Number(actual[key]||0) - Number(expected[key]||0)) <= 0.01,
      actual:Number(actual[key]||0),
      expected:Number(expected[key]||0)
    }));
  }
  function runLockedRegressionChecks(state){
    return regressionScenarios.map(sc=>{
      const expected = lockedExpectations[sc.key];
      const preview = getRegressionPreview(state, sc.key);
      const checks = regressionMetricChecks(preview, expected);
      return {
        key: sc.key,
        title: sc.title,
        kind: sc.kind,
        ok: checks.every(check=>check.pass),
        checks,
        expected,
        preview
      };
    });
  }

  return {
    regressionScenarios,
    lockedExpectations,
    getRegressionScenario,
    applyRegressionScenario,
    getRegressionPreview,
    regressionMetricChecks,
    runLockedRegressionChecks
  };
}
