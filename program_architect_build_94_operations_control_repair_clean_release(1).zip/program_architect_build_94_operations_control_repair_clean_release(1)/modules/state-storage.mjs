export function createStateStorage(deps){
  const {
    STORAGE_KEY,
    LEGACY_STORAGE_KEYS,
    APP_META,
    defaultState,
    migrateCatalogState,
    PRELOADED_CATALOG_PRODUCTS,
    rebuildVendorCatalogFromProducts,
    defaultDeletedBuiltInSpecialPrograms,
    defaultPrograms,
    defaultOrnamentalPrograms,
    defaultSpecialPrograms,
    defaultSelectedSpecialPrograms,
    specialsCatalog,
    withLegacyAliases,
    blankQuote,
    ornamentalDensityTier,
    downloadText
  } = deps;

  function hydrateStateSnapshot(s){
    let migratedCatalog = migrateCatalogState(s);
    if(!migratedCatalog.products.length){
      migratedCatalog = {
        products: PRELOADED_CATALOG_PRODUCTS,
        vendorCatalog: rebuildVendorCatalogFromProducts(PRELOADED_CATALOG_PRODUCTS)
      };
    }
    const deletedBuiltInPrograms = Array.isArray(s.deletedBuiltInPrograms) ? s.deletedBuiltInPrograms : [];
    const deletedBuiltInOrnamentalPrograms = Array.isArray(s.deletedBuiltInOrnamentalPrograms) ? s.deletedBuiltInOrnamentalPrograms : [];
    const deletedBuiltInSpecialPrograms = structuredClone(defaultDeletedBuiltInSpecialPrograms);
    Object.entries(s.deletedBuiltInSpecialPrograms || {}).forEach(([key, values])=>{
      if(Array.isArray(values)) deletedBuiltInSpecialPrograms[key] = values;
    });
    const programsMerged = {...defaultPrograms, ...(s.programs||{})};
    deletedBuiltInPrograms.forEach(key=>{ delete programsMerged[key]; });
    const ornamentalProgramsMerged = {...defaultOrnamentalPrograms, ...(s.ornamentalPrograms||{})};
    deletedBuiltInOrnamentalPrograms.forEach(key=>{ delete ornamentalProgramsMerged[key]; });
    const specialProgramsMerged = structuredClone(defaultSpecialPrograms);
    Object.entries(s.specialPrograms || {}).forEach(([treatmentKey, collection])=>{
      specialProgramsMerged[treatmentKey] = {...(defaultSpecialPrograms[treatmentKey] || {}), ...(collection || {})};
      (deletedBuiltInSpecialPrograms[treatmentKey] || []).forEach(key=>{ delete specialProgramsMerged[treatmentKey][key]; });
    });
    Object.keys(defaultSpecialPrograms).forEach(treatmentKey=>{
      specialProgramsMerged[treatmentKey] = {...(defaultSpecialPrograms[treatmentKey] || {}), ...(specialProgramsMerged[treatmentKey] || {})};
      (deletedBuiltInSpecialPrograms[treatmentKey] || []).forEach(key=>{ delete specialProgramsMerged[treatmentKey][key]; });
    });
    const selectedSpecialPrograms = {...defaultSelectedSpecialPrograms, ...(s.selectedSpecialPrograms || {})};
    Object.keys(defaultSpecialPrograms).forEach(treatmentKey=>{
      const collection = specialProgramsMerged[treatmentKey] || {};
      if(!collection[selectedSpecialPrograms[treatmentKey]]){
        selectedSpecialPrograms[treatmentKey] = Object.keys(collection)[0] || `special_${treatmentKey}_base`;
      }
    });
    return {
      ...defaultState,
      ...s,
      labels:withLegacyAliases({...defaultState.labels, ...(s.labels||{})}),
      programs:programsMerged,
      ornamentalPrograms:ornamentalProgramsMerged,
      specialPrograms:specialProgramsMerged,
      selectedSpecialPrograms,
      selectedSpecialTreatment:(s.selectedSpecialTreatment && specialsCatalog.some(x=>x.key===s.selectedSpecialTreatment)) ? s.selectedSpecialTreatment : defaultState.selectedSpecialTreatment,
      deletedBuiltInPrograms,
      deletedBuiltInOrnamentalPrograms,
      deletedBuiltInSpecialPrograms,
      currentQuote:{...blankQuote(), ...(s.currentQuote||{}), ornamentalDensity: ornamentalDensityTier((s.currentQuote||{}).ornamentalDensity)},
      history:s.history||[],
      vendorCatalog:migratedCatalog.vendorCatalog,
      catalogState:{...defaultState.catalogState, ...(s.catalogState||{}), products:migratedCatalog.products},
      importState:{...defaultState.importState, ...(s.importState||{})},
      validationState:{...defaultState.validationState, ...(s.validationState||{})},
      regressionState:{...defaultState.regressionState, ...(s.regressionState||{})},
      specialTreatmentState:{...defaultState.specialTreatmentState, ...(s.specialTreatmentState||{})},
      actualSell:{...defaultState.actualSell, ...(s.actualSell||{})},
      margins:{turf:45, ornamental:50, palm:55, specials:60, ...(s.margins||{})},
      manualSales:s.manualSales||[],
      forecasts:{properties:1, avgTurfSqft:5000, avgOrnSqft:3000, avgPalmCount:8, avgSpecialSqft:3000, ...(s.forecasts||{})},
      orderSheetDraft:s.orderSheetDraft||[],
      labelCenter:{...defaultState.labelCenter, ...(s.labelCenter||{})},
      programLineEditors:{turf:{}, ornamental:{}, specials:{}, ...(s.programLineEditors||{})},
      appMeta:{...defaultState.appMeta, ...(s.appMeta||{})},
      settings:{...defaultState.settings, ...(s.settings||{})}
    };
  }

  function loadState(){
    try{
      const raw = localStorage.getItem(STORAGE_KEY) || LEGACY_STORAGE_KEYS.map(key=>localStorage.getItem(key)).find(Boolean) || "{}";
      const s = JSON.parse(raw);
      return hydrateStateSnapshot(s);
    }catch{return structuredClone(defaultState);}
  }

  function serializeBackupPayload(state){
    return {
      app: APP_META.appName,
      build: APP_META.buildLabel,
      exportedAt: new Date().toISOString(),
      storageKey: STORAGE_KEY,
      state
    };
  }

  function saveState(state){
    state.appMeta = {...defaultState.appMeta, ...(state.appMeta||{}), lastSavedAt:new Date().toISOString()};
    if(state.settings?.autoBackupOnSave){
      const lastAuto = new Date(state.appMeta.lastAutoBackupAt || 0).getTime();
      const now = Date.now();
      if(!lastAuto || (now - lastAuto) > (5 * 60 * 1000)){
        const stamp = new Date(now).toISOString().replace(/[:.]/g, "-");
        downloadText(`${APP_META.backupFilePrefix}-autosave-${stamp}.json`, JSON.stringify(serializeBackupPayload(state), null, 2), "application/json");
        state.appMeta.lastAutoBackupAt = new Date(now).toISOString();
        state.appMeta.lastBackupAt = state.appMeta.lastAutoBackupAt;
      }
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  function exportBackup(state){
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    downloadText(`${APP_META.backupFilePrefix}-${stamp}.json`, JSON.stringify(serializeBackupPayload(state), null, 2), "application/json");
    state.appMeta = {...defaultState.appMeta, ...(state.appMeta||{}), lastBackupAt:new Date().toISOString()};
    saveState(state);
  }

  function importBackupText(text){
    const payload = JSON.parse(String(text||"{}"));
    const snapshot = payload && typeof payload === "object" && payload.state && typeof payload.state === "object" ? payload.state : payload;
    const restored = hydrateStateSnapshot(snapshot || {});
    restored.appMeta = {...defaultState.appMeta, ...(restored.appMeta||{}), lastRestoreAt:new Date().toISOString()};
    saveState(restored);
    return restored;
  }

  return {
    hydrateStateSnapshot,
    loadState,
    serializeBackupPayload,
    saveState,
    exportBackup,
    importBackupText
  };
}
