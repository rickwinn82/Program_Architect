import fs from "fs";
import path from "path";
import vm from "vm";
import process from "process";

const root = path.resolve(process.cwd());
const calcPath = path.join(root, "calc-core.js");
const appPath = path.join(root, "app-main.js");
const expectedPath = path.join(root, "regression-expected.json");

const calcSource = fs.readFileSync(calcPath, "utf8");
let appSource = fs.readFileSync(appPath, "utf8");
appSource = appSource.replace(/^(import .*?;\r?\n)+/, "");
appSource = appSource.replace(/new URL\("\.\/vendor\/pdf\.min\.mjs", import\.meta\.url\)\.href/g, '"./vendor/pdf.min.mjs"');
appSource = appSource.replace(/new URL\("\.\/vendor\/pdf\.worker\.min\.mjs", import\.meta\.url\)\.href/g, '"./vendor/pdf.worker.min.mjs"');

const context = {
  console,
  structuredClone,
  setTimeout,
  clearTimeout,
  Date,
  Math,
  JSON,
  Number,
  String,
  Boolean,
  Array,
  Object,
  RegExp,
  Intl,
  URL,
  Map,
  Set,
  WeakMap,
  WeakSet,
  Promise,
  Blob,
  navigator: {},
  location: { href: "" },
  localStorage: { getItem(){ return null; }, setItem(){}, removeItem(){} },
  document: {
    head: { appendChild(){} },
    body: { appendChild(){}, removeChild(){} },
    getElementById(){ return null; },
    querySelectorAll(){ return []; },
    createElement(){ return { style:{}, click(){}, remove(){}, set src(v){ this._src = v; }, set href(v){ this._href = v; } }; },
    addEventListener(){}
  },
  alert(){},
  confirm(){ return true; },
  prompt(){ return ""; },
  open(){ return { document:{ write(){}, close(){} }, focus(){}, print(){} }; },
  FileReader: class {},
  ensurePdfJsModule: async ()=>({ GlobalWorkerOptions:{} }),
  STORAGE_KEY: "program-architect-unified-v2-build82",
  LEGACY_STORAGE_KEYS: [],
  BASE_APP_META: {
    appName: "Program Architect",
    buildLabel: "Build 94 Operations Control Repair",
    officeContactEmail: "rick@genesiswm.net",
    officeContactPhone: "941-720-6840",
    orderSheetTitle: "Genesis Development Order Sheet",
    estimateSubjectPrefix: "Program Architect Estimate",
    backupFilePrefix: "program-architect-backup"
  },
  APP_COPY: {
    officeDeliveryContact: "rick@genesiswm.net | 941-720-6840",
    pdfOfflineHelp: "Vendor bid PDF import could not load the local PDF.js bundle."
  },
  createStateStorage: ({defaultState}) => ({
    hydrateStateSnapshot: s => ({...defaultState, ...s}),
    loadState: () => structuredClone(defaultState),
    saveState(){},
    exportBackup(){},
    importBackupText: text => JSON.parse(text)
  }),
  createRegressionTools: ({blankRegressionQuote, todayKey, quoteTotals, seasonalWindow, advisory}) => {
    const regressionScenarios = [
      { key:'turf5000', kind:'quote', title:'Turf only — 5,000 sq ft monthly', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 5000; q.services.turf.selected = true; state.currentQuote = q; state.view='quote'; } },
      { key:'orn3000', kind:'quote', title:'Ornamental only — 3,000 sq ft monthly', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 0; q.ornamentalSqft = 3000; q.services.ornamental.selected = true; state.currentQuote = q; state.view='quote'; } },
      { key:'trio_base', kind:'quote', title:'Turf + ornamental + palms', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 5000; q.ornamentalSqft = 3000; q.palmCount = 8; q.services.turf.selected = true; q.services.ornamental.selected = true; q.services.palm.selected = true; state.currentQuote = q; state.view='quote'; } },
      { key:'trio_discount5', kind:'quote', title:'Trio quote with 5% manual discount', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 5000; q.ornamentalSqft = 3000; q.palmCount = 8; q.services.turf.selected = true; q.services.ornamental.selected = true; q.services.palm.selected = true; q.manualDiscountPct = 5; state.currentQuote = q; state.view='quote'; } },
      { key:'trio_discount10', kind:'quote', title:'Trio quote with 10% manual discount', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 5000; q.ornamentalSqft = 3000; q.palmCount = 8; q.services.turf.selected = true; q.services.ornamental.selected = true; q.services.palm.selected = true; q.manualDiscountPct = 10; state.currentQuote = q; state.view='quote'; } },
      { key:'palm3', kind:'quote', title:'Palm minimum case — 3 palms', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 0; q.ornamentalSqft = 0; q.palmCount = 3; q.services.palm.selected = true; state.currentQuote = q; state.view='quote'; } },
      { key:'palm8', kind:'quote', title:'Palm count case — 8 palms', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 0; q.ornamentalSqft = 0; q.palmCount = 8; q.services.palm.selected = true; state.currentQuote = q; state.view='quote'; } },
      { key:'palm20', kind:'quote', title:'Palm count case — 20 palms', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 0; q.ornamentalSqft = 0; q.palmCount = 20; q.services.palm.selected = true; state.currentQuote = q; state.view='quote'; } },
      { key:'fireant350', kind:'quote', title:'Special treatment — Fire Ant add-on', apply(state){ const q = blankRegressionQuote(); q.turfSqft = 5000; q.services.turf.selected = true; q.specials.fireAnt.selected = true; q.specials.fireAnt.price = 350; state.currentQuote = q; state.view='quote'; } },
      { key:'soil72', kind:'daily', title:'Daily Positioning — 72°F soil', apply(state){ state.soilTemp = 72; state.turf = 'staug'; state.view = 'dashboard'; state.lastDailyRefresh = todayKey(); } }
    ];
    function applyRegressionScenario(state, key){ const scenario = regressionScenarios.find(s => s.key === key); if(!scenario) return false; scenario.apply(state); return true; }
    function getRegressionPreview(state, key){ const clone = JSON.parse(JSON.stringify(state)); if(!applyRegressionScenario(clone, key)) return null; return { state: clone, totals: quoteTotals(clone), sw: seasonalWindow(clone), adv: advisory(clone) }; }
    return { regressionScenarios, getRegressionPreview };
  }
};

context.window = context;
context.globalThis = context;
context.self = context;
context.addEventListener = () => {};

vm.createContext(context);
vm.runInContext(calcSource, context);
vm.runInContext(`${appSource}\n;globalThis.__capture = { defaultState, regressionScenarios, getRegressionPreview };`, context);

const { defaultState, regressionScenarios, getRegressionPreview } = context.__capture;
const expected = JSON.parse(fs.readFileSync(expectedPath, "utf8"));
const failures = [];

for (const scenario of regressionScenarios) {
  const preview = getRegressionPreview(structuredClone(defaultState), scenario.key);
  const baseline = expected[scenario.key];
  if (!preview || !baseline) {
    failures.push(`${scenario.key}: missing preview or baseline`);
    continue;
  }
  if (baseline.kind === "daily") {
    if (String(preview.sw?.mode || "") !== String(baseline.mode || "")) failures.push(`${scenario.key}: mode changed`);
    if (String(preview.adv?.summary || "") !== String(baseline.summary || "")) failures.push(`${scenario.key}: summary changed`);
    continue;
  }
  const actual = {
    total: Number(preview.totals?.total || 0),
    cost: Number(preview.totals?.metrics?.cost || 0),
    profit: Number(preview.totals?.metrics?.profit_after_discount || 0),
    margin: Number(preview.totals?.metrics?.margin_after_discount_pct || 0),
    annual: Number(preview.totals?.metrics?.annual_revenue_total || 0),
    discount: Number(preview.totals?.discountAmount || 0),
    turfRevenue: Number(preview.totals?.turfRev || 0),
    ornamentalRevenue: Number(preview.totals?.ornRev || 0),
    palmRevenue: Number(preview.totals?.palmRev?.price || 0),
    palmCost: Number(preview.totals?.metrics?.cost_breakdown?.palm || 0)
  };
  for (const [key, expectedValue] of Object.entries(baseline)) {
    if (key === "kind") continue;
    const actualValue = Number(actual[key] || 0);
    if (Math.abs(actualValue - Number(expectedValue || 0)) > 0.01) {
      failures.push(`${scenario.key}: ${key} expected ${expectedValue} got ${actualValue}`);
    }
  }
}

if (failures.length) {
  console.error("Regression check failures:");
  failures.forEach(item => console.error(`- ${item}`));
  process.exit(1);
}

console.log(`Regression checks passed for ${regressionScenarios.length} scenarios.`);
