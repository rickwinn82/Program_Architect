const CACHE_NAME = "program-architect-build94-v1";
const APP_SHELL = [
  "./",
  "./index.html",
  "./calc-core.js",
  "./app-main.js",
  "./manifest.webmanifest",
  "./README.txt",
  "./Program%20Architect%20Build%2094%20Operations%20Control%20Repair%20Standalone.html",
  "./icon.svg",
  "./modules/pdf-loader.mjs",
  "./modules/constants.mjs",
  "./modules/state-storage.mjs",
  "./modules/regression-tools.mjs",
  "./vendor/pdf.min.mjs",
  "./vendor/pdf.worker.min.mjs",
  "./regression-expected.json",
  "./package.json"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  if(event.request.method !== "GET") return;
  event.respondWith(
    caches.match(event.request).then(cached => {
      if(cached) return cached;
      return fetch(event.request).then(response => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy)).catch(() => {});
        return response;
      }).catch(() => caches.match("./index.html"));
    })
  );
});
